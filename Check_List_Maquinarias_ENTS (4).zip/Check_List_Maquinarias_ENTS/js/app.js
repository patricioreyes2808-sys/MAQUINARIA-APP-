/* =========================================================================
   Check List Maquinarias ENTS — Aplicación (núcleo, acceso y panel)
   ========================================================================= */
(function () {
  'use strict';

  var E = UI.esc, I = UI.icon;
  var S = { user: null, view: 'dashboard', params: {} };
  var WIZ = null;
  var HIST = { q: '', estado: '', desde: '', hasta: '' };
  var PL_FILTRO = '';
  var PLEDIT = null;
  var DEFERRED = null;
  var IMPORT = null;

  var NAV = [
    { id: 'dashboard', label: 'Panel', icon: 'dashboard', roles: ['admin', 'supervisor', 'operador'] },
    { id: 'nuevo', label: 'Nuevo checklist', icon: 'plus', roles: ['admin', 'supervisor', 'operador'] },
    { id: 'historial', label: 'Historial', icon: 'list', roles: ['admin', 'supervisor', 'operador'] },
    { id: 'usuarios', label: 'Usuarios', icon: 'users', roles: ['admin', 'supervisor'], group: 'Administración' },
    { id: 'equipos', label: 'Equipos', icon: 'truck', roles: ['admin', 'supervisor'], group: 'Administración' },
    { id: 'plantillas', label: 'Plantillas', icon: 'file', roles: ['admin', 'supervisor'], group: 'Administración' },
    { id: 'ajustes', label: 'Configuración', icon: 'settings', roles: ['admin', 'supervisor'], group: 'Administración' }
  ];

  var ROLES_VISTA = {
    dashboard: ['admin', 'supervisor', 'operador'],
    nuevo: ['admin', 'supervisor', 'operador'],
    historial: ['admin', 'supervisor', 'operador'],
    insp: ['admin', 'supervisor', 'operador'],
    usuarios: ['admin', 'supervisor'],
    equipos: ['admin', 'supervisor'],
    plantillas: ['admin', 'supervisor'],
    ajustes: ['admin', 'supervisor']
  };

  var TITLES = {
    dashboard: ['Panel de control', 'Resumen operacional de los checklists de maquinaria.'],
    nuevo: ['Nuevo check list', 'Elige el tipo de maquinaria y registra la inspección en terreno.'],
    historial: ['Historial de check list', 'Todos los registros con su estado y confirmación por WhatsApp.'],
    usuarios: ['Usuarios', 'Crea las cuentas de operadores y supervisores con sus equipos asignados.'],
    equipos: ['Equipos', 'Catálogo de maquinaria disponible para inspección.'],
    plantillas: ['Check lists por tipo de maquinaria', 'Los 22 check lists oficiales y los que subas en Excel.'],
    ajustes: ['Configuración', 'Datos de la empresa, mensaje de WhatsApp y respaldos.'],
    insp: ['Detalle del check list', 'Registro completo, firma y confirmación de envío.']
  };

  /* ------------------------------- helpers ------------------------------- */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }

  function equipoById(id) {
    var e = DB.equipos();
    for (var i = 0; i < e.length; i++) if (e[i].id === id) return e[i];
    return null;
  }

  function isAdmin() { return S.user && S.user.rol === 'admin'; }
  function isSuper() { return S.user && (S.user.rol === 'admin' || S.user.rol === 'supervisor'); }

  function visibles() {
    var list = DB.inspecciones().slice();
    if (S.user.rol === 'operador') list = list.filter(function (i) { return i.usuarioId === S.user.id; });
    return list;
  }

  function codigoCorto(ins) { return String(ins.id).replace(/[^a-z0-9]/gi, '').slice(-6).toUpperCase(); }

  /* ------------------------------- arranque ------------------------------ */
  document.addEventListener('DOMContentLoaded', function () {
    DB.init();
    S.user = DB.currentUser();
    bindGlobal();
    if (S.user) {
      renderApp();
      if (window.API && API.sesion()) API.jalar().then(function () { renderView(); });
    } else {
      renderLogin();
    }
    registerPWA();
  });

  function bindGlobal() {
    document.addEventListener('click', onClick);
    document.addEventListener('submit', function (e) {
      e.preventDefault();
      if (e.target.id === 'login-form') doLogin();
    });
    document.addEventListener('change', onInput);
    document.addEventListener('input', onInput);
  }

  /* --------------------------------- login ------------------------------- */
  function renderLogin() {
    var app = document.getElementById('app');
    app.innerHTML =
      '<div class="login">' +
        '<section class="login-art">' +
          '<div class="brand">' +
            '<div class="brand-mark">' + I('check') + '</div>' +
            '<div class="brand-txt"><strong>Check List Maquinarias</strong><span>ENTS</span></div>' +
          '</div>' +
          '<div>' +
            '<div class="chip" style="margin-bottom:18px"><span class="dot"></span> Plataforma de inspección de maquinaria</div>' +
            '<h1 class="login-headline">Check list de <em>maquinaria</em> sin papel.</h1>' +
            '<p class="login-sub">Digitaliza la inspección diaria de 22 tipos de maquinaria, deja evidencia firmada y confirma cada registro por WhatsApp en el mismo momento.</p>' +
            '<div class="login-feats">' +
              feat('file', 'Check lists desde Excel', 'Sube tus planillas y quedan disponibles como formularios.') +
              feat('whatsapp', 'Confirmación por WhatsApp', 'Cada registro envía día, fecha y hora al encuestado.') +
              feat('shield', 'Perfil administrador', 'Crea usuarios con RUT, correo, celular y equipo a operar.') +
              feat('smart', 'Instalable en Android y iPhone', 'Funciona como aplicación, incluso sin señal en faena.') +
            '</div>' +
          '</div>' +
          '<div class="small muted">© 2026 ENTS · Registro digital de inspecciones de maquinaria</div>' +
        '</section>' +
        '<section class="login-form-wrap">' +
          '<form class="login-card" id="login-form" autocomplete="on">' +
            '<div class="brand" style="margin-bottom:26px">' +
              '<div class="brand-mark">' + I('check') + '</div>' +
              '<div class="brand-txt"><strong>Check List Maquinarias</strong><span>ENTS</span></div>' +
            '</div>' +
            '<h2>Iniciar sesión</h2>' +
            '<p class="lead">Ingresa con tu correo o RUT y tu contraseña.</p>' +
            '<div class="form-row" style="gap:13px">' +
              '<div class="field">' +
                '<label for="li-user">Correo o RUT</label>' +
                '<input id="li-user" name="user" type="text" placeholder="nombre@empresa.cl" autocomplete="username" required>' +
              '</div>' +
              '<div class="field">' +
                '<label for="li-pass">Contraseña</label>' +
                '<div style="position:relative">' +
                  '<input id="li-pass" name="pass" type="password" placeholder="••••••••" autocomplete="current-password" required style="padding-right:44px">' +
                  '<button type="button" class="icon-btn" data-act="toggle-pass" style="position:absolute;right:3px;top:3px;border:0">' + I('eye') + '</button>' +
                '</div>' +
              '</div>' +
              '<div id="login-error" class="field invalid" style="display:none"><span class="err" style="display:block"></span></div>' +
              '<button class="btn btn-primary btn-block" type="submit" style="margin-top:4px;height:44px">Ingresar al sistema ' + I('arrow') + '</button>' +
            '</div>' +
            '<div class="demo-box">' +
              '<b>Cuentas de demostración</b>' +
              demo('Administrador', 'admin@ents.cl', 'Admin2026') +
              demo('Supervisor', 'supervisor@ents.cl', 'Supervisor2026') +
              demo('Operador', 'operador@ents.cl', 'Operador2026') +
            '</div>' +
            '<div class="login-foot">¿Olvidaste tu contraseña? El administrador puede asignarte una nueva.<br>Los datos quedan guardados en este dispositivo.</div>' +
          '</form>' +
        '</section>' +
      '</div>';
  }

  function feat(ico, t, d) {
    return '<div class="login-feat"><div class="fi">' + I(ico) + '</div><div><b>' + E(t) + '</b><br>' + E(d) + '</div></div>';
  }

  function demo(rol, mail, pass) {
    return '<div class="demo-line"><span>' + E(rol) + '</span><code>' + E(mail) + '</code>' +
      '<button type="button" class="btn btn-sm btn-ghost" data-act="demo" data-mail="' + E(mail) + '" data-pass="' + E(pass) + '">Usar</button></div>';
  }

  function doLogin() {
    var u = $('#li-user').value, p = $('#li-pass').value;
    var box = $('#login-error');
    function fallo(msg) {
      box.style.display = 'block';
      box.querySelector('.err').textContent = msg;
    }

    if (window.API && API.activo()) {
      var btn = $('.login-card button[type="submit"]');
      var textoBoton = btn ? btn.innerHTML : '';
      if (btn) { btn.disabled = true; btn.innerHTML = 'Conectando…'; }
      API.conectar(API.info().url, u, p).then(function (datos) {
        var local = DB.entrarRemoto(datos.usuario, p);
        S.user = local;
        S.view = 'dashboard';
        UI.toast('Bienvenido, ' + String(local.nombre).split(' ')[0]);
        renderApp();
        API.jalar().then(function () { renderView(); });
      }).catch(function (e) {
        var r = DB.login(u, p);
        if (r.ok) {
          S.user = r.user;
          S.view = 'dashboard';
          UI.toast('Sin conexión: trabajando con la copia guardada');
          renderApp();
        } else {
          fallo(e && e.message ? 'No se pudo conectar: ' + e.message : 'No se pudo conectar con el servidor.');
        }
      }).then(function () {
        if (btn) { btn.disabled = false; btn.innerHTML = textoBoton; }
      });
      return;
    }

    var r = DB.login(u, p);
    if (!r.ok) { fallo(r.error); return; }
    S.user = r.user;
    S.view = 'dashboard';
    UI.toast('Bienvenido, ' + r.user.nombre.split(' ')[0]);
    renderApp();
  }

  /* --------------------------------- shell ------------------------------- */
  function renderApp() {
    var items = NAV.filter(function (n) { return n.roles.indexOf(S.user.rol) >= 0; });
    var st = DB.stats();
    var navHtml = '', lastGroup = '';
    items.forEach(function (n) {
      if (n.group && n.group !== lastGroup) { navHtml += '<div class="nav-label">' + E(n.group) + '</div>'; lastGroup = n.group; }
      var badge = (n.id === 'historial' && st.sinEnviar) ? '<span class="pill">' + st.sinEnviar + '</span>' : '';
      navHtml += '<a href="#" data-act="nav" data-view="' + n.id + '" class="' + (S.view === n.id || (S.view === 'insp' && n.id === 'historial') ? 'active' : '') + '">' +
        I(n.icon) + '<span>' + E(n.label) + '</span>' + badge + '</a>';
    });

    var rolTxt = S.user.rol === 'admin' ? 'Administrador' : (S.user.rol === 'supervisor' ? 'Supervisor' : 'Operador');

    document.getElementById('app').innerHTML =
      '<div class="shell">' +
        '<aside class="sidebar">' +
          '<div class="brand">' +
            '<div class="brand-mark">' + I('check') + '</div>' +
            '<div class="brand-txt"><strong>Check List Maquinarias</strong><span>ENTS</span></div>' +
          '</div>' +
          '<nav class="nav">' + navHtml + '</nav>' +
          '<div class="side-foot">' +
            '<div class="user-chip" data-act="cuenta">' +
              '<div class="avatar">' + E(UI.initials(S.user.nombre)) + '</div>' +
              '<div class="u-meta"><strong>' + E(S.user.nombre) + '</strong><span>' + E(rolTxt) + '</span></div>' +
              I('settings', 'small') +
            '</div>' +
          '</div>' +
        '</aside>' +
        '<main class="main">' +
          '<div class="topbar">' +
            '<button type="button" class="icon-btn menu-btn" data-act="open-nav" aria-label="Menú">' + I('menu') + '</button>' +
            '<div class="crumb">ENTS / <b>' + E((TITLES[S.view] || ['Panel'])[0]) + '</b></div>' +
            '<div class="spacer"></div>' +
            '<button type="button" class="btn btn-ghost btn-sm" data-act="install" id="btn-install" style="display:none">' + I('download') + ' Instalar app</button>' +
            (window.API && API.activo() ? (function () {
              var i = API.info();
              var color = i.estado === 'conectado' ? 'var(--ok)' : (i.estado === 'sin-conexion' ? 'var(--amber)' : 'var(--bad)');
              var txt = i.estado === 'conectado' ? 'Base compartida' : (i.estado === 'sin-conexion' ? 'Sin conexión' : 'Sesión vencida');
              return '<span class="chip" title="' + E(i.url) + '"><span class="dot" style="background:' + color + '"></span>' + E(txt) + '</span>';
            })() : '<span class="chip" title="Los datos se guardan solo en este equipo"><span class="dot" style="background:var(--muted)"></span>Datos locales</span>') +
            '<span class="chip"><span class="dot" style="background:' + (S.user.rol === 'admin' ? 'var(--amber)' : 'var(--ok)') + '"></span>' + E(rolTxt) + '</span>' +
          '</div>' +
          '<div id="view" class="view"></div>' +
        '</main>' +
      '</div>';

    if (DEFERRED) { var b = $('#btn-install'); if (b) b.style.display = 'inline-flex'; }
    renderView();
  }

  function renderView() {
    var v = S.view, html = '', after = null;
    if (S.user && ROLES_VISTA[v] && ROLES_VISTA[v].indexOf(S.user.rol) < 0) { v = 'dashboard'; S.view = 'dashboard'; }
    if (v === 'dashboard') html = viewDashboard();
    else if (v === 'nuevo') html = viewNuevo();
    else if (v === 'historial') { html = viewHistorial(); after = afterView; }
    else if (v === 'usuarios') html = viewUsuarios();
    else if (v === 'equipos') html = viewEquipos();
    else if (v === 'plantillas') html = viewPlantillas();
    else if (v === 'ajustes') html = viewAjustes();
    else if (v === 'insp') html = viewInsp();
    else html = viewDashboard();
    var host = document.getElementById('view');
    if (!host) return;
    host.innerHTML = html;
    host.classList.remove('view'); void host.offsetWidth; host.classList.add('view');
    if (after) after(host);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    closeNav();
  }

  function go(view, params) {
    S.view = view; S.params = params || {};
    $$('.nav a').forEach(function (a) { a.classList.toggle('active', a.dataset.view === view || (view === 'insp' && a.dataset.view === 'historial')); });
    var crumb = $('.topbar .crumb b');
    if (crumb) crumb.textContent = (TITLES[view] || ['Panel'])[0];
    renderView();
  }

  function closeNav() { document.body.classList.remove('nav-open'); }

  function pageHead(actions) {
    var t = TITLES[S.view] || ['', ''];
    return '<div class="page-head"><div><h1>' + E(t[0]) + '</h1><p class="sub">' + E(t[1]) + '</p></div><div class="spacer"></div>' +
      (actions ? '<div class="page-actions">' + actions + '</div>' : '') + '</div>';
  }

  /* ------------------------------- dashboard ----------------------------- */
  function viewDashboard() {
    var st = DB.stats();
    var ins = visibles();
    var recientes = ins.slice(0, 5);
    var max = Math.max.apply(null, st.serie.map(function (x) { return x.total; }).concat([1]));

    var bars = st.serie.map(function (x) {
      var h = Math.round(x.total * 100 / max);
      return '<div class="bar-col"><div class="bar-v">' + x.total + '</div>' +
        '<div class="bar ' + (x.total ? '' : 'zero') + '" style="height:' + Math.max(6, h) + '%"></div>' +
        '<div class="bar-lbl">' + E(x.label) + ' ' + x.dia + '</div></div>';
    }).join('');

    var acts = recientes.length ? recientes.map(function (i) {
      var cls = i.estado === 'Aprobado' ? 'ok' : (i.estado === 'Rechazado' ? 'bad' : 'warn');
      return '<div class="act" data-act="ver" data-id="' + E(i.id) + '" style="cursor:pointer">' +
        '<div class="act-dot ' + cls + '">' + UI.estadoIcon(i.estado) + '</div>' +
        '<div class="act-body"><strong>' + E(i.equipoCodigo + ' · ' + i.equipoNombre) + '</strong>' +
        '<span>' + E(i.estado) + ' · ' + E(DB.fechaHora(i.creado)) + ' · ' + E(i.usuarioNombre.split(' ')[0]) + '</span></div>' +
        (i.whatsapp && i.whatsapp.enviado ? '<span class="badge badge-ok">' + I('check') + ' WA</span>' : '<span class="badge badge-warn">Sin enviar</span>') +
      '</div>';
    }).join('') : UI.empty('Aún no hay checklists', 'Registra el primero para comenzar el historial.');

    return pageHead(
        '<button type="button" class="btn btn-ghost" data-act="nav" data-view="historial">' + I('list') + ' Ver historial</button>' +
        '<button type="button" class="btn btn-primary" data-act="nav" data-view="nuevo">' + I('plus') + ' Nuevo checklist</button>'
      ) +
      (isAdmin() ? '<div class="card card-pad" style="margin-bottom:16px;border-color:rgba(255,176,32,.28);background:linear-gradient(100deg,rgba(255,176,32,.09),rgba(255,176,32,.01))">' +
        '<div style="display:flex;gap:13px;align-items:center;flex-wrap:wrap">' +
          '<div class="act-dot" style="background:var(--amber-soft);color:var(--amber);width:36px;height:36px;border-radius:10px">' + I('shield') + '</div>' +
          '<div style="flex:1;min-width:200px"><strong style="font-size:13.5px">Sesión con permisos de administrador</strong>' +
          '<div class="small muted">Puedes crear usuarios, asignar equipos, subir checklists desde Excel y configurar el mensaje de WhatsApp.</div></div>' +
          '<button type="button" class="btn btn-soft btn-sm" data-act="nav" data-view="usuarios">' + I('users') + ' Gestionar usuarios</button>' +
        '</div></div>' : '') +
      '<div class="grid grid-4" style="margin-bottom:16px">' +
        kpi('Checklists hoy', st.hoy, 'Registros del día', 'list', 'b') +
        kpi('Cumplimiento 30 días', st.cumplimiento + '<small>%</small>', 'Ítems con B (bueno)', 'shield', 'g') +
        kpi('Sin confirmar por WhatsApp', st.sinEnviar, 'Requieren reenvío', 'whatsapp', st.sinEnviar ? 'r' : '') +
        kpi('Equipos activos', st.equipos, st.usuarios + ' usuarios habilitados', 'truck', '') +
      '</div>' +
      '<div class="grid" style="grid-template-columns:1.55fr 1fr;gap:16px" id="dash-grid">' +
        '<div class="card">' +
          '<div class="card-head"><h3>Actividad de los últimos 7 días</h3><div class="spacer"></div><span class="chip">' + st.total + ' registros</span></div>' +
          '<div class="card-body"><div class="bars">' + bars + '</div></div>' +
        '</div>' +
        '<div class="card">' +
          '<div class="card-head"><h3>Últimos checklists</h3><div class="spacer"></div>' +
            '<button type="button" class="icon-btn" data-act="nav" data-view="historial" aria-label="Ver todos">' + I('arrow') + '</button></div>' +
          '<div class="card-body" style="padding:6px 20px">' + acts + '</div>' +
        '</div>' +
      '</div>' +
      '<div class="grid grid-2" style="margin-top:16px">' +
        '<div class="card"><div class="card-head"><h3>Estado de la flota</h3></div><div class="card-body">' + flota() + '</div></div>' +
        '<div class="card"><div class="card-head"><h3>Checklists sin confirmar</h3><div class="spacer"></div>' +
          '<span class="badge ' + (st.sinEnviar ? 'badge-warn' : 'badge-ok') + '">' + (st.sinEnviar ? st.sinEnviar + ' pendientes' : 'Todo enviado') + '</span></div>' +
          '<div class="card-body" style="padding:8px 20px">' + pendientes(ins) + '</div></div>' +
      '</div>';
  }

  function kpi(label, val, note, ico, tone) {
    return '<div class="kpi ' + (tone || '') + '">' +
      '<div class="kpi-top"><span class="kpi-label">' + E(label) + '</span><div class="kpi-ico">' + I(ico) + '</div></div>' +
      '<div class="kpi-val">' + val + '</div><div class="kpi-note">' + E(note) + '</div></div>';
  }

  function flota() {
    var eqs = DB.equipos().filter(function (e) { return e.activo; });
    var ins = DB.inspecciones();
    if (!eqs.length) return UI.empty('Sin equipos', 'Agrega equipos al catálogo.');
    return '<div style="display:flex;flex-direction:column;gap:9px">' + eqs.slice(0, 6).map(function (e) {
      var last = null;
      for (var i = 0; i < ins.length; i++) { if (ins[i].equipoId === e.id) { last = ins[i]; break; } }
      var badge = !last ? '<span class="badge badge-mute">Sin registro</span>' : UI.badge(last.estado);
      return '<div style="display:flex;align-items:center;gap:10px">' +
        '<div class="avatar" style="width:30px;height:30px;border-radius:8px;font-size:10px">' + E((e.tipo || 'EQ').slice(0, 2).toUpperCase()) + '</div>' +
        '<div style="flex:1;min-width:0"><div class="t-strong" style="font-size:12.8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + E(e.codigo + ' · ' + e.nombre) + '</div>' +
        '<div class="t-sub">' + (last ? E(DB.fechaHora(last.creado)) : 'Sin inspecciones') + '</div></div>' + badge + '</div>';
    }).join('') + '</div>';
  }

  function pendientes(ins) {
    var list = ins.filter(function (i) { return !i.whatsapp || !i.whatsapp.enviado; }).slice(0, 4);
    if (!list.length) return '<div class="empty" style="padding:26px 10px"><div class="empty-ico" style="width:40px;height:40px">' + I('check') + '</div><h4 style="font-size:13px">Todos los mensajes fueron confirmados</h4><p class="small">No hay registros pendientes de envío.</p></div>';
    return list.map(function (i) {
      return '<div class="act" style="align-items:center">' +
        '<div class="act-dot warn">' + I('whatsapp') + '</div>' +
        '<div class="act-body"><strong>' + E(i.equipoCodigo + ' · ' + i.plantillaNombre) + '</strong><span>' + E(DB.fechaHora(i.creado) + ' · ' + i.usuarioNombre) + '</span></div>' +
        '<button type="button" class="btn btn-sm btn-wa" data-act="wa" data-id="' + E(i.id) + '">Enviar</button></div>';
    }).join('');
  }

  /* ------------------------------ nuevo checklist ------------------------- */
  function viewNuevo() {
    if (!WIZ) WIZ = { step: 1, tipo: '', equipoId: '', plantillaId: '', respuestas: {}, obs: {}, observaciones: '', firma: '', telefono: S.user.telefono,
      patente: '', kilometraje: '', ultimaMantencion: '', proximaMantencion: '' };

    var head = pageHead('') +
      '<div class="stepper">' + step(1, 'Equipo y checklist') + '<div class="step-line"></div>' +
      step(2, 'Inspección') + '<div class="step-line"></div>' + step(3, 'Firma y envío') + '</div>';

    if (WIZ.step === 1) return head + wizStep1();
    if (WIZ.step === 2) return head + wizStep2();
    return head + wizStep3();
  }

  function step(n, label) {
    var cls = WIZ.step === n ? 'on' : (WIZ.step > n ? 'done' : '');
    return '<div class="step ' + cls + '"><span class="n">' + (WIZ.step > n ? '✓' : n) + '</span><span class="t">' + E(label) + '</span></div>';
  }

  function wizStep1() {
    var tipos = DB.catalogo();
    var pls = WIZ.tipo ? DB.plantillas().filter(function (p) { return p.tipo === WIZ.tipo; }) : [];
    var eqs = DB.equipos().filter(function (e) { return e.activo; });
    if (S.user.rol === 'operador') {
      var asignados = S.user.equipos || [];
      if (asignados.length) eqs = eqs.filter(function (e) { return asignados.indexOf(e.id) >= 0; });
    }
    if (WIZ.tipo) eqs = eqs.filter(function (e) { return e.tipo === WIZ.tipo; });

    var tipoOpts = '<option value="">Selecciona el tipo de maquinaria…</option>' + tipos.map(function (t) {
      return '<option value="' + E(t.tipo) + '"' + (WIZ.tipo === t.tipo ? ' selected' : '') + '>' + E(t.nombre) + ' · ' + t.items.length + ' ítems</option>';
    }).join('');

    var pl = WIZ.plantillaId ? DB.findPlantilla(WIZ.plantillaId) : (pls[0] || null);
    var plOpts = pls.length > 1 ? '<div class="field" style="margin-top:14px"><label for="wiz-pl">Check list a aplicar</label>' +
      '<select id="wiz-pl" data-bind="plantilla">' + pls.map(function (p) {
        return '<option value="' + E(p.id) + '"' + (pl && pl.id === p.id ? ' selected' : '') + '>' + E(p.nombre) + '</option>';
      }).join('') + '</select></div>' : '';

    var resumen = '';
    if (WIZ.tipo) {
      resumen = '<div style="display:flex;gap:12px;align-items:center;margin-top:14px;background:#0E181E;border:1px solid var(--line);border-radius:10px;padding:12px 14px">' +
        '<div style="color:var(--amber)">' + I('file') + '</div>' +
        '<div><b style="font-size:13px">' + E(pl ? pl.nombre : 'Check list ' + WIZ.tipo) + '</b>' +
        '<div class="small muted">' + (pl ? pl.items.length + ' puntos de inspección · ' + groupItems(pl.items).length + ' secciones' : 'Sin check list cargado para este tipo') + '</div></div></div>';
    }

    var eqHtml = !WIZ.tipo
      ? '<div class="small muted" style="padding:2px">Primero selecciona el tipo de maquinaria.</div>'
      : (eqs.length ? eqs.map(function (e) {
          return '<button type="button" class="pick ' + (WIZ.equipoId === e.id ? 'on' : '') + '" data-act="pick-eq" data-id="' + E(e.id) + '">' +
            '<span class="pk-check">' + I('check') + '</span>' +
            '<div class="pk-code">' + E(e.codigo) + '</div><div class="pk-name">' + E(e.nombre) + '</div>' +
            '<div class="pk-meta">' + E([e.tipo, e.marca, e.modelo].filter(Boolean).join(' · ')) + (e.patente ? ' · ' + E(e.patente) : '') + '</div></button>';
        }).join('') : UI.empty('Sin equipos de este tipo', 'El administrador debe registrar un equipo de ' + WIZ.tipo + ' en el catálogo.'));

    return '<div class="card card-pad" style="margin-bottom:16px">' +
        '<div class="card-head" style="padding:0 0 14px;border:0"><h3>1. Tipo de maquinaria</h3></div>' +
        '<div class="field" style="margin:0"><label for="wiz-tipo">Selecciona el tipo de maquinaria a inspeccionar</label>' +
        '<select id="wiz-tipo" data-bind="tipo">' + tipoOpts + '</select></div>' + plOpts + resumen +
      '</div>' +
      '<div class="card card-pad">' +
        '<div class="card-head" style="padding:0 0 14px;border:0"><h3>2. Equipo inspeccionado</h3>' +
        (WIZ.tipo ? '<span class="chip" style="margin-left:10px">' + E(WIZ.tipo) + '</span>' : '') + '</div>' +
        '<div class="pick-grid">' + eqHtml + '</div></div>' +
      '</div>' +
      datosEquipoHtml() +
      '<div class="form-foot" style="margin-top:16px">' +
        '<div class="small muted">Registro a nombre de <b style="color:#DCE7EE">' + E(S.user.nombre) + '</b> · ' + E(DB.fechaLarga(new Date().toISOString())) + '</div>' +
        '<div style="flex:1"></div>' +
        '<button type="button" class="btn btn-primary" data-act="wiz-next" ' + (WIZ.equipoId && WIZ.plantillaId ? '' : 'disabled') + '>Continuar ' + I('arrow') + '</button>' +
      '</div>';
  }

  function fmtFecha(v) {
    if (!v) return '—';
    var p = String(v).slice(0, 10).split('-');
    return p.length === 3 ? p[2] + '-' + p[1] + '-' + p[0] : String(v);
  }

  function datosEquipoVacios() {
    return !WIZ.patente && !WIZ.kilometraje && !WIZ.ultimaMantencion && !WIZ.proximaMantencion;
  }

  function datosEquipoHtml() {
    var eq = WIZ.equipoId ? equipoById(WIZ.equipoId) : null;
    if (!eq) return '';
    if (datosEquipoVacios() && eq) {
      WIZ.patente = eq.patente || '';
      WIZ.kilometraje = (eq.kilometraje === 0 || eq.kilometraje) ? String(eq.kilometraje) : '';
      WIZ.ultimaMantencion = eq.ultimaMantencion || '';
      WIZ.proximaMantencion = eq.proximaMantencion || '';
    }
    var hoy = new Date().toISOString().slice(0, 10);
    var vencida = WIZ.proximaMantencion && WIZ.proximaMantencion < hoy;
    return '<div class="card card-pad" style="margin-top:16px">' +
        '<div class="card-head" style="padding:0 0 14px;border:0"><h3>3. Datos del equipo</h3>' +
          '<span class="chip" style="margin-left:10px">Se guardan en el registro</span></div>' +
        '<div class="form-row c2">' +
          '<div class="field" data-f="wiz-patente"><label for="wiz-patente">Patente del equipo *</label>' +
            '<input id="wiz-patente" type="text" data-bind="patente" value="' + E(WIZ.patente) + '" placeholder="LJ-PR-42" autocomplete="off">' +
            '<span class="err"></span></div>' +
          '<div class="field" data-f="wiz-km"><label for="wiz-km">Kilometraje u horómetro *</label>' +
            '<input id="wiz-km" type="text" inputmode="numeric" data-bind="kilometraje" value="' + E(WIZ.kilometraje) + '" placeholder="128450">' +
            '<span class="err"></span></div>' +
        '</div>' +
        '<div class="form-row c2" style="margin-top:13px">' +
          '<div class="field" data-f="wiz-um"><label for="wiz-um">Última mantención *</label>' +
            '<input id="wiz-um" type="date" data-bind="ultimaMantencion" value="' + E(WIZ.ultimaMantencion) + '">' +
            '<span class="err"></span></div>' +
          '<div class="field" data-f="wiz-pm"><label for="wiz-pm">Próxima mantención *</label>' +
            '<input id="wiz-pm" type="date" data-bind="proximaMantencion" value="' + E(WIZ.proximaMantencion) + '">' +
            '<span class="err"></span></div>' +
        '</div>' +
        '<div class="small" id="wiz-mant-aviso" style="margin-top:6px;color:' + (vencida ? '#FCA5A5' : 'var(--muted)') + '">' +
          (vencida ? 'Atención: la próxima mantención está vencida respecto de hoy. El registro se puede guardar y quedará con esa observación.' : 'Estos datos aparecen en el PDF y en la confirmación enviada.') +
        '</div></div>';
  }

  function avisoMantencion() {
    var el = document.getElementById('wiz-mant-aviso');
    if (!el || !WIZ) return;
    var hoy = new Date().toISOString().slice(0, 10);
    var vencida = WIZ.proximaMantencion && WIZ.proximaMantencion < hoy;
    el.style.color = vencida ? '#FCA5A5' : 'var(--muted)';
    el.textContent = vencida
      ? 'Atención: la próxima mantención está vencida respecto de hoy. El registro se puede guardar y quedará con esa observación.'
      : 'Estos datos aparecen en el PDF y en la confirmación enviada.';
  }

  function groupItems(items) {
    var out = [], idx = {};
    items.forEach(function (it) {
      var k = it.sec || 'General';
      if (!(k in idx)) { idx[k] = out.length; out.push({ sec: k, items: [] }); }
      out[idx[k]].items.push(it);
    });
    return out;
  }

  function wizStep2() {
    var pl = DB.findPlantilla(WIZ.plantillaId);
    var eq = equipoById(WIZ.equipoId);
    if (!pl) { WIZ.step = 1; return wizStep1(); }
    var grupos = groupItems(pl.items);

    var body = grupos.map(function (g) {
      var items = g.items.map(function (it) {
        var v = WIZ.respuestas[it.id] || '';
        var obs = WIZ.obs[it.id] || '';
        return '<div class="chk-item ' + (v === 'no' ? 'flag-no' : '') + '" data-item="' + E(it.id) + '">' +
          '<div><div class="chk-txt">' + (it.crit ? '<span class="crit-tag">CRÍTICO</span>' : '') + '<span>' + E(it.txt) + '</span></div>' +
          (it.criterio ? '<div class="chk-crit">Criterio: ' + E(it.criterio) + '</div>' : '') + '</div>' +
          '<div class="seg" role="group" aria-label="Resultado del ítem">' +
            segBtn('si', 'B', v, 'Bueno') + segBtn('no', 'M', v, 'Malo') + segBtn('na', 'N/A', v, 'No aplica') +
          '</div>' +
          '<input class="chk-obs" type="text" placeholder="Describe la desviación y la acción tomada" data-bind="obs" data-item="' + E(it.id) + '" value="' + E(obs) + '">' +
        '</div>';
      }).join('');
      return '<div class="card chk-sec"><div class="chk-sec-head">' + I('list') + '<h4>' + E(g.sec) + '</h4>' +
        '<span class="cnt">' + g.items.length + ' ítems</span></div>' + items + '</div>';
    }).join('');

    return '<div class="card card-pad" style="margin-bottom:16px;display:flex;gap:16px;flex-wrap:wrap;align-items:center">' +
        '<div class="avatar lg" style="border-radius:12px">' + I('truck') + '</div>' +
        '<div style="flex:1;min-width:180px"><div style="font-weight:650;font-size:15px">' + E(eq.codigo + ' · ' + eq.nombre) + '</div>' +
        '<div class="small muted">' + E(pl.nombre) + ' · ' + pl.items.length + ' ítems · ' + E(DB.fechaLarga(new Date().toISOString())) + '</div>' +
        '<div class="tiny muted" style="margin-top:4px"><b>B</b> = Bueno · <b>M</b> = Malo · <b>N/A</b> = No aplica</div></div>' +
        '<button type="button" class="btn btn-ghost btn-sm" data-act="bulk-si">' + I('check') + ' Marcar restantes como B (Bueno)</button>' +
      '</div>' + body +
      '<div class="form-foot">' +
        '<div class="progress"><div class="progress-bar"><span id="wiz-bar"></span></div>' +
        '<div class="progress-meta"><span id="wiz-count">0 de ' + pl.items.length + ' evaluados</span><span id="wiz-nc">0 con M (malo)</span></div></div>' +
        '<button type="button" class="btn btn-ghost" data-act="wiz-back">Atrás</button>' +
        '<button type="button" class="btn btn-primary" data-act="wiz-summary">Ver resumen ' + I('arrow') + '</button>' +
      '</div>';
  }

  function segBtn(val, label, current, titulo) {
    return '<button type="button" data-act="seg" data-val="' + val + '" title="' + E(titulo || label) + '" aria-label="' + E(titulo || label) + '" class="' + (current === val ? 'on' : '') + '">' + E(label) + '</button>';
  }

  function wizStep3() {
    var pl = DB.findPlantilla(WIZ.plantillaId);
    var eq = equipoById(WIZ.equipoId);
    var resp = pl.items.map(function (it) { return { valor: WIZ.respuestas[it.id] || 'na', crit: it.crit, txt: it.txt }; });
    var estado = DB.estadoDe(resp);
    var noConf = resp.filter(function (r) { return r.valor === 'no'; });
    var evalCount = resp.filter(function (r) { return r.valor !== 'na'; }).length;

    return '<div class="grid" style="grid-template-columns:1fr .85fr;gap:16px;align-items:start" id="wiz3">' +
      '<div>' +
        '<div class="card" style="margin-bottom:16px">' +
          '<div class="card-head"><h3>Resumen de la inspección</h3><div class="spacer"></div>' + UI.badge(estado) + '</div>' +
          '<div class="card-body">' +
            '<div class="grid grid-3" style="gap:10px;margin-bottom:16px">' +
              mini('Evaluados', evalCount, 'var(--info)') +
              mini('M · Malos', noConf.length, 'var(--bad)') +
              mini('Críticos', pl.items.filter(function (x) { return x.crit; }).length, 'var(--amber)') +
            '</div>' +
            '<dl class="dl">' +
              '<dt>Equipo</dt><dd>' + E(eq.codigo + ' · ' + eq.nombre) + '</dd>' +
              '<dt>Patente</dt><dd>' + E(WIZ.patente || eq.patente || '—') + '</dd>' +
              '<dt>Kilometraje</dt><dd>' + E(WIZ.kilometraje || '—') + '</dd>' +
              '<dt>Última mantención</dt><dd>' + E(fmtFecha(WIZ.ultimaMantencion)) + '</dd>' +
              '<dt>Próxima mantención</dt><dd>' + E(fmtFecha(WIZ.proximaMantencion)) + '</dd>' +
              '<dt>Plantilla</dt><dd>' + E(pl.nombre) + '</dd>' +
              '<dt>Operador</dt><dd>' + E(S.user.nombre) + ' · ' + E(S.user.rut) + '</dd>' +
              '<dt>Fecha y hora</dt><dd>' + E(DB.fechaLarga(new Date().toISOString())) + ' · ' + E(DB.hora(new Date().toISOString())) + '</dd>' +
            '</dl>' +
          '</div></div>' +
        (noConf.length ? '<div class="card" style="margin-bottom:16px;border-color:rgba(248,113,113,.28)">' +
          '<div class="card-head"><h3 style="color:#FCA5A5">Ítems marcados como M (Malo)</h3></div>' +
          '<div class="card-body" style="padding:8px 0">' + noConf.map(function (r) {
            return '<div class="res-row"><div class="st no">' + I('x') + '</div><div class="res-txt">' + E(r.txt) + '</div></div>';
          }).join('') + '</div></div>' : '') +
        '<div class="card"><div class="card-head"><h3>Observaciones generales</h3><div class="spacer"></div><span class="small muted">Opcional</span></div>' +
          '<div class="card-body"><textarea data-bind="observaciones" placeholder="Ej.: Se informa a mantenimiento, equipo queda fuera de servicio hasta cambio de cable." style="min-height:96px">' + E(WIZ.observaciones) + '</textarea></div></div>' +
      '</div>' +
      '<div>' +
        '<div class="card" style="margin-bottom:16px">' +
          '<div class="card-head"><h3>Firma del operador</h3><div class="spacer"></div><span class="small muted">Obligatoria</span></div>' +
          '<div class="card-body">' +
            '<div class="sig-wrap"><canvas id="sig-canvas"></canvas><div class="sig-hint">Firma con el dedo o el mouse</div></div>' +
            '<div class="sig-tools"><span class="tiny muted" id="sig-state">Sin firma</span>' +
              '<button type="button" class="btn btn-sm btn-ghost" data-act="sig-clear">' + I('refresh') + ' Limpiar</button></div>' +
          '</div></div>' +
        '<div class="card" style="margin-bottom:16px">' +
          '<div class="card-head"><h3>Confirmación por WhatsApp</h3><div class="spacer"></div>' + I('whatsapp') + '</div>' +
          '<div class="card-body">' +
            '<div class="field" style="margin-bottom:12px"><label for="wiz-phone">Teléfono del encuestado</label>' +
            '<input id="wiz-phone" data-bind="telefono" type="tel" value="' + E(WIZ.telefono || S.user.telefono) + '">' +
            '<span class="hint">Se enviará el mensaje con fecha, hora y resultado del checklist.</span></div>' +
            '<div class="wa-preview"><div class="wa-bubble" id="wiz-preview">' + E(previewMsg(eq, pl, resp, estado)) + '</div></div>' +
          '</div></div>' +
        '<div class="card card-pad">' +
          '<button type="button" class="btn btn-primary btn-block" data-act="guardar" style="height:46px">' + I('check') + ' Guardar checklist</button>' +
          '<div class="small muted" style="text-align:center;margin-top:10px">Después podrás enviar el mensaje de confirmación.</div>' +
        '</div>' +
      '</div></div>';
  }

  function mini(label, val, color) {
    return '<div style="background:#0E181E;border:1px solid var(--line);border-radius:10px;padding:10px 12px">' +
      '<div class="tiny muted" style="text-transform:uppercase;letter-spacing:.07em">' + E(label) + '</div>' +
      '<div style="font-size:20px;font-weight:700;color:' + color + '">' + val + '</div></div>';
  }

  function countResumen() {
    var pl = DB.findPlantilla(WIZ.plantillaId);
    if (!pl) return { answered: 0, total: 0, eval: 0, nc: 0 };
    var answered = 0, evalCount = 0, nc = 0;
    pl.items.forEach(function (it) {
      var v = WIZ.respuestas[it.id];
      if (v) answered++;
      if (v === 'si' || v === 'no') evalCount++;
      if (v === 'no') nc++;
    });
    return { answered: answered, total: pl.items.length, eval: evalCount, nc: nc };
  }

  function updateProgress() {
    var c = countResumen();
    var bar = document.getElementById('wiz-bar'), cnt = document.getElementById('wiz-count'), ncEl = document.getElementById('wiz-nc');
    if (bar) bar.style.width = (c.total ? Math.round(c.answered * 100 / c.total) : 0) + '%';
    if (cnt) cnt.textContent = c.answered + ' de ' + c.total + ' evaluados';
    if (ncEl) ncEl.textContent = c.nc + ' con M (malo)';
  }

  /* --------------------------- mensaje WhatsApp -------------------------- */
  function previewMsg(eq, pl, resp, estado) {
    return buildMsg({
      plantillaNombre: pl.nombre, equipoNombre: eq.nombre, equipoCodigo: eq.codigo,
      patente: WIZ.patente || eq.patente || '', kilometraje: WIZ.kilometraje,
      ultimaMantencion: WIZ.ultimaMantencion, proximaMantencion: WIZ.proximaMantencion,
      usuarioNombre: S.user.nombre, usuarioRut: S.user.rut, creado: new Date().toISOString(),
      estado: estado, respuestas: resp, observaciones: WIZ.observaciones, id: 'BORRADOR'
    });
  }

  function buildMsg(ins) {
    var st = DB.get().settings;
    var noConf = (ins.respuestas || []).filter(function (r) { return r.valor === 'no'; });
    var evaluados = (ins.respuestas || []).filter(function (r) { return r.valor !== 'na'; }).length;
    var obs = [];
    if (noConf.length) obs.push('Ítems con M (malo): ' + noConf.slice(0, 4).map(function (r) { return r.txt; }).join('; ') + (noConf.length > 4 ? ' (+' + (noConf.length - 4) + ')' : ''));
    if (ins.observaciones) obs.push('Obs.: ' + ins.observaciones);
    var map = {
      nombre: ins.usuarioNombre || '', checklist: ins.plantillaNombre || '', equipo: ins.equipoNombre || '',
      codigo: ins.equipoCodigo || '', fecha: DB.fechaLarga(ins.creado), fechaCorta: DB.fecha(ins.creado),
      hora: DB.hora(ins.creado), estado: ins.estado || '', evaluados: evaluados, noconformes: noConf.length,
      observaciones: obs.length ? obs.join('\n') : 'Sin observaciones.',
      patente: ins.patente || '', kilometraje: ins.kilometraje != null && ins.kilometraje !== '' ? String(ins.kilometraje) : '',
      ultimaMantencion: fmtFecha(ins.ultimaMantencion), proximaMantencion: fmtFecha(ins.proximaMantencion),
      id: ins.id === 'BORRADOR' ? 'BORRADOR' : codigoCorto(ins), empresa: st.empresa || '',
      proyecto: st.proyecto || '', rut: ins.usuarioRut || ''
    };
    var tpl = st.mensaje || 'Checklist {{checklist}} del equipo {{equipo}} ({{codigo}}) — patente {{patente}} — {{fecha}} {{hora}}. Resultado: {{estado}}.';
    return tpl.replace(/\{\{(\w+)\}\}/g, function (m, k) { return (map[k] !== undefined && map[k] !== null) ? String(map[k]) : m; });
  }

  function waLink(phone, msg) {
    return 'https://wa.me/' + DB.normPhone(phone) + '?text=' + encodeURIComponent(msg);
  }

  function abrirWhatsapp(ins, afterSend) {
    if (!ins) return;
    var phone = (ins.whatsapp && ins.whatsapp.destino) || ins.usuarioTelefono || '';
    var msg = buildMsg(ins);
    var enviado = ins.whatsapp && ins.whatsapp.enviado;

    var box = document.createElement('div');
    box.innerHTML =
      '<div class="field" style="margin-bottom:13px"><label for="wa-phone">Teléfono destino</label>' +
        '<input id="wa-phone" type="tel" value="' + E(DB.fmtPhone(phone)) + '">' +
        '<span class="hint">Formato internacional. Ej.: +56 9 1234 5678</span></div>' +
      '<div class="wa-preview"><div class="wa-bubble" id="wa-msg">' + E(msg) + '</div></div>' +
        '<div class="small muted" style="margin-top:10px">El mensaje de texto no adjunta archivos. Usa <b>Enviar PDF</b> para que la confirmación llegue como documento, con todos los datos del equipo.</div>' +
      '<div class="wa-meta">' + I('whatsapp') + ' Mensaje generado automáticamente con fecha, hora y resultado.' +
        (enviado ? ' <span class="badge badge-ok" style="margin-left:auto">Ya confirmado</span>' : '') + '</div>';

    UI.modal({
      title: 'Enviar confirmación por WhatsApp',
      subtitle: ins.equipoCodigo + ' · ' + DB.fechaHora(ins.creado),
      size: 'lg',
      body: box,
      actions: [
        { label: 'Copiar mensaje', className: 'btn-ghost', onClick: function () {
            UI.copyText($('#wa-msg').textContent).then(function (ok) { UI.toast(ok ? 'Mensaje copiado' : 'No se pudo copiar', ok ? 'ok' : 'err'); });
          } },
        { label: 'Abrir WhatsApp', className: 'btn-wa', onClick: function () {
            var tel = $('#wa-phone').value;
            if (DB.normPhone(tel).length < 11) { UI.toast('Revisa el teléfono ingresado', 'err'); return; }
            var link = waLink(tel, buildMsg(ins));
            var w = window.open(link, '_blank', 'noopener');
            if (!w) UI.toast('Permite las ventanas emergentes para abrir WhatsApp', 'err');
            var root = document.getElementById('modal-root');
            var foot = root ? root.querySelector('.modal-foot') : null;
            if (foot && !foot.querySelector('[data-confirm-send]')) {
              var b = document.createElement('button');
              b.type = 'button'; b.className = 'btn btn-primary'; b.setAttribute('data-confirm-send', '1');
              b.textContent = 'Ya envié el mensaje';
              b.addEventListener('click', function () {
                DB.marcarWhatsapp(ins.id, { destino: DB.normPhone(tel), mensaje: buildMsg(ins) });
                UI.closeModal();
                UI.toast('Envío confirmado y registrado');
                if (afterSend) afterSend(); else renderView();
              });
              foot.appendChild(b);
            }
          } },
        { label: 'Enviar PDF', className: 'btn-wa', onClick: function () {
            enviarPdfWhatsapp(ins, $('#wa-phone').value);
          } },
        { label: 'Cerrar', className: 'btn-ghost', onClick: function () { UI.closeModal(); } }
      ]
    });
  }

  /* ------------------------------ historial ------------------------------ */

  function descargarPdf(ins) {
    if (!ins) return;
    if (!window.API || !API.sesion()) { UI.toast('Conecta la base compartida para generar el PDF', 'err'); return; }
    UI.toast('Generando PDF…');
    API.descargarPdf(ins.id).then(function () {
      UI.toast('PDF descargado');
    }).catch(function (e) {
      UI.toast((e && e.message) || 'No se pudo generar el PDF', 'err');
    });
  }

  function enviarPdfWhatsapp(ins, telefono) {
    if (!ins) return;
    if (!window.API || !API.sesion()) { UI.toast('Conecta la base compartida para enviar el PDF automáticamente', 'err'); return; }
    var destino = DB.normPhone(telefono);
    if (destino.length < 11) { UI.toast('Revisa el teléfono ingresado', 'err'); return; }
    UI.toast('Enviando PDF por WhatsApp…');
    API.enviarPdf(ins.id, telefono).then(function () {
      DB.marcarWhatsapp(ins.id, { destino: destino, mensaje: buildMsg(ins), pdf: true });
      UI.closeModal();
      UI.toast('Confirmación en PDF enviada por WhatsApp');
      renderView();
    }).catch(function (e) {
      UI.toast((e && e.message) || 'No se pudo enviar el PDF. Revisa la configuración de WhatsApp del servidor.', 'err');
    });
  }
  function histFiltradas() {
    var list = visibles();
    if (HIST.estado) list = list.filter(function (i) { return i.estado === HIST.estado; });
    if (HIST.desde) { var d1 = new Date(HIST.desde + 'T00:00:00').getTime(); list = list.filter(function (i) { return new Date(i.creado).getTime() >= d1; }); }
    if (HIST.hasta) { var d2 = new Date(HIST.hasta + 'T23:59:59').getTime(); list = list.filter(function (i) { return new Date(i.creado).getTime() <= d2; }); }
    if (HIST.q) {
      var q = HIST.q.toLowerCase();
      list = list.filter(function (i) {
        return (i.equipoCodigo + ' ' + i.equipoNombre + ' ' + i.plantillaNombre + ' ' + i.usuarioNombre + ' ' + i.usuarioRut).toLowerCase().indexOf(q) >= 0;
      });
    }
    return list;
  }

  function viewHistorial() {
    return pageHead(
        '<button type="button" class="btn btn-ghost" data-act="export">' + I('download') + ' Exportar Excel</button>' +
        '<button type="button" class="btn btn-primary" data-act="nav" data-view="nuevo">' + I('plus') + ' Nuevo checklist</button>'
      ) +
      '<div class="card">' +
        '<div class="card-head" style="gap:10px;flex-wrap:wrap">' +
          '<div class="search">' + I('search') + '<input id="hist-q" type="search" placeholder="Buscar por equipo, código, operador o RUT" value="' + E(HIST.q) + '"></div>' +
          '<select id="hist-estado" style="width:auto;min-width:150px">' +
            '<option value="">Todos los estados</option>' +
            optEst('Aprobado') + optEst('Con observaciones') + optEst('Rechazado') +
          '</select>' +
          '<input id="hist-desde" type="date" value="' + E(HIST.desde) + '" style="width:auto" title="Desde">' +
          '<input id="hist-hasta" type="date" value="' + E(HIST.hasta) + '" style="width:auto" title="Hasta">' +
          '<div class="spacer" style="flex:1"></div>' +
          '<span class="chip" id="hist-count">' + histFiltradas().length + ' registros</span>' +
        '</div>' +
        '<div class="table-wrap" id="hist-table">' + histRows() + '</div>' +
      '</div>';
  }

  function optEst(v) { return '<option value="' + E(v) + '"' + (HIST.estado === v ? ' selected' : '') + '>' + E(v) + '</option>'; }

  function histRows() {
    var list = histFiltradas();
    if (!list.length) return UI.empty('No hay checklists que coincidan', 'Ajusta los filtros o registra un nuevo checklist.');
    return '<table><thead><tr>' +
        '<th>Fecha / hora</th><th>Equipo</th><th>Checklist</th><th>Operador</th><th>Estado</th><th>WhatsApp</th><th></th>' +
      '</tr></thead><tbody>' +
      list.map(function (i) {
        var wa = i.whatsapp && i.whatsapp.enviado
          ? '<span class="badge badge-ok">' + I('check') + ' Confirmado</span>'
          : '<span class="badge badge-warn">Pendiente</span>';
        return '<tr class="clickable" data-act="ver" data-id="' + E(i.id) + '">' +
          '<td class="t-nowrap"><div class="t-strong mono">' + E(DB.fecha(i.creado)) + '</div><div class="t-sub mono">' + E(DB.hora(i.creado)) + '</div></td>' +
          '<td><div class="t-strong">' + E(i.equipoCodigo) + '</div><div class="t-sub">' + E(i.equipoNombre) + '</div></td>' +
          '<td><div style="max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + E(i.plantillaNombre) + '</div>' +
            '<div class="t-sub">' + i.respuestas.length + ' ítems · ' + i.respuestas.filter(function (r) { return r.crit; }).length + ' críticos</div></td>' +
          '<td><div>' + E(i.usuarioNombre) + '</div><div class="t-sub">' + E(i.usuarioRut || '') + '</div></td>' +
          '<td>' + UI.badge(i.estado) + '</td>' +
          '<td>' + wa + '</td>' +
          '<td class="t-right"><div class="cell-actions">' +
            '<button type="button" class="icon-btn" data-act="ver" data-id="' + E(i.id) + '" aria-label="Ver">' + I('eye') + '</button>' +
            '<button type="button" class="icon-btn" data-act="wa" data-id="' + E(i.id) + '" aria-label="WhatsApp">' + I('whatsapp') + '</button>' +
          '</div></td></tr>';
      }).join('') + '</tbody></table>';
  }

  function afterView(host) {
    var q = $('#hist-q', host);
    if (q) {
      var t = null;
      q.addEventListener('input', function () {
        clearTimeout(t);
        t = setTimeout(function () { HIST.q = q.value; refreshHist(); }, 220);
      });
    }
    var es = $('#hist-estado', host);
    if (es) es.addEventListener('change', function () { HIST.estado = es.value; refreshHist(); });
    var d1 = $('#hist-desde', host);
    if (d1) d1.addEventListener('change', function () { HIST.desde = d1.value; refreshHist(); });
    var d2 = $('#hist-hasta', host);
    if (d2) d2.addEventListener('change', function () { HIST.hasta = d2.value; refreshHist(); });
  }

  function refreshHist() {
    var t = document.getElementById('hist-table');
    if (t) t.innerHTML = histRows();
    var c = document.getElementById('hist-count');
    if (c) c.textContent = histFiltradas().length + ' registros';
  }

  /* ------------------------------- detalle ------------------------------- */
  function viewInsp() {
    var ins = DB.findInspeccion(S.params.id);
    if (!ins) return pageHead('') + UI.empty('Registro no encontrado', 'Puede haber sido eliminado.');
    if (S.user.rol === 'operador' && ins.usuarioId !== S.user.id) return UI.empty('Sin acceso', 'Este registro pertenece a otro operador.');

    var nc = ins.respuestas.filter(function (r) { return r.valor === 'no'; });
    var na = ins.respuestas.filter(function (r) { return r.valor === 'na'; });
    var si = ins.respuestas.filter(function (r) { return r.valor === 'si'; });
    var wa = ins.whatsapp || {};

    var secs = groupItems(ins.respuestas).map(function (g) {
      return '<div class="res-sec">' + E(g.sec) + '</div>' + g.items.map(function (r) {
        var cls = r.valor === 'si' ? 'si' : (r.valor === 'no' ? 'no' : 'na');
        var ico = r.valor === 'si' ? 'check' : (r.valor === 'no' ? 'x' : 'minus');
        return '<div class="res-row"><div class="st ' + cls + '">' + I(ico) + '</div><div class="res-txt">' +
          (r.crit ? '<span class="tiny" style="color:var(--amber);font-weight:800">CRÍTICO · </span>' : '') + E(r.txt) +
          (r.obs ? '<div class="res-obs">' + E(r.obs) + '</div>' : '') + '</div>' +
          '<span class="tiny muted">' + (r.valor === 'si' ? 'B · Bueno' : r.valor === 'no' ? 'M · Malo' : 'N/A') + '</span></div>';
      }).join('');
    }).join('');

    return pageHead(
        '<button type="button" class="btn btn-ghost" data-act="nav" data-view="historial">Atrás</button>' +
        '<button type="button" class="btn btn-ghost" data-act="print">' + I('print') + ' Imprimir</button>' +
        '<button type="button" class="btn btn-ghost" data-act="pdf" data-id="' + E(ins.id) + '">' + I('download') + ' PDF</button>' +
        (isAdmin() ? '<button type="button" class="btn btn-danger" data-act="del-insp" data-id="' + E(ins.id) + '">' + I('trash') + '</button>' : '') +
        '<button type="button" class="btn btn-wa" data-act="wa" data-id="' + E(ins.id) + '">' + I('whatsapp') + ' ' + (wa.enviado ? 'Reenviar' : 'Enviar confirmación') + '</button>'
      ) +
      '<div class="ficha-grid">' +
        '<div>' +
          '<div class="card" style="margin-bottom:16px">' +
            '<div class="card-head"><div><h3>' + E(ins.plantillaNombre) + '</h3>' +
              '<div class="small muted" style="margin-top:2px">Registro ' + E(codigoCorto(ins)) + ' · ' + E(DB.fechaLarga(ins.creado)) + ' · ' + E(DB.hora(ins.creado)) + '</div></div>' +
              '<div class="spacer"></div>' + UI.badge(ins.estado) + '</div>' +
            '<div class="card-body"><dl class="dl">' +
              '<dt>Equipo</dt><dd>' + E(ins.equipoCodigo + ' · ' + ins.equipoNombre) + '</dd>' +
              '<dt>Patente</dt><dd>' + E(ins.patente || '—') + '</dd>' +
              '<dt>Kilometraje</dt><dd>' + E(ins.kilometraje != null && ins.kilometraje !== '' ? String(ins.kilometraje) : '—') + '</dd>' +
              '<dt>Última mantención</dt><dd>' + E(fmtFecha(ins.ultimaMantencion)) + '</dd>' +
              '<dt>Próxima mantención</dt><dd>' + E(fmtFecha(ins.proximaMantencion)) + '</dd>' +
              '<dt>Operador</dt><dd>' + E(ins.usuarioNombre) + '</dd>' +
              '<dt>RUT</dt><dd>' + E(ins.usuarioRut || '—') + '</dd>' +
              '<dt>Teléfono</dt><dd>' + E(ins.usuarioTelefono || '—') + '</dd>' +
              '<dt>Observaciones</dt><dd>' + E(ins.observaciones || 'Sin observaciones.') + '</dd>' +
            '</dl>' +
            '<div class="grid grid-3" style="gap:10px;margin-top:16px">' +
              mini('B · Buenos', si.length, 'var(--ok)') + mini('M · Malos', nc.length, 'var(--bad)') + mini('N/A', na.length, 'var(--muted)') +
            '</div></div></div>' +
          '<div class="card">' +
            '<div class="card-head"><h3>Detalle de la inspección</h3><div class="spacer"></div><span class="chip">' + ins.respuestas.length + ' ítems</span></div>' +
            '<div>' + secs + '</div></div>' +
        '</div>' +
        '<div>' +
          '<div class="card" style="margin-bottom:16px">' +
            '<div class="card-head"><h3>Confirmación por WhatsApp</h3></div>' +
            '<div class="card-body">' +
              (wa.enviado ? '<div class="badge badge-ok" style="margin-bottom:10px">' + I('check') + ' Enviado el ' + E(DB.fechaHora(wa.fechaEnvio)) + '</div>' : '<div class="badge badge-warn" style="margin-bottom:10px">Sin confirmar</div>') +
              '<div class="small muted" style="margin-bottom:6px">Destino</div>' +
              '<div style="font-weight:600;margin-bottom:12px">' + E(DB.fmtPhone(wa.destino || ins.usuarioTelefono || '')) + '</div>' +
              '<div class="wa-preview"><div class="wa-bubble" style="max-height:190px">' + E(buildMsg(ins)) + '</div></div>' +
            '</div></div>' +
          '<div class="card">' +
            '<div class="card-head"><h3>Firma</h3></div>' +
            '<div class="card-body">' +
              (ins.firma ? '<img src="' + E(ins.firma) + '" alt="Firma del operador" style="width:100%;border-radius:10px;background:#0B141A;border:1px solid var(--line)">' : '<div class="small muted">Sin firma registrada.</div>') +
              '<div class="small muted" style="margin-top:10px">' + E(ins.usuarioNombre) + ' · ' + E(ins.usuarioRut || '') + '</div>' +
            '</div></div>' +
        '</div>' +
      '</div>';
  }

  /* ------------------------------- usuarios ------------------------------ */
  function viewUsuarios() {
    var us = DB.users();
    var eqs = DB.equipos();
    function eqName(id) { var e = eqs.filter(function (x) { return x.id === id; })[0]; return e ? e.codigo : ''; }

    return pageHead(
        '<button type="button" class="btn btn-ghost" data-act="user-export">' + I('download') + ' Exportar</button>' +
        '<button type="button" class="btn btn-primary" data-act="user-new">' + I('plus') + ' Nuevo usuario</button>'
      ) +
      '<div class="grid grid-4" style="margin-bottom:16px">' +
        kpi('Usuarios activos', us.filter(function (u) { return u.activo; }).length, us.length + ' en total', 'users', '') +
        kpi('Administradores', us.filter(function (u) { return u.rol === 'admin'; }).length, 'Acceso total al sistema', 'shield', 'b') +
        kpi('Supervisores', us.filter(function (u) { return u.rol === 'supervisor'; }).length, 'Gestión de equipos', 'eye', 'g') +
        kpi('Operadores', us.filter(function (u) { return u.rol === 'operador'; }).length, 'Ejecutan checklists', 'truck', '') +
      '</div>' +
      '<div class="card"><div class="table-wrap"><table><thead><tr>' +
        '<th>Usuario</th><th>RUT</th><th>Contacto</th><th>Rol</th><th>Equipos asignados</th><th>Estado</th><th></th>' +
      '</tr></thead><tbody>' +
      us.map(function (u) {
        var rol = u.rol === 'admin' ? 'badge-info' : (u.rol === 'supervisor' ? 'badge-warn' : 'badge-mute');
        var rolTxt = u.rol === 'admin' ? 'Administrador' : (u.rol === 'supervisor' ? 'Supervisor' : 'Operador');
        var chips = (u.equipos || []).map(function (id) { return '<span class="chip" style="font-size:10.6px;padding:2px 7px">' + E(eqName(id)) + '</span>'; }).join(' ');
        return '<tr>' +
          '<td><div class="row-avatar"><div class="avatar">' + E(UI.initials(u.nombre)) + '</div>' +
            '<div style="min-width:0"><div class="t-strong">' + E(u.nombre) + '</div><div class="t-sub">' + E(u.cargo || '—') + '</div></div></div></td>' +
          '<td class="mono t-nowrap">' + E(u.rut) + '</td>' +
          '<td><div style="font-size:12.6px">' + E(u.email) + '</div><div class="t-sub">' + E(u.telefono) + '</div></td>' +
          '<td><span class="badge ' + rol + '">' + E(rolTxt) + '</span></td>' +
          '<td>' + (chips || '<span class="tiny muted">Sin asignar</span>') + '</td>' +
          '<td>' + (u.activo ? '<span class="badge badge-ok">Activo</span>' : '<span class="badge badge-bad">Inactivo</span>') + '</td>' +
          '<td class="t-right"><div class="cell-actions">' +
            '<button type="button" class="icon-btn" data-act="user-edit" data-id="' + E(u.id) + '" aria-label="Editar">' + I('edit') + '</button>' +
            '<button type="button" class="icon-btn" data-act="user-pass" data-id="' + E(u.id) + '" aria-label="Restablecer contraseña">' + I('refresh') + '</button>' +
            '<button type="button" class="icon-btn" data-act="user-toggle" data-id="' + E(u.id) + '" aria-label="Activar/desactivar">' + I(u.activo ? 'x' : 'check') + '</button>' +
            '<button type="button" class="icon-btn danger" data-act="user-del" data-id="' + E(u.id) + '" aria-label="Eliminar">' + I('trash') + '</button>' +
          '</div></td></tr>';
      }).join('') + '</tbody></table></div></div>';
  }

  function userForm(id) {
    var u = id ? DB.findUser(id) : null;
    var eqs = DB.equipos();
    var body =
      '<div class="form-row c2">' +
        fieldText('u-nombre', 'Nombre completo', u ? u.nombre : '', 'Ej.: Juan Pérez Morales', 'text', true) +
        fieldText('u-rut', 'RUT', u ? u.rut : '', '12.345.678-9', 'text', true) +
      '</div>' +
      '<div class="form-row c2" style="margin-top:13px">' +
        fieldText('u-email', 'Correo electrónico', u ? u.email : '', 'nombre@empresa.cl', 'email', true) +
        fieldText('u-tel', 'Teléfono celular', u ? u.telefono : '+56 9 ', '+56 9 1234 5678', 'tel', true) +
      '</div>' +
      '<div class="form-row c2" style="margin-top:13px">' +
        '<div class="field"><label for="u-rol">Rol / permisos</label><select id="u-rol">' +
          (S.user.rol === 'admin' ? ['operador', 'supervisor', 'admin'] : ['operador', 'supervisor']).map(function (r) {
            var lbl = r === 'admin' ? 'Administrador (acceso total)' : (r === 'supervisor' ? 'Supervisor' : 'Operador');
            return '<option value="' + r + '"' + (u && u.rol === r ? ' selected' : (!u && r === 'operador' ? ' selected' : '')) + '>' + lbl + '</option>';
          }).join('') + '</select></div>' +
        fieldText('u-cargo', 'Cargo', u ? (u.cargo || '') : '', 'Ej.: Operador de equipos', 'text', false) +
      '</div>' +
      '<div class="form-sep"></div>' +
      '<div class="field"><label>Equipos que puede operar</label>' +
        '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:7px;margin-top:2px">' +
        (eqs.length ? eqs.map(function (e) {
          var on = u ? (u.equipos || []).indexOf(e.id) >= 0 : false;
          return '<label class="check-inline" style="background:#0E181E;border:1px solid var(--line);padding:8px 10px;border-radius:8px">' +
            '<input type="checkbox" class="u-eq" value="' + E(e.id) + '"' + (on ? ' checked' : '') + '>' +
            '<span><b style="font-size:12px">' + E(e.codigo) + '</b> · ' + E(e.tipo) + '</span></label>';
        }).join('') : '<span class="small muted">Sin equipos en el catálogo.</span>') + '</div>' +
        '<span class="hint">El operador solo verá los equipos que le asignes.</span></div>' +
      '<div class="form-sep"></div>' +
      (u ? '' : fieldText('u-pass', 'Contraseña inicial', '', 'Déjala vacía para generar una automática', 'text', false)) +
      '<label class="check-inline" style="margin-top:' + (u ? '0' : '13px') + '"><input type="checkbox" id="u-activo"' + (!u || u.activo ? ' checked' : '') + '> Usuario activo (puede iniciar sesión)</label>';

    return UI.modal({
      title: u ? 'Editar usuario' : 'Nuevo usuario',
      subtitle: u ? 'Actualiza los datos de acceso y los equipos asignados.' : 'Crea la cuenta con RUT, correo, celular y equipo a operar.',
      size: 'lg', body: body,
      actions: [
        { label: 'Cancelar', className: 'btn-ghost', onClick: function () { UI.closeModal(); } },
        { label: u ? 'Guardar cambios' : 'Crear usuario', className: 'btn-primary', onClick: function () { saveUserForm(id); } }
      ]
    });
  }

  function fieldText(id, label, val, ph, type, req) {
    return '<div class="field" data-f="' + id + '"><label for="' + id + '">' + E(label) + (req ? ' *' : '') + '</label>' +
      '<input id="' + id + '" type="' + (type || 'text') + '" value="' + E(val) + '" placeholder="' + E(ph) + '">' +
      '<span class="err"></span></div>';
  }

  function markInvalid(id, msg) {
    var f = document.querySelector('[data-f="' + id + '"]');
    if (!f) return;
    f.classList.add('invalid');
    var e = f.querySelector('.err');
    if (e) e.textContent = msg;
  }

  function saveUserForm(id) {
    $$('.field.invalid').forEach(function (f) { f.classList.remove('invalid'); });
    var nombre = $('#u-nombre').value.trim();
    var rut = $('#u-rut').value.trim();
    var email = $('#u-email').value.trim();
    var tel = $('#u-tel').value.trim();
    var rol = $('#u-rol').value;
    var cargo = $('#u-cargo').value.trim();
    var passEl = $('#u-pass');
    var pass = passEl ? passEl.value : '';
    var equipos = $$('.u-eq').filter(function (c) { return c.checked; }).map(function (c) { return c.value; });
    var activo = $('#u-activo').checked;
    var bad = false;

    if (nombre.length < 5) { markInvalid('u-nombre', 'Ingresa nombre y apellido.'); bad = true; }
    if (!DB.validaRut(rut)) { markInvalid('u-rut', 'RUT inválido. Verifica el dígito verificador.'); bad = true; }
    else {
      var dup = DB.users().filter(function (x) { return DB.limpiarRut(x.rut) === DB.limpiarRut(rut) && x.id !== id; })[0];
      if (dup) { markInvalid('u-rut', 'Ese RUT ya está registrado (' + dup.nombre + ').'); bad = true; }
    }
    if (!UI.emailOk(email)) { markInvalid('u-email', 'Correo no válido.'); bad = true; }
    else if (DB.emailTaken(email, id)) { markInvalid('u-email', 'Ese correo ya tiene una cuenta.'); bad = true; }
    if (DB.normPhone(tel).length < 11) { markInvalid('u-tel', 'Ingresa un celular válido, ej.: +56 9 1234 5678.'); bad = true; }
    if (rol === 'operador' && !equipos.length) { UI.toast('Asigna al menos un equipo al operador', 'err'); bad = true; }
    if (bad) return;

    var data = { nombre: nombre, rut: rut, email: email, telefono: tel, rol: rol, cargo: cargo, equipos: equipos, activo: activo, password: pass };
    if (rol === 'admin' && !isAdmin()) { UI.toast('Solo un administrador puede crear o modificar administradores', 'err'); return; }
    var r = id ? DB.saveUser(data, id) : DB.saveUser(data);
    if (!r.ok) { UI.toast(r.error, 'err'); return; }
    if (window.API && API.registrarClave) API.registrarClave(r.user.email, pass || r.tempPass);
    UI.closeModal();
    UI.toast(id ? 'Usuario actualizado' : 'Usuario creado correctamente');
    renderView();
    if (!id) setTimeout(function () { showCredentials(r.user, r.tempPass); }, 250);
  }

  function showCredentials(u, pass) {
    var eqs = DB.equipos();
    var nombres = (u.equipos || []).map(function (id) { var e = eqs.filter(function (x) { return x.id === id; })[0]; return e ? e.codigo : ''; }).join(', ');
    var url = location.href.split('#')[0];
    var msg = 'Hola ' + u.nombre + ', se creó tu acceso a Check List Maquinarias ENTS.\n\n' +
      'Usuario: ' + u.email + '\nContraseña temporal: ' + pass + '\nRUT: ' + u.rut +
      (nombres ? '\nEquipo(s): ' + nombres : '') + '\n\nIngresa aquí: ' + url +
      '\n\nPor seguridad, cambia tu contraseña al ingresar.';

    var body = '<div class="card card-pad" style="margin-bottom:14px;background:rgba(255,176,32,.06);border-color:rgba(255,176,32,.25)">' +
      '<div class="small muted" style="margin-bottom:4px">Contraseña temporal</div>' +
      '<div class="mono" style="font-size:22px;font-weight:700;letter-spacing:.04em">' + E(pass) + '</div>' +
      '<div class="tiny muted" style="margin-top:6px">Se muestra una sola vez. También puedes enviarla por WhatsApp.</div></div>' +
      '<div class="dl"><dt>Nombre</dt><dd>' + E(u.nombre) + '</dd><dt>RUT</dt><dd>' + E(u.rut) + '</dd>' +
      '<dt>Correo</dt><dd>' + E(u.email) + '</dd><dt>Celular</dt><dd>' + E(u.telefono) + '</dd>' +
      '<dt>Rol</dt><dd>' + E(u.rol === 'admin' ? 'Administrador' : u.rol === 'supervisor' ? 'Supervisor' : 'Operador') + '</dd>' +
      '<dt>Equipos</dt><dd>' + E(nombres || 'Sin asignar') + '</dd></div>';

    UI.modal({
      title: 'Usuario creado', subtitle: 'Comparte estas credenciales con ' + u.nombre.split(' ')[0] + '.', size: 'lg', body: body,
      actions: [
        { label: 'Copiar', className: 'btn-ghost', onClick: function () { UI.copyText(msg).then(function (ok) { UI.toast(ok ? 'Credenciales copiadas' : 'No se pudo copiar', ok ? 'ok' : 'err'); }); } },
        { label: 'Enviar por WhatsApp', className: 'btn-wa', onClick: function () {
            window.open(waLink(u.telefono, msg), '_blank', 'noopener');
            UI.toast('Abriendo WhatsApp…');
          } },
        { label: 'Listo', className: 'btn-primary', onClick: function () { UI.closeModal(); } }
      ]
    });
  }

  function resetPass(id) {
    var u = DB.findUser(id);
    if (!u) return;
    var pass = DB.tempPassword();
    DB.setPassword(id, pass);
    UI.toast('Contraseña restablecida');
    showCredentials(u, pass);
  }

  /* -------------------------------- equipos ------------------------------ */
  function viewEquipos() {
    var eqs = DB.equipos();
    var ins = DB.inspecciones();
    return pageHead('<button type="button" class="btn btn-primary" data-act="eq-new">' + I('plus') + ' Agregar equipo</button>') +
      '<div class="card"><div class="table-wrap"><table><thead><tr>' +
        '<th>Código</th><th>Equipo</th><th>Tipo</th><th>Marca / modelo</th><th>Faena</th><th>Última inspección</th><th>Estado</th><th></th>' +
      '</tr></thead><tbody>' +
      (eqs.length ? eqs.map(function (e) {
        var last = null;
        for (var i = 0; i < ins.length; i++) if (ins[i].equipoId === e.id) { last = ins[i]; break; }
        return '<tr>' +
          '<td><span class="badge badge-mute mono">' + E(e.codigo) + '</span></td>' +
          '<td class="t-strong">' + E(e.nombre) + '</td>' +
          '<td>' + E(e.tipo) + '</td>' +
          '<td><div style="font-size:12.6px">' + E([e.marca, e.modelo].filter(Boolean).join(' ')) + '</div><div class="t-sub">' + E(e.patente || '') + '</div></td>' +
          '<td>' + E(e.faena || '—') + '</td>' +
          '<td>' + (last ? '<div style="font-size:12.6px">' + E(DB.fechaHora(last.creado)) + '</div>' + UI.badge(last.estado) : '<span class="tiny muted">Sin registros</span>') + '</td>' +
          '<td>' + (e.activo ? '<span class="badge badge-ok">Activo</span>' : '<span class="badge badge-bad">Inactivo</span>') + '</td>' +
          '<td class="t-right"><div class="cell-actions">' +
            '<button type="button" class="icon-btn" data-act="eq-edit" data-id="' + E(e.id) + '" aria-label="Editar">' + I('edit') + '</button>' +
            '<button type="button" class="icon-btn danger" data-act="eq-del" data-id="' + E(e.id) + '" aria-label="Eliminar">' + I('trash') + '</button>' +
          '</div></td></tr>';
      }).join('') : '<tr><td colspan="8">' + UI.empty('Sin equipos', 'Agrega el primer equipo al catálogo.') + '</td></tr>') +
      '</tbody></table></div></div>';
  }

  function equipoForm(id) {
    var e = id ? equipoById(id) : null;
    var tipos = DB.tipos().concat(['Otro']);
    var body = '<div class="form-row c2">' +
        fieldText('e-codigo', 'Código interno', e ? e.codigo : '', 'CAM-001', 'text', true) +
        fieldText('e-nombre', 'Nombre del equipo', e ? e.nombre : '', 'Camión Pluma 8 t', 'text', true) +
      '</div><div class="form-row c2" style="margin-top:13px">' +
        '<div class="field"><label for="e-tipo">Tipo de equipo</label><select id="e-tipo">' +
          tipos.map(function (t) { return '<option value="' + E(t) + '"' + (e && e.tipo === t ? ' selected' : '') + '>' + E(t) + '</option>'; }).join('') +
        '</select></div>' + fieldText('e-faena', 'Faena / ubicación', e ? e.faena : 'Escondida', 'Escondida', 'text', false) +
      '</div><div class="form-row c3" style="margin-top:13px">' +
        fieldText('e-marca', 'Marca', e ? e.marca : '', 'Hyundai', 'text', false) +
        fieldText('e-modelo', 'Modelo', e ? e.modelo : '', 'HD-270', 'text', false) +
        fieldText('e-patente', 'Patente / N° serie', e ? e.patente : '', 'LJ-PR-42', 'text', false) +
      '</div><div class="form-row c3" style="margin-top:13px">' +
        fieldText('e-km', 'Kilometraje u horómetro', e && e.kilometraje != null ? String(e.kilometraje) : '', '128450', 'number', false) +
        fieldText('e-um', 'Última mantención', e ? (e.ultimaMantencion || '') : '', '', 'date', false) +
        fieldText('e-pm', 'Próxima mantención', e ? (e.proximaMantencion || '') : '', '', 'date', false) +
      '</div><div class="form-sep"></div>' +
      '<label class="check-inline"><input type="checkbox" id="e-activo"' + (!e || e.activo ? ' checked' : '') + '> Equipo activo</label>';

    UI.modal({
      title: e ? 'Editar equipo' : 'Agregar equipo',
      subtitle: 'Los datos se usan en la cabecera del checklist, en el PDF y en el mensaje de WhatsApp.',
      size: 'lg', body: body,
      actions: [
        { label: 'Cancelar', className: 'btn-ghost', onClick: function () { UI.closeModal(); } },
        { label: 'Guardar', className: 'btn-primary', onClick: function () {
            var data = {
              codigo: $('#e-codigo').value.trim().toUpperCase(), nombre: $('#e-nombre').value.trim(),
              tipo: $('#e-tipo').value, faena: $('#e-faena').value.trim(), marca: $('#e-marca').value.trim(),
              modelo: $('#e-modelo').value.trim(), patente: $('#e-patente').value.trim().toUpperCase(),
              kilometraje: $('#e-km').value === '' ? '' : Number($('#e-km').value),
              ultimaMantencion: $('#e-um').value, proximaMantencion: $('#e-pm').value,
              activo: $('#e-activo').checked
            };
            if (!data.codigo || !data.nombre) { UI.toast('Código y nombre son obligatorios', 'err'); return; }
            DB.saveEquipo(data, id);
            UI.closeModal(); UI.toast(e ? 'Equipo actualizado' : 'Equipo agregado'); renderView();
          } }
      ]
    });
  }

  /* ------------------------------- plantillas ---------------------------- */
  function viewPlantillas() {
    var pls = DB.plantillas();
    var tipos = DB.tipos();
    var filtro = PL_FILTRO;
    var visibles = filtro ? pls.filter(function (p) { return p.tipo === filtro; }) : pls;
    var totalItems = visibles.reduce(function (a, p) { return a + p.items.length; }, 0);

    function tarjeta(p) {
      return '<div class="card">' +
        '<div class="card-head"><div><h3>' + E(p.nombre) + '</h3><div class="small muted" style="margin-top:2px">' + E(p.tipo || 'General') + ' · ' + E(p.frecuencia || 'Diario') + '</div></div>' +
          '<div class="spacer"></div><span class="chip">' + p.items.length + ' ítems</span></div>' +
        '<div class="card-body">' +
          '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">' +
            (p.items.filter(function (x) { return x.crit; }).length ? '<span class="badge badge-warn">' + p.items.filter(function (x) { return x.crit; }).length + ' críticos</span>' : '') +
            '<span class="badge badge-mute">' + groupItems(p.items).length + ' secciones</span>' +
            '<span class="badge badge-info">' + E(p.fuente || 'Manual') + '</span></div>' +
          '<div class="small muted" style="height:44px;overflow:hidden">' + E(p.items.slice(0, 2).map(function (x) { return x.txt; }).join(' · ')) + '…</div>' +
          '<div style="display:flex;gap:8px;margin-top:12px">' +
            '<button type="button" class="btn btn-ghost btn-sm" data-act="pl-view" data-id="' + E(p.id) + '">' + I('eye') + ' Ver ítems</button>' +
            (isSuper() ? '<button type="button" class="btn btn-ghost btn-sm" data-act="pl-edit" data-id="' + E(p.id) + '">' + I('edit') + ' Modificar</button>' : '') +
            '<button type="button" class="btn btn-ghost btn-sm" data-act="pl-export" data-id="' + E(p.id) + '">' + I('download') + ' Excel</button>' +
            '<div style="flex:1"></div>' +
            '<button type="button" class="icon-btn danger" data-act="pl-del" data-id="' + E(p.id) + '" aria-label="Eliminar">' + I('trash') + '</button>' +
          '</div></div></div>';
    }

    var cuerpo;
    if (!visibles.length) {
      cuerpo = UI.empty('Sin checklists para este tipo', 'Sube un archivo Excel o elige otro tipo de maquinaria.');
    } else if (filtro) {
      cuerpo = '<div class="grid grid-2">' + visibles.map(tarjeta).join('') + '</div>';
    } else {
      cuerpo = tipos.map(function (t) {
        var g = pls.filter(function (p) { return p.tipo === t; });
        if (!g.length) return '';
        var n = g.reduce(function (a, p) { return a + p.items.length; }, 0);
        return '<div class="chk-sec-head" style="margin:22px 0 10px;display:flex;align-items:center;gap:10px">' + I('truck') +
          '<h4 style="margin:0">' + E(t) + '</h4><span class="cnt">' + g.length + ' checklist · ' + n + ' ítems</span></div>' +
          '<div class="grid grid-2">' + g.map(tarjeta).join('') + '</div>';
      }).join('');
    }

    return pageHead(
        '<button type="button" class="btn btn-ghost" data-act="pl-model">' + I('download') + ' Descargar formato Excel</button>' +
        '<button type="button" class="btn btn-ghost" data-act="pl-new">' + I('plus') + ' Nuevo check list</button>' +
        '<button type="button" class="btn btn-primary" data-act="pl-upload">' + I('upload') + ' Subir checklist Excel</button>'
      ) +
      '<div class="card card-pad" style="margin-bottom:16px;display:flex;gap:14px;align-items:flex-start;border-color:rgba(96,165,250,.22);background:linear-gradient(100deg,rgba(96,165,250,.07),transparent)">' +
        '<div class="act-dot" style="background:rgba(96,165,250,.14);color:var(--info);width:34px;height:34px;border-radius:9px;flex:none">' + I('file') + '</div>' +
        '<div class="small"><strong style="color:#DBEAFE">¿Cómo subir tu checklist?</strong><br>' +
        'El archivo debe tener una fila de encabezados con las columnas <b>Sección</b>, <b>Ítem</b>, <b>Criterio de aceptación</b> y <b>Crítico</b> (Sí/No). ' +
        'Cada fila se convierte en un punto a inspeccionar. Acepta .xlsx, .xls y .csv.</div></div>' +
      '<div class="card card-pad" style="margin-bottom:6px;display:flex;gap:14px;align-items:flex-end;flex-wrap:wrap">' +
        '<div class="field" style="flex:1;min-width:240px;margin:0"><label for="pl-filtro">Filtrar por tipo de maquinaria</label>' +
        '<select id="pl-filtro" data-bind="pl-filtro"><option value="">Todos los tipos (' + pls.length + ')</option>' +
        tipos.map(function (t) {
          var n = pls.filter(function (p) { return p.tipo === t; }).length;
          return '<option value="' + E(t) + '"' + (filtro === t ? ' selected' : '') + '>' + E(t) + ' (' + n + ')</option>';
        }).join('') + '</select></div>' +
        '<div class="small muted" style="padding-bottom:11px">' + visibles.length + ' checklist · ' + totalItems + ' ítems en total</div>' +
      '</div>' +
      cuerpo;
  }

  function plantillaUpload() {
    IMPORT = null;
    var body = '<div class="field" style="margin-bottom:13px"><label for="pl-file">Archivo Excel</label>' +
        '<input id="pl-file" type="file" accept=".xlsx,.xls,.csv" data-role="pl-file">' +
        '<span class="hint">Acepta .xlsx, .xls y .csv (máx. 5 MB).</span></div>' +
      '<div class="form-row c2"><div class="field"><label for="pl-nombre">Nombre del checklist</label>' +
        '<input id="pl-nombre" type="text" placeholder="Ej.: Checklist Diario — Camión Pluma"></div>' +
        '<div class="field"><label for="pl-tipo">Tipo de equipo</label><select id="pl-tipo">' +
        DB.tipos().map(function (t) { return '<option>' + E(t) + '</option>'; }).join('') +
        '</select></div></div>' +
      '<div class="form-row c2" style="margin-top:13px"><div class="field"><label for="pl-frec">Frecuencia</label><select id="pl-frec">' +
        ['Diario', 'Por turno', 'Semanal', 'Mensual'].map(function (t) { return '<option>' + E(t) + '</option>'; }).join('') + '</select></div>' +
        '<div class="field"><label>Vista previa</label><div id="pl-preview" class="small muted" style="padding-top:9px">Selecciona un archivo para ver los ítems detectados.</div></div></div>' +
      '<div id="pl-preview-table" style="margin-top:14px"></div>';

    UI.modal({
      title: 'Subir checklist desde Excel', subtitle: 'Las filas del archivo se convierten en ítems del formulario.', size: 'xl', body: body,
      actions: [
        { label: 'Cancelar', className: 'btn-ghost', onClick: function () { UI.closeModal(); } },
        { label: 'Guardar plantilla', className: 'btn-primary', onClick: function () { guardarPlantillaImport(); } }
      ]
    });
  }

  function handlePlFile(file) {
    if (!file) return;
    if (typeof XLSX === 'undefined') { UI.toast('No se pudo cargar el lector de Excel', 'err'); return; }
    if (file.size > 5 * 1024 * 1024) { UI.toast('El archivo supera los 5 MB', 'err'); return; }
    var reader = new FileReader();
    reader.onload = function (ev) {
      try {
        var wb = XLSX.read(new Uint8Array(ev.target.result), { type: 'array' });
        var ws = wb.Sheets[wb.SheetNames[0]];
        var rows = XLSX.utils.sheet_to_json(ws, { header: 1, blankrows: false, defval: '' });
        var parsed = parseRows(rows);
        IMPORT = parsed;
        renderImportPreview(file.name, parsed);
      } catch (err) {
        UI.toast('No se pudo leer el archivo: ' + err.message, 'err');
      }
    };
    reader.readAsArrayBuffer(file);
  }

  function parseRows(rows) {
    if (!rows.length) return { items: [], header: [] };
    var hIdx = 0, best = -1;
    for (var i = 0; i < Math.min(rows.length, 12); i++) {
      var score = rows[i].filter(function (c) {
        return /(item|ítem|pregunta|actividad|control|descripci|criterio|secci|cr[ií]tico)/i.test(String(c));
      }).length;
      if (score > best) { best = score; hIdx = i; }
    }
    var header = rows[hIdx].map(function (c) { return String(c).trim(); });
    function col(re) {
      for (var k = 0; k < header.length; k++) if (re.test(header[k])) return k;
      return -1;
    }
    var cSec = col(/secc|sección|area|área|etapa|categor|grupo/i);
    var cItem = col(/item|ítem|pregunta|actividad|control|descripci|requisito/i);
    var cCrit = col(/criterio|aceptaci|estándar|estandar|referencia|tolerancia/i);
    var cFlag = col(/cr[ií]tico|critic|obligator/i);
    if (cItem < 0) cItem = header.length > 1 ? 1 : 0;
    if (cSec < 0) cSec = 0;
    var items = [];
    for (var r = hIdx + 1; r < rows.length; r++) {
      var row = rows[r];
      var txt = String(row[cItem] || '').trim();
      if (!txt || /^(total|firma|observaci)/i.test(txt)) continue;
      var sec = cSec >= 0 ? String(row[cSec] || '').trim() : '';
      var flag = cFlag >= 0 ? String(row[cFlag] || '').trim() : '';
      items.push({
        sec: sec || 'General',
        txt: txt,
        criterio: cCrit >= 0 ? String(row[cCrit] || '').trim() : '',
        crit: /^(s[ií]|x|1|true|cr[ií]tico|obligatorio)$/i.test(flag)
      });
    }
    return { items: items, header: header };
  }

  function renderImportPreview(filename, parsed) {
    var pv = document.getElementById('pl-preview');
    if (pv) pv.innerHTML = '<b style="color:#6EE7B7">' + parsed.items.length + ' ítems detectados</b><br>' + E(filename);
    var box = document.getElementById('pl-preview-table');
    if (!box) return;
    if (!parsed.items.length) {
      box.innerHTML = '<div class="card card-pad small" style="color:#FCA5A5">No se detectaron ítems. Revisa que exista una columna "Ítem" con una fila por punto a inspeccionar.</div>';
      return;
    }
    box.innerHTML = '<div class="card" style="max-height:300px;overflow:auto"><div class="table-wrap"><table><thead><tr>' +
      '<th style="width:34px">#</th><th>Sección</th><th>Ítem</th><th>Criterio</th><th>Crítico</th></tr></thead><tbody>' +
      parsed.items.slice(0, 40).map(function (it, i) {
        return '<tr><td class="muted">' + (i + 1) + '</td><td>' + E(it.sec) + '</td><td>' + E(it.txt) + '</td><td class="small muted">' + E(it.criterio || '—') + '</td>' +
          '<td>' + (it.crit ? '<span class="badge badge-warn">Sí</span>' : '<span class="tiny muted">No</span>') + '</td></tr>';
      }).join('') + '</tbody></table></div></div>' +
      (parsed.items.length > 40 ? '<div class="tiny muted" style="padding:8px">Mostrando 40 de ' + parsed.items.length + ' ítems.</div>' : '');

    var nm = document.getElementById('pl-nombre');
    if (nm && !nm.value) nm.value = filename.replace(/\.(xlsx|xls|csv)$/i, '').replace(/[_-]+/g, ' ');
  }

  function guardarPlantillaImport() {
    if (!IMPORT || !IMPORT.items.length) { UI.toast('Primero carga un archivo con ítems', 'err'); return; }
    var nombre = $('#pl-nombre').value.trim();
    if (!nombre) { UI.toast('Escribe un nombre para el checklist', 'err'); return; }
    var total = IMPORT.items.length;
    DB.savePlantilla({
      nombre: nombre, tipo: $('#pl-tipo').value, frecuencia: $('#pl-frec').value,
      items: IMPORT.items, fuente: 'Excel importado'
    });
    IMPORT = null;
    UI.closeModal();
    UI.toast('Plantilla guardada con ' + total + ' ítems');
    go('plantillas');
  }

  function descargarModelo() {
    if (typeof XLSX === 'undefined') { UI.toast('Lector de Excel no disponible', 'err'); return; }
    var aoa = [
      ['Sección', 'Ítem', 'Criterio de aceptación', 'Crítico'],
      ['Documentación', 'Licencia de conducir vigente y habilitada para el equipo', 'Licencia clase A3 o superior al día', 'Sí'],
      ['Documentación', 'Certificación del operador vigente', 'Certificado no mayor a 24 meses', 'Sí'],
      ['Inspección visual', 'Ausencia de fugas de aceite o combustible', 'Sin goteo bajo el equipo', 'Sí'],
      ['Inspección visual', 'Luces, balizas y alarma de retroceso operativas', 'Todas las luces funcionan', 'Sí'],
      ['Sistema hidráulico', 'Mangueras sin fisuras ni filtraciones', 'Sin abultamientos ni roce', 'Sí']
    ];
    var ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!cols'] = [{ wch: 22 }, { wch: 58 }, { wch: 46 }, { wch: 10 }];
    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Checklist');
    XLSX.writeFile(wb, 'Formato_Checklist.xlsx');
  }

  function exportPlantilla(id) {
    var p = DB.findPlantilla(id);
    if (!p || typeof XLSX === 'undefined') return;
    var aoa = [['Sección', 'Ítem', 'Criterio de aceptación', 'Crítico']].concat(p.items.map(function (it) {
      return [it.sec, it.txt, it.criterio || '', it.crit ? 'Sí' : 'No'];
    }));
    var ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!cols'] = [{ wch: 22 }, { wch: 58 }, { wch: 46 }, { wch: 10 }];
    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Checklist');
    XLSX.writeFile(wb, p.nombre.replace(/[^\w\s-]/g, '').slice(0, 40) + '.xlsx');
  }

  function verPlantilla(id) {
    var p = DB.findPlantilla(id);
    if (!p) return;
    var grupos = groupItems(p.items);
    var body = grupos.map(function (g) {
      return '<div class="res-sec">' + E(g.sec) + '</div>' + g.items.map(function (it) {
        return '<div class="res-row"><div class="st ' + (it.crit ? 'no' : 'na') + '">' + I(it.crit ? 'alert' : 'check') + '</div>' +
          '<div class="res-txt">' + E(it.txt) + (it.criterio ? '<div class="t-sub">' + E(it.criterio) + '</div>' : '') + '</div></div>';
      }).join('');
    }).join('');
    var acciones = [{ label: 'Cerrar', className: 'btn-ghost', onClick: function () { UI.closeModal(); } }];
    if (isSuper()) acciones.unshift({ label: 'Modificar ítems', className: 'btn-primary', onClick: function () { UI.closeModal(); editarPlantilla(id); } });
    UI.modal({
      title: p.nombre, subtitle: p.items.length + ' ítems · ' + (p.tipo || 'General') + ' · ' + (p.frecuencia || 'Diario'),
      size: 'xl', body: '<div class="card" style="max-height:60vh;overflow:auto">' + body + '</div>',
      actions: acciones
    });
  }

  /* ---------------------- edición de check lists (admin) ------------------ */

  function filaItem(it) {
    return '<div class="pedit-row" style="display:grid;grid-template-columns:1fr 2fr 1.4fr 62px 34px;gap:8px;margin-bottom:7px;align-items:center">' +
      '<input class="pedit-sec" type="text" value="' + E(it.sec || 'General') + '" placeholder="Sección">' +
      '<input class="pedit-txt" type="text" value="' + E(it.txt || '') + '" placeholder="Ítem a inspeccionar">' +
      '<input class="pedit-cri" type="text" value="' + E(it.criterio || '') + '" placeholder="Criterio de aceptación">' +
      '<label class="check-inline" style="margin:0;justify-content:center"><input class="pedit-crit" type="checkbox"' + (it.crit ? ' checked' : '') + '> Crítico</label>' +
      '<button type="button" class="icon-btn danger" data-act="pl-del-item" aria-label="Quitar ítem">' + I('trash') + '</button>' +
    '</div>';
  }

  function editarPlantilla(id) {
    var p = DB.findPlantilla(id);
    if (!p) { UI.toast('Check list no encontrado', 'err'); return; }
    var tipos = DB.tipos();
    if (tipos.indexOf(p.tipo) < 0 && p.tipo) tipos = tipos.concat([p.tipo]);
    var body = '<div class="form-row c3">' +
        '<div class="field"><label for="pe-nombre">Nombre del check list</label><input id="pe-nombre" type="text" value="' + E(p.nombre) + '"></div>' +
        '<div class="field"><label for="pe-tipo">Tipo de maquinaria</label><select id="pe-tipo">' +
          tipos.map(function (t) { return '<option value="' + E(t) + '"' + (p.tipo === t ? ' selected' : '') + '>' + E(t) + '</option>'; }).join('') +
        '</select></div>' +
        '<div class="field"><label for="pe-frec">Frecuencia</label><select id="pe-frec">' +
          ['Diario', 'Por turno', 'Semanal', 'Mensual'].map(function (t) { return '<option' + ((p.frecuencia || 'Diario') === t ? ' selected' : '') + '>' + E(t) + '</option>'; }).join('') +
        '</select></div></div>' +
      '<div class="form-sep"></div>' +
      '<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px"><strong style="font-size:13px">Ítems del check list</strong>' +
        '<span class="chip" id="pe-count">' + p.items.length + '</span><div style="flex:1"></div>' +
        '<button type="button" class="btn btn-ghost btn-sm" data-act="pl-add-item">' + I('plus') + ' Agregar ítem</button></div>' +
      '<div class="small muted" style="margin-bottom:8px">Puedes corregir el texto, cambiar la sección, agregar o quitar puntos. Los check lists ya guardados no se modifican.</div>' +
      '<div class="pedit-head" style="display:grid;grid-template-columns:1fr 2fr 1.4fr 62px 34px;gap:8px;font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);margin-bottom:6px">' +
        '<span>Sección</span><span>Ítem</span><span>Criterio</span><span style="text-align:center">Crítico</span><span></span></div>' +
      '<div id="pe-rows" style="max-height:52vh;overflow:auto;padding-right:4px">' + p.items.map(filaItem).join('') + '</div>';

    UI.modal({
      title: 'Modificar ' + p.nombre, subtitle: 'Los cambios se aplican a los próximos check lists.', size: 'xl', body: body,
      actions: [
        { label: 'Cancelar', className: 'btn-ghost', onClick: function () { UI.closeModal(); } },
        { label: 'Guardar cambios', className: 'btn-primary', onClick: function () { guardarEdicionPlantilla(id); } }
      ]
    });
    actualizarCuentaItems();
  }

  function actualizarCuentaItems() {
    var c = document.getElementById('pe-count');
    var filas = document.querySelectorAll('#pe-rows .pedit-row');
    if (c) c.textContent = filas.length;
  }

  function guardarEdicionPlantilla(id) {
    var p = DB.findPlantilla(id);
    if (!p) return;
    var nombre = (document.getElementById('pe-nombre').value || '').trim();
    if (!nombre) { UI.toast('El nombre no puede quedar vacío', 'err'); return; }
    var items = [];
    document.querySelectorAll('#pe-rows .pedit-row').forEach(function (f, i) {
      var txt = f.querySelector('.pedit-txt').value.trim();
      if (!txt) return;
      items.push({
        id: 'i' + (i + 1),
        sec: f.querySelector('.pedit-sec').value.trim() || 'General',
        txt: txt,
        criterio: f.querySelector('.pedit-cri').value.trim(),
        crit: f.querySelector('.pedit-crit').checked
      });
    });
    if (!items.length) { UI.toast('El check list debe tener al menos un ítem', 'err'); return; }
    DB.savePlantilla({
      nombre: nombre,
      tipo: document.getElementById('pe-tipo').value,
      frecuencia: document.getElementById('pe-frec').value,
      items: items,
      fuente: p.fuente || 'Manual'
    }, id);
    UI.closeModal();
    UI.toast('Check list actualizado');
    renderView();
  }

  function nuevoChecklist() {
    var tipos = DB.tipos();
    var body = '<div class="form-row c2">' +
        '<div class="field"><label for="pn-tipo">Tipo de maquinaria</label><select id="pn-tipo">' +
          (tipos.length ? tipos.map(function (t) { return '<option value="' + E(t) + '">' + E(t) + '</option>'; }).join('') : '<option value="General">General</option>') +
        '</select></div>' +
        '<div class="field"><label for="pn-nombre">Nombre del check list</label><input id="pn-nombre" type="text" placeholder="Checklist Diario — …"></div></div>' +
      '<div class="small muted" style="margin-top:10px">Se crea vacío: después agregas los ítems uno por uno, o subes un Excel.</div>';
    UI.modal({
      title: 'Nuevo check list', subtitle: 'Para un tipo de maquinaria que no esté en la lista.', size: 'lg', body: body,
      actions: [
        { label: 'Cancelar', className: 'btn-ghost', onClick: function () { UI.closeModal(); } },
        { label: 'Crear', className: 'btn-primary', onClick: function () {
            var tipo = document.getElementById('pn-tipo').value;
            var nombre = (document.getElementById('pn-nombre').value || '').trim() || ('Checklist Diario — ' + tipo);
            var p = DB.savePlantilla({ nombre: nombre, tipo: tipo, frecuencia: 'Diario', items: [{ id: 'i1', sec: 'General', txt: 'Ítem de ejemplo (edítalo)', crit: false, criterio: '' }], fuente: 'Manual' });
            UI.closeModal();
            editarPlantilla(p.id);
          } }
      ]
    });
  }

  /* -------------------------------- ajustes ------------------------------ */
  function chipBase() {
    var i = window.API ? API.info() : { estado: 'sin-configurar' };
    if (i.estado === 'conectado') return '<span class="badge badge-ok">' + I('check') + ' Conectada</span>';
    if (i.estado === 'sin-conexion') return '<span class="badge badge-warn">' + I('alert') + ' Sin conexión</span>';
    if (i.estado === 'sesion-vencida') return '<span class="badge badge-bad">' + I('alert') + ' Sesión vencida</span>';
    return '<span class="badge badge-mute">No configurada</span>';
  }

  function cardBaseCompartida() {
    var i = window.API ? API.info() : { url: '', estado: 'sin-configurar', ultima: '' };
    var pendientes = DB.borradosPendientes().length;
    var ultima = i.ultima ? DB.fechaHora(i.ultima) : 'sin sincronizar';
    var cuerpo = '';

    if (isAdmin()) {
      cuerpo += '<div class="field" style="margin-bottom:10px"><label for="srv-url">Dirección del servidor</label>' +
        '<input id="srv-url" type="url" placeholder="https://checklist.tuempresa.cl" value="' + E(i.url || '') + '">' +
        '<span class="hint">La dirección que entrega el servicio central. Debe ser HTTPS.</span></div>';
      cuerpo += '<div class="form-row c2" style="margin-bottom:10px">' +
        '<div class="field"><label for="srv-correo">Correo administrador</label><input id="srv-correo" type="email" placeholder="admin@empresa.cl" value="' + E(i.usuario && i.usuario.correo ? i.usuario.correo : '') + '"></div>' +
        '<div class="field"><label for="srv-clave">Contraseña</label><input id="srv-clave" type="password" placeholder="••••••••"></div></div>';
    }

    cuerpo += '<div class="dl" style="margin-bottom:12px"><dt>Estado</dt><dd>' + chipBase() + '</dd>' +
      '<dt>Última sincronización</dt><dd>' + E(ultima) + '</dd>' +
      '<dt>Cambios por subir</dt><dd>' + pendientes + '</dd></div>';

    cuerpo += '<div class="small muted" style="margin-bottom:12px">Con la base compartida, todos los equipos ven los mismos usuarios, check lists y registros. Sin señal, la aplicación sigue trabajando con la copia guardada y sincroniza al recuperar la conexión.</div>';

    cuerpo += '<div style="display:flex;gap:8px;flex-wrap:wrap">';
    if (isAdmin()) {
      cuerpo += '<button type="button" class="btn btn-ghost btn-sm" data-act="srv-probar">' + I('refresh') + ' Probar</button>' +
        '<button type="button" class="btn btn-primary btn-sm" data-act="srv-conectar">' + I('check') + ' Conectar</button>' +
        (i.url ? '<button type="button" class="btn btn-ghost btn-sm" data-act="srv-desconectar">Desconectar</button>' : '');
    }
    if (i.url) cuerpo += '<button type="button" class="btn btn-ghost btn-sm" data-act="srv-sincronizar">' + I('refresh') + ' Sincronizar ahora</button>';
    cuerpo += '</div>';

    return '<div class="card" style="margin-bottom:16px;border-color:rgba(96,165,250,.25)">' +
      '<div class="card-head"><h3>Base de datos compartida</h3><div class="spacer"></div>' + chipBase() + '</div>' +
      '<div class="card-body">' + cuerpo + '</div></div>';
  }

  function probarServidor() {
    var url = $('#srv-url') ? $('#srv-url').value : '';
    UI.toast('Probando conexión…');
    API.probar(url).then(function (d) {
      UI.toast('Servidor disponible: ' + (d.servicio || 'ok'));
    }).catch(function (e) {
      UI.toast(e.message || 'No se pudo conectar', 'err');
    });
  }

  function conectarServidor() {
    var url = $('#srv-url') ? $('#srv-url').value : '';
    var correo = $('#srv-correo') ? $('#srv-correo').value : '';
    var clave = $('#srv-clave') ? $('#srv-clave').value : '';
    if (!url) { UI.toast('Escribe la dirección del servidor', 'err'); return; }
    if (!correo || !clave) { UI.toast('Escribe el correo y la contraseña del administrador', 'err'); return; }
    UI.toast('Conectando…');
    API.conectar(url, correo, clave).then(function (datos) {
      if (!datos.usuario || datos.usuario.rol !== 'admin') {
        UI.toast('La cuenta debe ser administradora del servidor', 'err');
        return;
      }
      return API.jalar().then(function () { return API.empujar(); });
    }).then(function () {
      UI.toast('Base compartida conectada');
      renderView();
    }).catch(function (e) {
      UI.toast(e.message || 'No se pudo conectar', 'err');
    });
  }

  function sincronizarAhora() {
    if (!window.API || !API.sesion()) { UI.toast('Primero conecta la base compartida', 'err'); return; }
    UI.toast('Sincronizando…');
    API.sincronizar().then(function () {
      var i = API.info();
      if (i.estado === 'conectado') UI.toast('Información sincronizada');
      else UI.toast(i.error || 'No se pudo sincronizar', 'err');
      renderView();
    });
  }

  function desconectarServidor() {
    UI.confirm('Desconectar base compartida', 'La aplicación seguirá funcionando solo con los datos guardados en este equipo.', 'Desconectar', true).then(function (ok) {
      if (!ok) return;
      API.desconectar();
      UI.toast('Base compartida desconectada');
      renderView();
    });
  }

  function viewAjustes() {
    var st = DB.get().settings;
    var vars = ['nombre', 'checklist', 'equipo', 'codigo', 'patente', 'kilometraje', 'ultimaMantencion', 'proximaMantencion', 'fecha', 'hora', 'estado', 'evaluados', 'noconformes', 'observaciones', 'id', 'empresa', 'rut'];
    return pageHead('<button type="button" class="btn btn-primary" data-act="settings-save">' + I('check') + ' Guardar cambios</button>') +
      '<div class="grid" style="grid-template-columns:1.1fr .9fr;gap:16px;align-items:start" id="set-grid">' +
        '<div>' +
          '<div class="card" style="margin-bottom:16px"><div class="card-head"><h3>Datos de la empresa</h3></div><div class="card-body">' +
            '<div class="form-row c2">' +
              fieldText('s-empresa', 'Empresa', st.empresa, 'Salfa Montajes', 'text', true) +
              fieldText('s-contrato', 'Contrato', st.contrato, '26810-220-HC1-MZ00-00003', 'text', false) +
            '</div>' +
            '<div class="field" style="margin-top:13px"><label for="s-proyecto">Proyecto / faena</label>' +
              '<input id="s-proyecto" type="text" value="' + E(st.proyecto) + '"></div>' +
          '</div></div>' +
          '<div class="card"><div class="card-head"><h3>Mensaje de WhatsApp</h3><div class="spacer"></div><span class="small muted">Variables disponibles</span></div>' +
            '<div class="card-body">' +
              '<div class="field"><label for="s-mensaje">Plantilla del mensaje</label>' +
              '<textarea id="s-mensaje" style="min-height:170px;font-family:ui-monospace,Menlo,monospace;font-size:12.4px">' + E(st.mensaje) + '</textarea></div>' +
              '<div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:10px">' +
                vars.map(function (v) { return '<button type="button" class="chip" data-act="ins-var" data-var="{{' + v + '}}" style="cursor:pointer">' + E('{{' + v + '}}') + '</button>'; }).join('') +
              '</div>' +
            '</div></div>' +
        '</div>' +
        '<div>' +
          cardBaseCompartida() +
          '<div class="card" style="margin-bottom:16px"><div class="card-head"><h3>Envío de WhatsApp</h3></div><div class="card-body">' +
            '<div class="field"><label for="s-api">Modo de envío</label><select id="s-api">' +
              '<option value="enlace"' + (st.whatsappApi === 'enlace' ? ' selected' : '') + '>Enlace wa.me (sin costo, abre WhatsApp)</option>' +
              '<option value="api"' + (st.whatsappApi === 'api' ? ' selected' : '') + '>API oficial (automático, requiere servidor)</option>' +
            '</select><span class="hint">El envío automático 24/7 se configura en el backend incluido.</span></div>' +
            '<div class="form-sep"></div>' +
            '<div class="small muted">El mensaje incluye fecha, hora, equipo, resultado y observaciones. Queda registrada la confirmación con fecha y hora en cada checklist.</div>' +
          '</div></div>' +
          '<div class="card" style="margin-bottom:16px"><div class="card-head"><h3>Respaldo de datos</h3></div><div class="card-body">' +
            '<div class="small muted" style="margin-bottom:12px">Descarga una copia completa (usuarios, equipos, plantillas y checklists) o restaura un respaldo anterior.</div>' +
            '<div style="display:flex;gap:8px;flex-wrap:wrap">' +
              '<button type="button" class="btn btn-ghost btn-sm" data-act="backup">' + I('download') + ' Descargar respaldo</button>' +
              '<button type="button" class="btn btn-ghost btn-sm" data-act="restore">' + I('upload') + ' Restaurar</button>' +
              '<input type="file" id="restore-file" accept="application/json" data-role="restore" style="display:none">' +
            '</div></div></div>' +
          '<div class="card" style="margin-bottom:16px"><div class="card-head"><h3>Aplicación móvil</h3></div><div class="card-body">' +
            '<div class="small muted" style="margin-bottom:12px">Instala Check List Maquinarias ENTS en el teléfono para usarla como app, incluso sin señal.</div>' +
            '<button type="button" class="btn btn-soft btn-sm btn-block" data-act="install">' + I('smart') + ' Cómo instalarla en Android / iPhone</button>' +
          '</div></div>' +
          '<div class="card"><div class="card-head"><h3>Sesión</h3></div><div class="card-body">' +
            '<div class="dl" style="margin-bottom:14px"><dt>Usuario</dt><dd>' + E(S.user.nombre) + '</dd>' +
            '<dt>Rol</dt><dd>' + E(S.user.rol) + '</dd><dt>Correo</dt><dd>' + E(S.user.email) + '</dd></div>' +
            '<div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="btn btn-ghost btn-sm" data-act="cuenta">Cambiar contraseña</button>' +
            '<button type="button" class="btn btn-danger btn-sm" data-act="reset-demo">Restaurar datos de ejemplo</button></div>' +
          '</div></div>' +
        '</div>' +
      '</div>';
  }

  /* ------------------------------- acciones ------------------------------ */
  function onClick(e) {
    var el = e.target.closest('[data-act]');
    if (!el) return;
    var act = el.getAttribute('data-act');
    var id = el.getAttribute('data-id');

    var ACCIONES_GESTION = ['user-new', 'user-edit', 'user-del', 'user-toggle', 'user-pass',
      'eq-new', 'eq-edit', 'eq-del', 'pl-edit', 'pl-new', 'pl-upload', 'pl-add-item', 'pl-del-item',
      'pl-del', 'settings-save', 'srv-conectar', 'srv-desconectar', 'srv-sincronizar'];
    var ACCIONES_ADMIN = ['reset-demo', 'restore', 'backup', 'srv-probar'];
    if (ACCIONES_GESTION.indexOf(act) >= 0 && !isSuper()) {
      UI.toast('Solo administradores y supervisores pueden hacer cambios', 'err');
      return;
    }
    if (ACCIONES_ADMIN.indexOf(act) >= 0 && !isAdmin()) {
      UI.toast('Esta acción es solo para administradores', 'err');
      return;
    }

    switch (act) {
      case 'nav':
        e.preventDefault();
        if (el.getAttribute('data-view') === 'nuevo') WIZ = null;
        go(el.getAttribute('data-view'));
        break;
      case 'open-nav': document.body.classList.toggle('nav-open'); break;
      case 'logout':
        DB.logout(); S.user = null; WIZ = null; renderLogin();
        break;
      case 'toggle-pass': {
        var p = $('#li-pass');
        if (p) p.type = p.type === 'password' ? 'text' : 'password';
        break;
      }
      case 'demo': {
        var mu = $('#li-user'), mp = $('#li-pass');
        if (mu) mu.value = el.getAttribute('data-mail');
        if (mp) mp.value = el.getAttribute('data-pass');
        break;
      }
      case 'install': mostrarInstalacion(); break;
      case 'install-go': {
        if (DEFERRED) { DEFERRED.prompt(); DEFERRED = null; UI.closeModal(); }
        break;
      }
      case 'cuenta': abrirCuenta(); break;

      case 'pick-eq': {
        var eqSel = equipoById(id);
        WIZ.equipoId = id; WIZ.plantillaId = '';
        if (eqSel) {
          WIZ.patente = eqSel.patente || '';
          WIZ.kilometraje = (eqSel.kilometraje === 0 || eqSel.kilometraje) ? String(eqSel.kilometraje) : '';
          WIZ.ultimaMantencion = eqSel.ultimaMantencion || '';
          WIZ.proximaMantencion = eqSel.proximaMantencion || '';
        }
        renderView();
        break;
      }
      case 'pick-pl':
        WIZ.plantillaId = id; renderView();
        break;
      case 'wiz-next': {
        if (!WIZ.equipoId || !WIZ.plantillaId) { UI.toast('Selecciona equipo y plantilla', 'err'); return; }
        WIZ.step = 2; renderView();
        break;
      }
      case 'wiz-back': WIZ.step = 1; renderView(); break;
      case 'seg': {
        var itemEl = el.closest('.chk-item');
        if (!itemEl) break;
        WIZ.respuestas[itemEl.getAttribute('data-item')] = el.getAttribute('data-val');
        $$('.seg button', itemEl).forEach(function (b) { b.classList.toggle('on', b === el); });
        itemEl.classList.toggle('flag-no', el.getAttribute('data-val') === 'no');
        updateProgress();
        break;
      }
      case 'bulk-si': {
        var pl2 = DB.findPlantilla(WIZ.plantillaId);
        pl2.items.forEach(function (it) {
          if (!WIZ.respuestas[it.id]) WIZ.respuestas[it.id] = 'si';
          var row = document.querySelector('.chk-item[data-item="' + it.id + '"]');
          if (row) {
            $$('.seg button', row).forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-val') === WIZ.respuestas[it.id]); });
            row.classList.toggle('flag-no', WIZ.respuestas[it.id] === 'no');
          }
        });
        updateProgress();
        UI.toast('Ítems restantes marcados como B (Bueno)');
        break;
      }
      case 'wiz-summary': {
        var c = countResumen();
        if (c.answered < c.total) {
          UI.toast('Faltan ' + (c.total - c.answered) + ' ítems por evaluar', 'err');
          var falta = $$('.chk-item').filter(function (r) { return !WIZ.respuestas[r.getAttribute('data-item')]; })[0];
          if (falta) falta.scrollIntoView({ behavior: 'smooth', block: 'center' });
          return;
        }
        WIZ.step = 3; renderView();
        setTimeout(initSig, 40);
        break;
      }
      case 'sig-clear': {
        var cv = document.getElementById('sig-canvas');
        if (cv && cv.__clear) cv.__clear();
        WIZ.firma = '';
        var stt = document.getElementById('sig-state');
        if (stt) stt.textContent = 'Sin firma';
        break;
      }
      case 'guardar': guardarChecklist(); break;

      case 'ver': go('insp', { id: id }); break;
      case 'wa': {
        var ins = DB.findInspeccion(id);
        if (ins) abrirWhatsapp(ins, function () { renderView(); });
        break;
      }
      case 'print': window.print(); break;
      case 'pdf': descargarPdf(DB.findInspeccion(id)); break;
      case 'del-insp': {
        var i2 = DB.findInspeccion(id);
        UI.confirm('Eliminar checklist', 'Se eliminará el registro ' + codigoCorto(i2) + ' de forma permanente. ¿Continuar?', 'Eliminar', true).then(function (ok) {
          if (!ok) return;
          DB.deleteInspeccion(id);
          UI.toast('Registro eliminado');
          go('historial');
        });
        break;
      }
      case 'export': exportarHistorial(); break;

      case 'user-new': userForm(null); break;
      case 'user-edit': userForm(id); break;
      case 'user-pass': resetPass(id); break;
      case 'user-toggle':
        DB.toggleUser(id);
        UI.toast('Estado del usuario actualizado');
        renderView();
        break;
      case 'user-del': {
        var u = DB.findUser(id);
        UI.confirm('Eliminar usuario', 'Se eliminará la cuenta de ' + u.nombre + '. Los checklists ya registrados se conservan.', 'Eliminar', true).then(function (ok) {
          if (!ok) return;
          if (!DB.deleteUser(id)) { UI.toast('No puedes eliminar al último administrador activo', 'err'); return; }
          UI.toast('Usuario eliminado'); renderView();
        });
        break;
      }
      case 'user-export': exportarUsuarios(); break;

      case 'eq-new': equipoForm(null); break;
      case 'eq-edit': equipoForm(id); break;
      case 'eq-del': {
        var eq = equipoById(id);
        UI.confirm('Eliminar equipo', 'Se eliminará ' + eq.codigo + ' · ' + eq.nombre + ' del catálogo. Los checklists históricos se mantienen.', 'Eliminar', true).then(function (ok) {
          if (!ok) return;
          DB.deleteEquipo(id); UI.toast('Equipo eliminado'); renderView();
        });
        break;
      }

      case 'pl-upload': plantillaUpload(); break;
      case 'pl-view': verPlantilla(id); break;
      case 'pl-edit': editarPlantilla(id); break;
      case 'pl-new': nuevoChecklist(); break;
      case 'pl-add-item': {
        var cont = document.getElementById('pe-rows');
        if (cont) {
          cont.insertAdjacentHTML('beforeend', filaItem({ sec: '', txt: '', criterio: '', crit: false }));
          actualizarCuentaItems();
          var campos = cont.querySelectorAll('.pedit-txt');
          if (campos.length) campos[campos.length - 1].focus();
        }
        break;
      }
      case 'pl-del-item': {
        var fila = e.target.closest ? e.target.closest('.pedit-row') : null;
        if (fila) { fila.parentNode.removeChild(fila); actualizarCuentaItems(); }
        break;
      }
      case 'pl-export': exportPlantilla(id); break;
      case 'pl-model': descargarModelo(); break;
      case 'pl-del': {
        var pl3 = DB.findPlantilla(id);
        UI.confirm('Eliminar plantilla', 'Se eliminará "' + pl3.nombre + '". Los checklists ya realizados no se modifican.', 'Eliminar', true).then(function (ok) {
          if (!ok) return;
          DB.deletePlantilla(id); UI.toast('Plantilla eliminada'); renderView();
        });
        break;
      }

      case 'settings-save': guardarAjustes(); break;
      case 'srv-probar': probarServidor(); break;
      case 'srv-conectar': conectarServidor(); break;
      case 'srv-sincronizar': sincronizarAhora(); break;
      case 'srv-desconectar': desconectarServidor(); break;
      case 'ins-var': {
        var ta = $('#s-mensaje');
        if (!ta) break;
        var v = el.getAttribute('data-var');
        var pos = ta.selectionStart || ta.value.length;
        ta.value = ta.value.slice(0, pos) + v + ta.value.slice(pos);
        ta.focus();
        ta.selectionStart = ta.selectionEnd = pos + v.length;
        break;
      }
      case 'backup':
        UI.downloadText('respaldo-checklistpro-' + DB.fecha(new Date().toISOString()) + '.json', DB.exportJSON(), 'application/json');
        UI.toast('Respaldo descargado');
        break;
      case 'restore': {
        var rf = document.getElementById('restore-file');
        if (rf) rf.click();
        break;
      }
      case 'reset-demo': {
        UI.confirm('Restaurar datos de ejemplo', 'Se borrarán todos los usuarios, equipos y checklists actuales y se cargarán los datos de demostración. Esta acción no se puede deshacer.', 'Restaurar', true).then(function (ok) {
          if (!ok) return;
          DB.reset(); UI.toast('Datos restaurados');
          DB.logout(); S.user = null; renderLogin();
        });
        break;
      }
    }
  }

  function onInput(e) {
    var t = e.target;
    var bind = t.getAttribute && t.getAttribute('data-bind');

    if (bind === 'obs') {
      if (!WIZ) return;
      WIZ.obs[t.getAttribute('data-item')] = t.value;
      return;
    }
    if (bind === 'observaciones') {
      if (!WIZ) return;
      WIZ.observaciones = t.value;
      var prev = document.getElementById('wiz-preview');
      if (prev && WIZ.plantillaId) {
        var pl = DB.findPlantilla(WIZ.plantillaId);
        var eq = equipoById(WIZ.equipoId);
        if (pl && eq) {
          var resp = pl.items.map(function (it) { return { valor: WIZ.respuestas[it.id] || 'na', crit: it.crit, txt: it.txt }; });
          prev.textContent = previewMsg(eq, pl, resp, DB.estadoDe(resp));
        }
      }
      return;
    }
    if (bind === 'telefono') { if (WIZ) WIZ.telefono = t.value; return; }
    if (bind === 'patente' || bind === 'kilometraje' || bind === 'ultimaMantencion' || bind === 'proximaMantencion') {
      if (!WIZ) return;
      WIZ[bind] = t.value;
      if (bind === 'proximaMantencion') avisoMantencion();
      return;
    }
    if (bind === 'tipo') {
      if (!WIZ || e.type !== 'change') return;
      WIZ.tipo = t.value;
      WIZ.equipoId = '';
      var plt = t.value ? DB.plantillaPorTipo(t.value) : null;
      WIZ.plantillaId = plt ? plt.id : '';
      renderView();
      return;
    }
    if (bind === 'pl-filtro') {
      if (e.type !== 'change') return;
      PL_FILTRO = t.value;
      renderView();
      return;
    }
    if (bind === 'plantilla') {
      if (!WIZ || e.type !== 'change') return;
      WIZ.plantillaId = t.value;
      renderView();
      return;
    }

    if (e.type !== 'change' || !t.getAttribute) return;
    var role = t.getAttribute('data-role');
    if (role === 'pl-file') { handlePlFile(t.files[0]); return; }
    if (role === 'restore' && t.files && t.files[0]) {
      var rd = new FileReader();
      rd.onload = function (ev) {
        try {
          var obj = JSON.parse(ev.target.result);
          if (DB.importJSON(obj)) { UI.toast('Respaldo restaurado'); setTimeout(function () { location.reload(); }, 700); }
          else UI.toast('El archivo no es un respaldo válido', 'err');
        } catch (err) { UI.toast('Archivo JSON inválido', 'err'); }
      };
      rd.readAsText(t.files[0]);
    }
  }

  /* -------------------------------- firma -------------------------------- */
  function initSig() {
    var canvas = document.getElementById('sig-canvas');
    if (!canvas || canvas.__init) return;
    canvas.__init = true;
    var ctx = canvas.getContext('2d');
    var ratio = Math.min(window.devicePixelRatio || 1, 2);
    var r = canvas.getBoundingClientRect();
    canvas.width = Math.max(300, r.width) * ratio;
    canvas.height = 150 * ratio;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#E9F0F5';

    var drawing = false, empty = true, lx = 0, ly = 0;

    function pos(ev) {
      var box = canvas.getBoundingClientRect();
      return { x: ev.clientX - box.left, y: ev.clientY - box.top };
    }
    canvas.addEventListener('pointerdown', function (ev) {
      drawing = true;
      var p = pos(ev); lx = p.x; ly = p.y;
      try { canvas.setPointerCapture(ev.pointerId); } catch (err) {}
    });
    canvas.addEventListener('pointermove', function (ev) {
      if (!drawing) return;
      var p = pos(ev);
      ctx.beginPath(); ctx.moveTo(lx, ly); ctx.lineTo(p.x, p.y); ctx.stroke();
      lx = p.x; ly = p.y;
      if (empty) {
        empty = false;
        var st = document.getElementById('sig-state');
        if (st) st.textContent = 'Firma registrada';
      }
    });
    function end() {
      if (!drawing) return;
      drawing = false;
      try { WIZ.firma = canvas.toDataURL('image/png'); } catch (err) {}
    }
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointerleave', end);
    canvas.addEventListener('pointercancel', end);

    canvas.__clear = function () {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      empty = true; WIZ.firma = '';
    };
  }

  /* ------------------------- guardar checklist --------------------------- */
  function guardarChecklist() {
    var pl = DB.findPlantilla(WIZ.plantillaId);
    var eq = equipoById(WIZ.equipoId);
    if (!pl || !eq) { UI.toast('Faltan datos del checklist', 'err'); return; }
    var c = countResumen();
    if (c.answered < c.total) { UI.toast('Faltan ítems por evaluar', 'err'); return; }
    if (!WIZ.firma) { UI.toast('La firma del operador es obligatoria', 'err'); return; }
    var telEl = $('#wiz-phone');
    var tel = telEl ? telEl.value : WIZ.telefono;
    if (DB.normPhone(tel).length < 11) { UI.toast('Teléfono de destino no válido', 'err'); return; }

    var patente = String(WIZ.patente || '').trim().toUpperCase();
    var kmTexto = String(WIZ.kilometraje || '').trim().replace(/\./g, '');
    if (patente.length < 4) { UI.toast('Ingresa la patente del equipo', 'err'); return; }
    if (!/^\d{1,9}$/.test(kmTexto)) { UI.toast('El kilometraje u horómetro debe ser un número', 'err'); return; }
    if (!WIZ.ultimaMantencion || !WIZ.proximaMantencion) { UI.toast('Completa la última y la próxima mantención', 'err'); return; }
    if (WIZ.proximaMantencion < WIZ.ultimaMantencion) { UI.toast('La próxima mantención no puede ser anterior a la última', 'err'); return; }

    var respuestas = pl.items.map(function (it) {
      var v = WIZ.respuestas[it.id];
      return { itemId: it.id, txt: it.txt, sec: it.sec, crit: !!it.crit, valor: v, obs: v === 'no' ? (WIZ.obs[it.id] || '') : '' };
    });
    var estado = DB.estadoDe(respuestas);

    var ins = DB.saveInspeccion({
      plantillaId: pl.id, plantillaNombre: pl.nombre,
      equipoId: eq.id, equipoCodigo: eq.codigo, equipoNombre: eq.nombre,
      patente: patente, kilometraje: Number(kmTexto),
      ultimaMantencion: WIZ.ultimaMantencion, proximaMantencion: WIZ.proximaMantencion,
      usuarioId: S.user.id, usuarioNombre: S.user.nombre, usuarioRut: S.user.rut, usuarioTelefono: tel,
      creado: new Date().toISOString(), estado: estado, respuestas: respuestas,
      observaciones: WIZ.observaciones || '', firma: WIZ.firma,
      whatsapp: { enviado: false, destino: DB.normPhone(tel), intentos: 0 }
    });

    WIZ = null;
    UI.toast('Checklist guardado · ' + estado);
    go('insp', { id: ins.id });
    setTimeout(function () { abrirWhatsapp(DB.findInspeccion(ins.id), function () { renderView(); }); }, 420);
  }

  /* -------------------------------- export ------------------------------- */
  function exportarHistorial() {
    if (typeof XLSX === 'undefined') { UI.toast('Módulo Excel no disponible', 'err'); return; }
    var list = histFiltradas();
    var aoa = [['N° registro', 'Fecha', 'Hora', 'Código equipo', 'Equipo', 'Patente', 'Kilometraje', 'Última mantención', 'Próxima mantención', 'Checklist', 'Operador', 'RUT', 'Estado', 'Ítems', 'Ítems con M', 'WhatsApp', 'Fecha envío', 'Observaciones']];
    list.forEach(function (i) {
      aoa.push([
        codigoCorto(i), DB.fecha(i.creado), DB.hora(i.creado), i.equipoCodigo, i.equipoNombre,
        i.patente || '', i.kilometraje != null ? i.kilometraje : '', fmtFecha(i.ultimaMantencion), fmtFecha(i.proximaMantencion),
        i.plantillaNombre, i.usuarioNombre, i.usuarioRut, i.estado, i.respuestas.length,
        i.respuestas.filter(function (r) { return r.valor === 'no'; }).length,
        i.whatsapp && i.whatsapp.enviado ? 'Confirmado' : 'Pendiente',
        i.whatsapp && i.whatsapp.fechaEnvio ? DB.fechaHora(i.whatsapp.fechaEnvio) : '',
        i.observaciones || ''
      ]);
    });
    var ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!cols'] = [{ wch: 12 }, { wch: 12 }, { wch: 8 }, { wch: 13 }, { wch: 26 }, { wch: 12 }, { wch: 12 }, { wch: 15 }, { wch: 15 }, { wch: 34 }, { wch: 24 }, { wch: 14 }, { wch: 18 }, { wch: 8 }, { wch: 12 }, { wch: 13 }, { wch: 18 }, { wch: 44 }];
    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Checklists');
    XLSX.writeFile(wb, 'Checklists_' + DB.fecha(new Date().toISOString()) + '.xlsx');
    UI.toast('Exportados ' + list.length + ' registros');
  }

  function exportarUsuarios() {
    if (typeof XLSX === 'undefined') return;
    var eqs = DB.equipos();
    var aoa = [['Nombre completo', 'RUT', 'Correo', 'Teléfono', 'Rol', 'Cargo', 'Equipos asignados', 'Estado']];
    DB.users().forEach(function (u) {
      var nombres = (u.equipos || []).map(function (id) { var e = eqs.filter(function (x) { return x.id === id; })[0]; return e ? e.codigo : ''; }).join(', ');
      aoa.push([u.nombre, u.rut, u.email, u.telefono, u.rol, u.cargo || '', nombres, u.activo ? 'Activo' : 'Inactivo']);
    });
    var ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!cols'] = [{ wch: 28 }, { wch: 14 }, { wch: 28 }, { wch: 18 }, { wch: 12 }, { wch: 22 }, { wch: 26 }, { wch: 10 }];
    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Usuarios');
    XLSX.writeFile(wb, 'Usuarios_' + DB.fecha(new Date().toISOString()) + '.xlsx');
  }

  function guardarAjustes() {
    var st = DB.get().settings;
    st.empresa = $('#s-empresa').value.trim();
    st.proyecto = $('#s-proyecto').value.trim();
    st.contrato = $('#s-contrato').value.trim();
    st.mensaje = $('#s-mensaje').value;
    st.whatsappApi = $('#s-api').value;
    DB.save();
    UI.toast('Configuración guardada');
  }

  /* -------------------------------- cuenta ------------------------------- */
  function abrirCuenta() {
    var u = S.user;
    var body = '<div class="dl" style="margin-bottom:16px"><dt>Nombre</dt><dd>' + E(u.nombre) + '</dd>' +
      '<dt>RUT</dt><dd>' + E(u.rut) + '</dd><dt>Correo</dt><dd>' + E(u.email) + '</dd>' +
      '<dt>Celular</dt><dd>' + E(u.telefono) + '</dd>' +
      '<dt>Rol</dt><dd>' + E(u.rol === 'admin' ? 'Administrador' : u.rol === 'supervisor' ? 'Supervisor' : 'Operador') + '</dd></div>' +
      '<div class="form-sep"></div>' +
      '<div class="form-row c2"><div class="field"><label for="cp-1">Nueva contraseña</label><input id="cp-1" type="password" placeholder="Mínimo 6 caracteres"></div>' +
      '<div class="field"><label for="cp-2">Repetir contraseña</label><input id="cp-2" type="password"></div></div>';
    UI.modal({
      title: 'Mi cuenta', subtitle: 'Datos de acceso y seguridad.', size: 'lg', body: body,
      actions: [
        { label: 'Cerrar sesión', className: 'btn-danger', onClick: function () { UI.closeModal(); DB.logout(); S.user = null; WIZ = null; renderLogin(); } },
        { label: 'Cambiar contraseña', className: 'btn-primary', onClick: function () {
            var p1 = $('#cp-1').value, p2 = $('#cp-2').value;
            if (p1.length < 6) { UI.toast('La contraseña debe tener al menos 6 caracteres', 'err'); return; }
            if (p1 !== p2) { UI.toast('Las contraseñas no coinciden', 'err'); return; }
            DB.setPassword(u.id, p1);
            UI.closeModal(); UI.toast('Contraseña actualizada');
          } },
        { label: 'Cerrar', className: 'btn-ghost', onClick: function () { UI.closeModal(); } }
      ]
    });
  }

  /* ------------------------------ instalación ---------------------------- */
  function mostrarInstalacion() {
    var ios = /iPad|iPhone|iPod/.test(navigator.userAgent);
    var body = '<div class="small" style="line-height:1.75;color:#C6D4DE">' +
      '<p style="margin-bottom:12px"><b>Android (Chrome)</b></p>' +
      '<ol style="margin:0 0 16px;padding-left:20px"><li>Abre esta página en Chrome.</li><li>Toca el menú ⋮ (arriba a la derecha).</li><li>Elige <b>Instalar aplicación</b> o <b>Añadir a pantalla de inicio</b>.</li></ol>' +
      '<p style="margin-bottom:12px"><b>iPhone / iPad (Safari)</b></p>' +
      '<ol style="margin:0 0 16px;padding-left:20px"><li>Abre esta página en Safari.</li><li>Toca el botón <b>Compartir</b> (cuadrado con flecha).</li><li>Elige <b>Añadir a pantalla de inicio</b> y confirma.</li></ol>' +
      '<p style="margin-bottom:8px"><b>Versión instalable (APK / App Store)</b></p>' +
      '<p class="muted">El proyecto incluye la configuración para empaquetar la app con Capacitor y generar el APK de Android o el proyecto de iOS. Revisa el archivo <span class="mono">README.md</span> incluido en la entrega.</p></div>';
    if (DEFERRED) {
      body = '<div class="card card-pad" style="margin-bottom:14px;border-color:rgba(255,176,32,.3);background:rgba(255,176,32,.06)">' +
        '<div style="font-weight:600;margin-bottom:6px">Tu navegador permite instalar la app</div>' +
        '<div class="small muted" style="margin-bottom:12px">Se agregará un ícono a tu pantalla de inicio y funcionará sin conexión.</div>' +
        '<button type="button" class="btn btn-primary btn-sm" data-act="install-go">Instalar ahora</button></div>' + body;
    }
    UI.modal({ title: 'Instalar Check List Maquinarias ENTS', subtitle: ios ? 'Instrucciones para iPhone / iPad' : 'Instrucciones para Android e iPhone', size: 'lg', body: body, actions: [{ label: 'Entendido', className: 'btn-primary', onClick: function () { UI.closeModal(); } }] });
  }

  function registerPWA() {
    if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) {
      window.addEventListener('load', function () {
        navigator.serviceWorker.register('sw.js').catch(function () {});
      });
    }
    window.addEventListener('beforeinstallprompt', function (e) {
      e.preventDefault();
      DEFERRED = e;
      var b = document.getElementById('btn-install');
      if (b) b.style.display = 'inline-flex';
    });
  }

})();
