/*
 * Check List Maquinarias ENTS — conexión con la base compartida
 * -------------------------------------------------------------
 * Cuando la aplicación está conectada a un servidor, todos los equipos
 * trabajan sobre la misma información: usuarios, check lists, equipos y
 * registros. Si el equipo queda sin señal, sigue funcionando con la copia
 * local y sincroniza al recuperar la conexión.
 */
(function (global) {
  'use strict';

  var CLAVE = 'clm_api_v1';
  var cfg = { url: '', token: '', usuario: null, ultima: '', estado: 'sin-configurar', error: '' };

  try {
    var guardado = global.localStorage.getItem(CLAVE);
    if (guardado) cfg = Object.assign(cfg, JSON.parse(guardado));
  } catch (e) { /* sin configuración previa */ }

  function persistir() {
    try { global.localStorage.setItem(CLAVE, JSON.stringify(cfg)); } catch (e) { /* almacenamiento lleno */ }
  }

  function normalizar(url) {
    var u = String(url || '').trim();
    if (!u) return '';
    if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
    return u.replace(/\/+$/, '');
  }

  function activo() { return !!cfg.url; }

  function sesion() { return !!(cfg.url && cfg.token); }

  function info() {
    return {
      url: cfg.url,
      activo: activo(),
      sesion: sesion(),
      usuario: cfg.usuario,
      ultima: cfg.ultima,
      estado: cfg.estado,
      error: cfg.error
    };
  }

  function pedir(ruta, opciones) {
    var opt = opciones || {};
    var cabeceras = { 'Content-Type': 'application/json' };
    if (cfg.token) cabeceras.Authorization = 'Bearer ' + cfg.token;

    var control = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var temporizador = control ? setTimeout(function () { control.abort(); }, 15000) : null;

    return fetch(cfg.url + ruta, {
      method: opt.metodo || 'GET',
      headers: cabeceras,
      body: opt.cuerpo ? JSON.stringify(opt.cuerpo) : undefined,
      signal: control ? control.signal : undefined
    }).then(function (respuesta) {
      if (temporizador) clearTimeout(temporizador);
      return respuesta.json().catch(function () { return {}; }).then(function (datos) {
        if (!respuesta.ok) {
          var error = new Error((datos && datos.error) || ('Error ' + respuesta.status));
          error.status = respuesta.status;
          throw error;
        }
        return datos;
      });
    }).catch(function (e) {
      if (temporizador) clearTimeout(temporizador);
      throw e;
    });
  }

  function marcar(estado, error) {
    cfg.estado = estado;
    cfg.error = error || '';
    persistir();
    if (global.document && document.dispatchEvent) {
      document.dispatchEvent(new CustomEvent('api-estado', { detail: info() }));
    }
  }

  function probar(url) {
    var destino = normalizar(url);
    if (!destino) return Promise.reject(new Error('Escribe la dirección del servidor.'));
    return fetch(destino + '/api/salud').then(function (r) {
      if (!r.ok) throw new Error('El servidor respondió con error ' + r.status);
      return r.json();
    });
  }

  function conectar(url, correo, clave) {
    var destino = normalizar(url);
    if (!destino) return Promise.reject(new Error('Escribe la dirección del servidor.'));
    cfg.url = destino;
    cfg.token = '';
    return pedir('/api/auth/login', { metodo: 'POST', cuerpo: { correo: correo, clave: clave } })
      .then(function (datos) {
        cfg.token = datos.token;
        cfg.usuario = datos.usuario;
        marcar('conectado');
        return datos;
      })
      .catch(function (e) {
        marcar('error', e.message);
        throw e;
      });
  }

  function desconectar() {
    cfg.url = '';
    cfg.token = '';
    cfg.usuario = null;
    cfg.ultima = '';
    cfg.estado = 'sin-configurar';
    cfg.error = '';
    persistir();
  }

  /* ----------------------------- sincronización ---------------------------- */

  function limpiarUsuario(u) {
    return {
      id: u.id,
      nombre: u.nombre,
      rut: u.rut,
      email: u.email,
      telefono: u.telefono,
      rol: u.rol,
      cargo: u.cargo || '',
      equipos: u.equipos || [],
      activo: u.activo !== false,
      creado: u.creado || ''
    };
  }

  var clavesPendientes = {};

  function registrarClave(correo, clave) {
    var c = String(correo || '').trim().toLowerCase();
    if (c && clave) clavesPendientes[c] = String(clave);
  }

  function paquete() {
    var yo = global.S && global.S.user ? global.S.user : (global.DB ? DB.currentUser() : null);
    var esGestor = yo && (yo.rol === 'admin' || yo.rol === 'supervisor');
    var salida = {
      inspecciones: global.DB.inspecciones(),
      borrados: global.DB.borradosPendientes ? DB.borradosPendientes() : []
    };
    if (esGestor) {
      salida.usuarios = global.DB.users().map(limpiarUsuario);
      if (Object.keys(clavesPendientes).length) salida.claves = clavesPendientes;
      salida.plantillas = global.DB.plantillas();
      salida.equipos = global.DB.equipos();
      salida.ajustes = global.DB.get().settings;
    }
    return salida;
  }

  var empujando = false;
  var pendiente = false;

  function empujar() {
    if (!sesion()) return Promise.resolve(false);
    if (empujando) { pendiente = true; return Promise.resolve(false); }
    empujando = true;
    return pedir('/api/sincronizar', { metodo: 'POST', cuerpo: paquete() })
      .then(function (datos) {
        if (global.DB.limpiarBorrados) DB.limpiarBorrados();
        clavesPendientes = {};
        if (datos && datos.actualizado) cfg.ultima = datos.actualizado;
        marcar('conectado');
        return true;
      })
      .catch(function (e) {
        if (e.status === 401) marcar('sesion-vencida', 'La sesión del servidor venció. Vuelve a entrar.');
        else marcar('sin-conexion', e.message);
        return false;
      })
      .then(function (r) {
        empujando = false;
        if (pendiente) { pendiente = false; setTimeout(empujar, 400); }
        return r;
      });
  }

  function jalar() {
    if (!sesion()) return Promise.resolve(false);
    return pedir('/api/sincronizar')
      .then(function (datos) {
        if (datos && global.DB.aplicarRemoto) DB.aplicarRemoto(datos);
        cfg.ultima = (datos && datos.actualizado) || new Date().toISOString();
        marcar('conectado');
        return datos || true;
      })
      .catch(function (e) {
        marcar(e.status === 401 ? 'sesion-vencida' : 'sin-conexion', e.message);
        return false;
      });
  }

  var temporizador = null;
  function autoPush() {
    if (!sesion()) return;
    if (temporizador) clearTimeout(temporizador);
    temporizador = setTimeout(function () { empujar(); }, 1200);
  }

  function sincronizar() {
    if (!sesion()) return Promise.resolve(false);
    return jalar().then(function (ok) { return empujar().then(function () { return ok; }); });
  }

  function descargarPdf(id) {
    if (!cfg.url || !cfg.token) return Promise.reject(new Error('Conecta la base compartida para generar el PDF.'));
    return fetch(cfg.url + '/api/inspecciones/' + encodeURIComponent(id) + '/pdf', {
      headers: { Authorization: 'Bearer ' + cfg.token }
    }).then(function (r) {
      if (!r.ok) {
        return r.json().catch(function () { return {}; }).then(function (d) {
          throw new Error((d && d.error) || 'No se pudo generar el PDF');
        });
      }
      var nombre = 'Checklist_' + String(id).slice(-6).toUpperCase() + '.pdf';
      return r.blob().then(function (blob) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url; a.download = nombre;
        document.body.appendChild(a); a.click();
        setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 1500);
        return nombre;
      });
    });
  }

  function enviarPdf(id, telefono) {
    return pedir('/api/inspecciones/' + encodeURIComponent(id) + '/whatsapp', {
      metodo: 'POST',
      cuerpo: { telefono: telefono, pdf: true }
    });
  }

  global.API = {
    info: info,
    activo: activo,
    sesion: sesion,
    normalizar: normalizar,
    probar: probar,
    conectar: conectar,
    desconectar: desconectar,
    registrarClave: registrarClave,
    login: function (correo, clave) { return pedir('/api/auth/login', { metodo: 'POST', cuerpo: { correo: correo, clave: clave } }); },
    empujar: empujar,
    jalar: jalar,
    sincronizar: sincronizar,
    autoPush: autoPush,
    descargarPdf: descargarPdf,
    enviarPdf: enviarPdf,
    guardarToken: function (token, usuario) { cfg.token = token; cfg.usuario = usuario; marcar('conectado'); }
  };
})(window);
