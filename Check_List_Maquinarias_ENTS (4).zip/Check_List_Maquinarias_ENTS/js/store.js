/* =========================================================================
   Check List Maquinarias ENTS — Capa de datos y reglas de negocio (modo local / PWA)
   Los datos se guardan en el dispositivo del usuario (localStorage).
   ========================================================================= */
(function (global) {
  'use strict';

  var KEY = 'clm_ents_v1';
  var SKEY = 'clmpro_session';

  /* ---------------------------- utilidades ---------------------------- */
  function uid(prefix) {
    return (prefix || 'id') + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 7);
  }

  function utf8(s) { return unescape(encodeURIComponent(String(s))); }

  function sha256(ascii) {
    function rr(v, a) { return (v >>> a) | (v << (32 - a)); }
    var mathPow = Math.pow, maxWord = mathPow(2, 32), result = '', words = [],
        asciiBitLength = ascii.length * 8,
        hash = sha256.h = sha256.h || [], k = sha256.k = sha256.k || [],
        primeCounter = k.length, isComposite = {};
    for (var candidate = 2; primeCounter < 64; candidate++) {
      if (!isComposite[candidate]) {
        for (var x = 0; x < 313; x += candidate) isComposite[x] = candidate;
        hash[primeCounter] = (mathPow(candidate, 0.5) * maxWord) | 0;
        k[primeCounter++] = (mathPow(candidate, 1 / 3) * maxWord) | 0;
      }
    }
    ascii += '\x80';
    while (ascii.length % 64 - 56) ascii += '\x00';
    for (var i = 0; i < ascii.length; i++) {
      var j = ascii.charCodeAt(i);
      if (j >> 8) return '';
      words[i >> 2] |= j << ((3 - i) % 4) * 8;
    }
    words[words.length] = ((asciiBitLength / maxWord) | 0);
    words[words.length] = (asciiBitLength);
    for (var w2 = 0; w2 < words.length;) {
      var w = words.slice(w2, w2 += 16), oldHash = hash;
      hash = hash.slice(0, 8);
      for (i = 0; i < 64; i++) {
        var w15 = w[i - 15], ww2 = w[i - 2], a = hash[0], e = hash[4];
        var temp1 = hash[7] + (rr(e, 6) ^ rr(e, 11) ^ rr(e, 25)) +
          ((e & hash[5]) ^ ((~e) & hash[6])) + k[i] +
          (w[i] = (i < 16) ? w[i] : (
            w[i - 16] + (rr(w15, 7) ^ rr(w15, 18) ^ (w15 >>> 3)) +
            w[i - 7] + (rr(ww2, 17) ^ rr(ww2, 19) ^ (ww2 >>> 10))) | 0);
        var temp2 = (rr(a, 2) ^ rr(a, 13) ^ rr(a, 22)) +
          ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
        hash = [(temp1 + temp2) | 0].concat(hash);
        hash[4] = (hash[4] + temp1) | 0;
      }
      for (i = 0; i < 8; i++) hash[i] = (hash[i] + oldHash[i]) | 0;
    }
    for (i = 0; i < 8; i++) {
      for (j = 3; j + 1; j--) {
        var b = (hash[i] >> (j * 8)) & 255;
        result += ((b < 16) ? 0 : '') + b.toString(16);
      }
    }
    return result;
  }

  function hashPass(pass, salt) {
    return sha256(utf8(salt + '::' + pass + '::clmpro'));
  }

  function randomSalt() {
    var s = '';
    var abc = 'abcdefghijkmnpqrstuvwxyz23456789';
    for (var i = 0; i < 12; i++) s += abc[Math.floor(Math.random() * abc.length)];
    return s;
  }

  function tempPassword() {
    var a = 'ABCDEFGHJKLMNPQRSTUVWXYZ', b = 'abcdefghijkmnpqrstuvwxyz', n = '23456789';
    var p = '';
    p += a[Math.floor(Math.random() * a.length)];
    p += b[Math.floor(Math.random() * b.length)];
    for (var i = 0; i < 4; i++) p += n[Math.floor(Math.random() * n.length)];
    return p + n[Math.floor(Math.random() * n.length)];
  }

  /* ------------------------------ RUT -------------------------------- */
  function limpiarRut(rut) { return String(rut || '').replace(/[^0-9kK]/g, '').toUpperCase(); }

  function validaRut(rut) {
    var s = limpiarRut(rut);
    if (s.length < 8 || s.length > 9) return false;
    var cuerpo = s.slice(0, -1), dv = s.slice(-1);
    if (!/^\d+$/.test(cuerpo)) return false;
    var suma = 0, mult = 2;
    for (var i = cuerpo.length - 1; i >= 0; i--) {
      suma += parseInt(cuerpo.charAt(i), 10) * mult;
      mult = mult === 7 ? 2 : mult + 1;
    }
    var res = 11 - (suma % 11);
    var esperado = res === 11 ? '0' : (res === 10 ? 'K' : String(res));
    return esperado === dv;
  }

  function fmtRut(rut) {
    var s = limpiarRut(rut);
    if (s.length < 2) return String(rut || '');
    var cuerpo = s.slice(0, -1), dv = s.slice(-1);
    var out = '';
    for (var i = 0; i < cuerpo.length; i++) {
      var pos = cuerpo.length - i;
      out += cuerpo.charAt(i);
      if (pos > 1 && (pos - 1) % 3 === 0) out += '.';
    }
    return out + '-' + dv;
  }

  /* ----------------------------- teléfono ---------------------------- */
  function normPhone(tel) {
    var d = String(tel || '').replace(/[^0-9]/g, '');
    if (!d) return '';
    if (d.indexOf('56') === 0) d = d.slice(2);
    if (d.charAt(0) === '0') d = d.slice(1);
    if (d.length === 8) d = '9' + d; // celular sin el 9
    return '56' + d;
  }

  function fmtPhone(tel) {
    var d = normPhone(tel);
    if (d.length < 11) return tel || '';
    return '+' + d.slice(0, 2) + ' ' + d.slice(2, 3) + ' ' + d.slice(3, 7) + ' ' + d.slice(7);
  }

  /* ------------------------------ fechas ----------------------------- */
  var MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  var DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function d(iso) { return iso ? new Date(iso) : new Date(); }

  function fecha(iso) {
    var x = d(iso);
    return pad(x.getDate()) + '-' + pad(x.getMonth() + 1) + '-' + x.getFullYear();
  }
  function hora(iso) {
    var x = d(iso);
    return pad(x.getHours()) + ':' + pad(x.getMinutes());
  }
  function fechaLarga(iso) {
    var x = d(iso);
    return DIAS[x.getDay()] + ' ' + x.getDate() + ' de ' + MESES[x.getMonth()] + ' de ' + x.getFullYear();
  }
  function fechaHora(iso) { return fecha(iso) + ' · ' + hora(iso); }
  function diaClave(iso) {
    var x = d(iso);
    return x.getFullYear() + '-' + pad(x.getMonth() + 1) + '-' + pad(x.getDate());
  }
  function hoyClave() { return diaClave(new Date().toISOString()); }

  /* ------------------------------- seed ------------------------------ */
  function item(sec, txt, crit, criterio) {
    return { id: uid('it'), sec: sec, txt: txt, crit: !!crit, criterio: criterio || '' };
  }

  function seed() {
    var admin = {
      id: uid('us'), nombre: 'Administrador ENTS', rut: '11.111.111-1',
      email: 'admin@ents.cl', telefono: '+56 9 1111 1111',
      rol: 'admin', cargo: 'Administrador del sistema', equipos: [], activo: true,
      pass: null, salt: null, createdAt: new Date().toISOString()
    };
    admin.salt = randomSalt();
    admin.pass = hashPass('Admin2026', admin.salt);

    var jefe = {
      id: uid('us'), nombre: 'Rodrigo Salinas Fuentes', rut: '13.456.789-0',
      email: 'supervisor@ents.cl', telefono: '+56 9 2222 2222',
      rol: 'supervisor', cargo: 'Supervisor de equipos', equipos: [], activo: true,
      pass: null, salt: null, createdAt: new Date().toISOString()
    };
    jefe.salt = randomSalt();
    jefe.pass = hashPass('Supervisor2026', jefe.salt);

    /* Catálogo base: un equipo por cada tipo de maquinaria del checklist oficial */
    var base = (typeof CL_DATA !== 'undefined' && CL_DATA) ? CL_DATA : [];
    var equipos = base.map(function (t, i) {
      return {
        id: uid('eq'), codigo: t.pref + '-' + ('00' + (i + 1)).slice(-3),
        nombre: t.nombre, tipo: t.tipo, marca: '', modelo: '', patente: '',
        faena: 'Minera Escondida', activo: true
      };
    });

    function eqPorTipo(tipo) {
      for (var i = 0; i < equipos.length; i++) if (equipos[i].tipo === tipo) return equipos[i];
      return equipos[0];
    }

    var operador = {
      id: uid('us'), nombre: 'Juan Pérez Morales', rut: '15.876.432-1',
      email: 'operador@ents.cl', telefono: '+56 9 3333 3333',
      rol: 'operador', cargo: 'Operador de equipos',
      equipos: [eqPorTipo('Camioneta').id, eqPorTipo('Camión Tolva').id, eqPorTipo('Grúa Horquilla').id],
      activo: true, pass: null, salt: null, createdAt: new Date().toISOString()
    };
    operador.salt = randomSalt();
    operador.pass = hashPass('Operador2026', operador.salt);

    var plantillas = base.map(function (t) {
      return {
        id: uid('pl'),
        nombre: 'Checklist Diario — ' + t.nombre,
        tipo: t.tipo,
        frecuencia: 'Diario',
        items: t.items.map(function (it) {
          return { id: uid('it'), sec: it[0], txt: it[1], crit: false, criterio: '' };
        }),
        fuente: 'Check List Maquinarias y Vehículos rev. 0',
        createdAt: new Date().toISOString()
      };
    });

    function idxTipo(tipo) {
      for (var i = 0; i < plantillas.length; i++) if (plantillas[i].tipo === tipo) return i;
      return 0;
    }

    function mkInsp(o) {
      var pl = plantillas[o.pl];
      var eq = eqPorTipo(pl.tipo);
      var respuestas = pl.items.map(function (it, idx) {
        var v = o.malo && o.malo.indexOf(idx) >= 0 ? 'no' : 'si';
        return { itemId: it.id, txt: it.txt, sec: it.sec, crit: it.crit, valor: v, obs: v === 'no' ? (o.obsItem || 'Requiere corrección antes de operar') : '' };
      });
      var estado = o.malo && o.malo.length ? 'Con observaciones' : 'Aprobado';
      return {
        id: uid('insp'), plantillaId: pl.id, plantillaNombre: pl.nombre,
        equipoId: eq.id, equipoCodigo: eq.codigo, equipoNombre: eq.nombre,
        usuarioId: operador.id, usuarioNombre: operador.nombre, usuarioRut: operador.rut, usuarioTelefono: operador.telefono,
        creado: o.creado, estado: estado, respuestas: respuestas,
        observaciones: o.obs || '', firma: '',
        whatsapp: { enviado: !!o.enviado, fechaEnvio: o.enviado ? o.creado : null, destino: normPhone(operador.telefono), intentos: o.enviado ? 1 : 0 }
      };
    }

    var now = Date.now();
    var inspecciones = [
      mkInsp({ pl: idxTipo('Camioneta'), creado: new Date(now - 3 * 3600e3).toISOString(), enviado: true }),
      mkInsp({ pl: idxTipo('Grúa'), creado: new Date(now - 2.2 * 3600e3).toISOString(), malo: [8], enviado: false, obs: 'Baliza izquierda intermitente. Se avisa a mantenimiento.' }),
      mkInsp({ pl: idxTipo('Grúa Horquilla'), creado: new Date(now - 26 * 3600e3).toISOString(), enviado: true }),
      mkInsp({ pl: idxTipo('Camión Tolva'), creado: new Date(now - 50 * 3600e3).toISOString(), malo: [18], enviado: true, obs: 'Fuga de aceite hidráulico, equipo fuera de servicio.', obsItem: 'Manguera hidráulica con fuga: equipo detenido' }),
      mkInsp({ pl: idxTipo('Excavadora'), creado: new Date(now - 74 * 3600e3).toISOString(), enviado: true }),
      mkInsp({ pl: idxTipo('Retroexcavadora'), creado: new Date(now - 98 * 3600e3).toISOString(), malo: [8], enviado: true, obs: 'Humedad de aceite en manguera de elevación.' })
    ];

    return {
      version: 2,
      settings: {
        empresa: 'ENTS',
        proyecto: 'Minera Escondida — Proyecto EMTS',
        contrato: '26810-220-HC1-MZ00-00003',
        logoTexto: 'Check List Maquinarias ENTS',
        mensaje: 'Hola {{nombre}}, se registró el check list *{{checklist}}* del equipo *{{equipo}}* ({{codigo}}) — patente *{{patente}}*, kilometraje {{kilometraje}}, última mantención {{ultimaMantencion}}, próxima {{proximaMantencion}} — el {{fecha}} a las {{hora}}.\n\nResultado: *{{estado}}*\nÍtems evaluados: {{evaluados}} · Ítems con M (malo): {{noconformes}}\n{{observaciones}}\n\nRegistro N° {{id}}. — {{empresa}}',
        whatsappApi: 'enlace',
        pais: '+56'
      },
      users: [admin, jefe, operador],
      equipos: equipos,
      plantillas: plantillas,
      inspecciones: inspecciones
    };
  }

  /* ------------------------------ almacén ---------------------------- */
  var state = null;

  function load() {
    if (state) return state;
    var raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) { raw = null; }
    if (raw) {
      try { state = JSON.parse(raw); } catch (e) { state = null; }
    }
    if (!state || !state.users) { state = seed(); save(); }
    if (!state.settings) state.settings = seed().settings;
    return state;
  }

  var sinEmpujar = false;

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); }
    catch (e) { console.warn('No se pudo guardar', e); }
    if (!sinEmpujar && typeof window !== 'undefined' && window.API && window.API.autoPush) {
      try { window.API.autoPush(); } catch (e) { /* sin conexión */ }
    }
    return state;
  }

  /* ------------------- base compartida (sincronización) ------------------ */
  var CLAVE_BORRADOS = 'clm_borrados_v1';

  function borradosPendientes() {
    try { return JSON.parse(localStorage.getItem(CLAVE_BORRADOS) || '[]'); } catch (e) { return []; }
  }

  function marcarBorrado(tipo, id) {
    var lista = borradosPendientes();
    lista.push({ tipo: tipo, id: id, fecha: new Date().toISOString() });
    try { localStorage.setItem(CLAVE_BORRADOS, JSON.stringify(lista)); } catch (e) { /* sin espacio */ }
  }

  function limpiarBorrados() {
    try { localStorage.removeItem(CLAVE_BORRADOS); } catch (e) { /* nada */ }
  }

  function normalizarPlantillaRemota(p) {
    var items = (p.items || []).map(function (it, i) {
      return {
        id: it.id || ('i' + (i + 1)),
        sec: it.sec || 'General',
        txt: it.txt || '',
        criterio: it.criterio || '',
        crit: !!it.crit
      };
    });
    return {
      id: p.id || uid('pl'),
      tipo: p.tipo || 'General',
      nombre: p.nombre || 'Checklist',
      frecuencia: p.frecuencia || 'Diario',
      fuente: p.fuente || 'Base compartida',
      createdAt: p.creado || p.actualizado || new Date().toISOString(),
      items: items
    };
  }

  /* Reemplaza la información local con la que viene del servidor. */
  function aplicarRemoto(b) {
    if (!b) return false;
    var s = load();
    sinEmpujar = true;
    try {
      if (Array.isArray(b.usuarios) && b.usuarios.length) {
        var previos = {};
        s.users.forEach(function (u) { previos[u.id] = u; previos[String(u.email || '').toLowerCase()] = u; });
        s.users = b.usuarios.map(function (u) {
          var prev = previos[u.id] || previos[String(u.email || '').toLowerCase()] || null;
          var salt = prev ? prev.salt : randomSalt();
          return {
            id: u.id,
            nombre: u.nombre || '',
            rut: fmtRut(u.rut || ''),
            email: String(u.email || '').toLowerCase(),
            telefono: fmtPhone(u.telefono || ''),
            rol: u.rol || 'operador',
            cargo: u.cargo || '',
            equipos: u.equipos || [],
            activo: u.activo !== false,
            createdAt: u.creado || (prev ? prev.createdAt : '') || new Date().toISOString(),
            salt: salt,
            pass: prev ? prev.pass : hashPass(randomSalt(), salt),
            mustChange: false
          };
        });
      }
      if (Array.isArray(b.plantillas) && b.plantillas.length) s.plantillas = b.plantillas.map(normalizarPlantillaRemota);
      if (Array.isArray(b.equipos) && b.equipos.length) s.equipos = b.equipos;
      if (Array.isArray(b.inspecciones)) {
        var mapa = {};
        s.inspecciones.forEach(function (i) { if (i && i.id) mapa[i.id] = i; });
        b.inspecciones.forEach(function (i) { if (i && i.id) mapa[i.id] = Object.assign(mapa[i.id] || {}, i); });
        s.inspecciones = Object.keys(mapa).map(function (k) { return mapa[k]; });
        s.inspecciones.sort(function (a, b2) { return String(b2.creado).localeCompare(String(a.creado)); });
      }
      if (b.ajustes) {
        ['empresa', 'proyecto', 'contrato', 'mensaje', 'whatsappApi'].forEach(function (k) {
          if (typeof b.ajustes[k] === 'string' && b.ajustes[k]) s.settings[k] = b.ajustes[k];
        });
      }
      save();
      return true;
    } finally {
      sinEmpujar = false;
    }
  }

  /* Deja la sesión iniciada con un usuario que viene del servidor. */
  function entrarRemoto(u, clave) {
    var s = load();
    var local = null;
    for (var i = 0; i < s.users.length; i++) {
      if (s.users[i].id === u.id || String(s.users[i].email).toLowerCase() === String(u.email || '').toLowerCase()) { local = s.users[i]; break; }
    }
    sinEmpujar = true;
    try {
      if (!local) {
        local = { id: u.id || uid('us'), createdAt: new Date().toISOString() };
        s.users.push(local);
      }
      local.id = u.id || local.id;
      local.nombre = u.nombre || local.nombre;
      local.rut = fmtRut(u.rut || '');
      local.email = String(u.email || '').toLowerCase();
      local.telefono = fmtPhone(u.telefono || '');
      local.rol = u.rol || 'operador';
      local.cargo = u.cargo || '';
      local.equipos = u.equipos || [];
      local.activo = true;
      if (clave) { local.salt = randomSalt(); local.pass = hashPass(clave, local.salt); }
      setSession(local.id);
      save();
      return local;
    } finally {
      sinEmpujar = false;
    }
  }

  function reset() {
    state = seed();
    save();
    return state;
  }

  /* ------------------------------ sesión ----------------------------- */
  function currentUser() {
    var id = null;
    try { id = localStorage.getItem(SKEY); } catch (e) { id = null; }
    if (!id) return null;
    var s = load();
    for (var i = 0; i < s.users.length; i++) {
      if (s.users[i].id === id && s.users[i].activo) return s.users[i];
    }
    return null;
  }

  function setSession(userId) {
    try { localStorage.setItem(SKEY, userId); } catch (e) {}
  }

  function logout() {
    try { localStorage.removeItem(SKEY); } catch (e) {}
  }

  function login(ident, pass) {
    var s = load();
    var key = String(ident || '').trim().toLowerCase();
    var rutKey = limpiarRut(ident);
    var u = null;
    for (var i = 0; i < s.users.length; i++) {
      var x = s.users[i];
      if (x.email.toLowerCase() === key || (rutKey && limpiarRut(x.rut) === rutKey)) { u = x; break; }
    }
    if (!u) return { ok: false, error: 'No encontramos una cuenta con ese correo o RUT.' };
    if (!u.activo) return { ok: false, error: 'La cuenta está desactivada. Contacta al administrador.' };
    if (hashPass(pass, u.salt) !== u.pass) return { ok: false, error: 'La contraseña no es correcta.' };
    setSession(u.id);
    return { ok: true, user: u };
  }

  /* ------------------------------ usuarios --------------------------- */
  function getUsers() { return load().users; }
  function findUser(id) { return load().users.filter(function (u) { return u.id === id; })[0] || null; }

  function emailTaken(email, exceptId) {
    var e = String(email || '').trim().toLowerCase();
    return load().users.some(function (u) { return u.email.toLowerCase() === e && u.id !== exceptId; });
  }

  function saveUser(data, id) {
    var s = load();
    var pass = data.password ? String(data.password) : '';
    if (id) {
      var u = findUser(id);
      if (!u) return { ok: false, error: 'Usuario no encontrado' };
      u.nombre = data.nombre; u.rut = fmtRut(data.rut); u.email = data.email;
      u.telefono = fmtPhone(data.telefono); u.rol = data.rol; u.cargo = data.cargo || u.cargo;
      u.equipos = data.equipos || [];
      u.activo = data.activo !== false;
      if (pass) { u.salt = randomSalt(); u.pass = hashPass(pass, u.salt); u.mustChange = false; }
      save();
      return { ok: true, user: u };
    }
    var nu = {
      id: uid('us'), nombre: data.nombre, rut: fmtRut(data.rut), email: data.email,
      telefono: fmtPhone(data.telefono), rol: data.rol, cargo: data.cargo || '',
      equipos: data.equipos || [], activo: data.activo !== false,
      createdAt: new Date().toISOString(), mustChange: true
    };
    var passFinal = pass || tempPassword();
    nu.salt = randomSalt();
    nu.pass = hashPass(passFinal, nu.salt);
    s.users.push(nu);
    save();
    return { ok: true, user: nu, tempPass: passFinal };
  }

  function setPassword(id, pass) {
    var u = findUser(id);
    if (!u) return false;
    u.salt = randomSalt(); u.pass = hashPass(pass, u.salt); u.mustChange = false;
    save(); return true;
  }

  function toggleUser(id) {
    var u = findUser(id);
    if (!u) return false;
    u.activo = !u.activo;
    save(); return u.activo;
  }

  function deleteUser(id) {
    var s = load();
    var u = findUser(id);
    if (!u) return false;
    if (u.rol === 'admin' && s.users.filter(function (x) { return x.rol === 'admin' && x.activo; }).length <= 1) return false;
    s.users = s.users.filter(function (x) { return x.id !== id; });
    marcarBorrado('usuario', id);
    save(); return true;
  }

  /* ------------------------------ equipos ---------------------------- */
  function getEquipos() { return load().equipos; }
  function saveEquipo(data, id) {
    var s = load();
    if (id) {
      var e = s.equipos.filter(function (x) { return x.id === id; })[0];
      if (!e) return null;
      Object.assign(e, data); save(); return e;
    }
    var ne = Object.assign({ id: uid('eq'), activo: true }, data);
    s.equipos.push(ne); save(); return ne;
  }
  function deleteEquipo(id) {
    var s = load();
    s.equipos = s.equipos.filter(function (x) { return x.id !== id; });
    s.users.forEach(function (u) { u.equipos = (u.equipos || []).filter(function (x) { return x !== id; }); });
    save(); return true;
  }

  /* ---------------------------- plantillas --------------------------- */
  function getPlantillas() { return load().plantillas; }
  function findPlantilla(id) { return load().plantillas.filter(function (p) { return p.id === id; })[0] || null; }
  function savePlantilla(data, id) {
    var s = load();
    if (id) {
      var p = findPlantilla(id);
      if (!p) return null;
      Object.assign(p, data); save(); return p;
    }
    var np = Object.assign({ id: uid('pl'), createdAt: new Date().toISOString(), items: [] }, data);
    np.items = (np.items || []).map(function (it) { return { id: it.id || uid('it'), sec: it.sec || 'General', txt: it.txt, crit: !!it.crit, criterio: it.criterio || '' }; });
    s.plantillas.push(np); save(); return np;
  }
  function deletePlantilla(id) {
    var s = load();
    s.plantillas = s.plantillas.filter(function (p) { return p.id !== id; });
    marcarBorrado('plantilla', id);
    save(); return true;
  }

  /* --------------------------- inspecciones -------------------------- */
  function getInspecciones() { return load().inspecciones; }
  function findInspeccion(id) { return load().inspecciones.filter(function (i) { return i.id === id; })[0] || null; }

  function saveInspeccion(data, id) {
    var s = load();
    if (id) {
      var x = findInspeccion(id);
      if (!x) return null;
      Object.assign(x, data); save(); return x;
    }
    var ni = Object.assign({ id: uid('insp'), creado: new Date().toISOString() }, data);
    s.inspecciones.unshift(ni); save(); return ni;
  }

  function estadoDe(respuestas) {
    var no = respuestas.filter(function (r) { return r.valor === 'no'; });
    var critico = no.some(function (r) { return r.crit; });
    if (critico) return 'Rechazado';
    if (no.length) return 'Con observaciones';
    return 'Aprobado';
  }

  function marcarWhatsapp(id, info) {
    var x = findInspeccion(id);
    if (!x) return null;
    x.whatsapp = Object.assign({}, x.whatsapp, info, {
      enviado: true,
      fechaEnvio: info.fechaEnvio || new Date().toISOString(),
      intentos: ((x.whatsapp && x.whatsapp.intentos) || 0) + 1
    });
    save(); return x;
  }

  function deleteInspeccion(id) {
    var s = load();
    s.inspecciones = s.inspecciones.filter(function (i) { return i.id !== id; });
    marcarBorrado('inspeccion', id);
    save(); return true;
  }

  /* ------------------------------ métricas --------------------------- */
  function stats() {
    var s = load();
    var hoy = hoyClave();
    var hace30 = Date.now() - 30 * 864e5;
    var delMes = s.inspecciones.filter(function (i) { return new Date(i.creado).getTime() >= hace30; });
    var items = 0, cumple = 0;
    delMes.forEach(function (i) {
      i.respuestas.forEach(function (r) {
        if (r.valor === 'si' || r.valor === 'no') { items++; if (r.valor === 'si') cumple++; }
      });
    });
    var serie = [];
    for (var k = 6; k >= 0; k--) {
      var dt = new Date(Date.now() - k * 864e5);
      var key = diaClave(dt.toISOString());
      serie.push({
        key: key,
        label: DIAS[dt.getDay()].slice(0, 3),
        dia: dt.getDate(),
        total: s.inspecciones.filter(function (i) { return diaClave(i.creado) === key; }).length
      });
    }
    return {
      hoy: s.inspecciones.filter(function (i) { return diaClave(i.creado) === hoy; }).length,
      total: s.inspecciones.length,
      cumplimiento: items ? Math.round(cumple * 100 / items) : 100,
      sinEnviar: s.inspecciones.filter(function (i) { return !i.whatsapp || !i.whatsapp.enviado; }).length,
      rechazados: delMes.filter(function (i) { return i.estado === 'Rechazado'; }).length,
      equipos: s.equipos.filter(function (e) { return e.activo; }).length,
      usuarios: s.users.filter(function (u) { return u.activo; }).length,
      serie: serie
    };
  }

  /* --------------------------- respaldo ------------------------------ */
  function exportJSON() { return JSON.stringify(load(), null, 2); }
  function importJSON(obj) {
    if (!obj || !obj.users || !obj.equipos) return false;
    state = obj; save(); return true;
  }

  global.DB = {
    init: load, save: save, reset: reset, get: function () { return load(); },
    uid: uid, hashPass: hashPass, tempPassword: tempPassword,
    validaRut: validaRut, fmtRut: fmtRut, limpiarRut: limpiarRut,
    normPhone: normPhone, fmtPhone: fmtPhone,
    fecha: fecha, hora: hora, fechaLarga: fechaLarga, fechaHora: fechaHora, diaClave: diaClave, hoyClave: hoyClave,
    currentUser: currentUser, login: login, logout: logout, setSession: setSession,
    users: getUsers, findUser: findUser, emailTaken: emailTaken, saveUser: saveUser,
    setPassword: setPassword, toggleUser: toggleUser, deleteUser: deleteUser,
    equipos: getEquipos, saveEquipo: saveEquipo, deleteEquipo: deleteEquipo,
    plantillas: getPlantillas, findPlantilla: findPlantilla, savePlantilla: savePlantilla, deletePlantilla: deletePlantilla,
    catalogo: function () { return (typeof CL_DATA !== 'undefined' && CL_DATA) ? CL_DATA : []; },
    tipos: function () {
      var d = (typeof CL_DATA !== 'undefined' && CL_DATA) ? CL_DATA : [], out = [];
      d.forEach(function (t) { var n = (t && t.tipo) ? t.tipo : ''; if (n && out.indexOf(n) < 0) out.push(n); });
      return out;
    },
    aplicarRemoto: aplicarRemoto, entrarRemoto: entrarRemoto,
    borradosPendientes: borradosPendientes, limpiarBorrados: limpiarBorrados, marcarBorrado: marcarBorrado,
    plantillaPorTipo: function (tipo) { var ps = getPlantillas(); for (var i = 0; i < ps.length; i++) if (ps[i].tipo === tipo) return ps[i]; return null; },
    inspecciones: getInspecciones, findInspeccion: findInspeccion, saveInspeccion: saveInspeccion,
    estadoDe: estadoDe, marcarWhatsapp: marcarWhatsapp, deleteInspeccion: deleteInspeccion,
    stats: stats, exportJSON: exportJSON, importJSON: importJSON,
    MESES: MESES, DIAS: DIAS
  };
})(window);
