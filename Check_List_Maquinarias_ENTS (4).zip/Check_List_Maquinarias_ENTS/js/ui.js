/* =========================================================================
   CheckList Pro — Componentes de interfaz reutilizables
   ========================================================================= */
(function (global) {
  'use strict';

  function esc(s) {
    return String(s === null || s === undefined ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function initials(name) {
    var p = String(name || '').trim().split(/\s+/);
    return ((p[0] || '?').charAt(0) + (p[1] ? p[1].charAt(0) : '')).toUpperCase();
  }

  var toastBox = null;
  function toast(msg, type, ms) {
    if (!toastBox) toastBox = document.getElementById('toasts');
    if (!toastBox) return;
    var t = document.createElement('div');
    t.className = 'toast toast-' + (type || 'ok');
    t.setAttribute('role', 'status');
    t.textContent = msg;
    toastBox.appendChild(t);
    setTimeout(function () {
      t.classList.add('out');
      setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 260);
    }, ms || 3200);
  }

  var openModal = null;

  function modal(opts) {
    var root = document.getElementById('modal-root');
    if (!root) return null;
    closeModal();
    var overlay = document.createElement('div');
    overlay.className = 'overlay';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');

    overlay.innerHTML =
      '<div class="modal ' + (opts.size === 'lg' ? 'modal-lg' : '') + (opts.size === 'xl' ? 'modal-xl' : '') + '">' +
        '<header class="modal-head">' +
          '<div><h3>' + esc(opts.title || '') + '</h3>' +
            (opts.subtitle ? '<p class="modal-sub">' + esc(opts.subtitle) + '</p>' : '') + '</div>' +
          '<button type="button" class="icon-btn" data-modal-close aria-label="Cerrar">' + icon('close') + '</button>' +
        '</header>' +
        '<div class="modal-body"></div>' +
        (opts.actions === false ? '' : '<footer class="modal-foot"></footer>') +
      '</div>';

    var body = overlay.querySelector('.modal-body');
    if (typeof opts.body === 'string') body.innerHTML = opts.body;
    else if (opts.body) body.appendChild(opts.body);

    var foot = overlay.querySelector('.modal-foot');
    (opts.actions || []).forEach(function (a) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'btn ' + (a.className || 'btn-primary');
      b.textContent = a.label;
      b.addEventListener('click', function () { if (a.onClick) a.onClick(overlay); });
      foot.appendChild(b);
    });

    overlay.addEventListener('click', function (e) {
      if (e.target === overlay || e.target.closest('[data-modal-close]')) closeModal();
    });
    document.addEventListener('keydown', onKey);

    root.appendChild(overlay);
    requestAnimationFrame(function () { overlay.classList.add('in'); });
    openModal = overlay;

    var auto = overlay.querySelector('[data-autofocus]');
    if (auto) setTimeout(function () { auto.focus(); }, 60);
    return overlay;
  }

  function onKey(e) { if (e.key === 'Escape') closeModal(); }

  function closeModal() {
    var root = document.getElementById('modal-root');
    if (!root || !openModal) return;
    var m = openModal;
    openModal = null;
    document.removeEventListener('keydown', onKey);
    m.classList.remove('in');
    setTimeout(function () { if (m.parentNode) m.parentNode.removeChild(m); }, 180);
  }

  function confirmDlg(title, message, okLabel, danger) {
    return new Promise(function (resolve) {
      var m = modal({
        title: title,
        body: '<p class="confirm-msg">' + esc(message) + '</p>',
        actions: [
          { label: 'Cancelar', className: 'btn-ghost', onClick: function () { closeModal(); resolve(false); } },
          { label: okLabel || 'Confirmar', className: danger ? 'btn-danger' : 'btn-primary', onClick: function () { closeModal(); resolve(true); } }
        ]
      });
      if (m) m.addEventListener('click', function (e) { if (e.target === m) resolve(false); });
    });
  }

  var ICONS = {
    dashboard: '<path d="M3 13h8V3H3v10Zm0 8h8v-6H3v6Zm10 0h8V11h-8v10Zm0-18v6h8V3h-8Z"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    truck: '<path d="M1 3h15v13H1z"/><path d="M16 8h4l3 3v5h-7V8Z"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>',
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    minus: '<path d="M5 12h14"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    close: '<path d="M18 6 6 18M6 6l12 12"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5M12 15V3"/>',
    upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M17 8l-5-5-5 5M12 3v12"/>',
    whatsapp: '<path d="M20.5 3.5A10.5 10.5 0 0 0 3.2 16.2L2 22l5.9-1.2A10.5 10.5 0 1 0 20.5 3.5Z"/><path d="M8.5 8.8c.3-.7.6-.7.9-.7h.7c.2 0 .5 0 .7.6l.8 1.9c.1.3 0 .5-.1.7l-.5.6c-.2.2-.3.4-.1.7a7 7 0 0 0 3.2 2.7c.3.1.5.1.7-.1l.7-.8c.2-.2.4-.2.6-.1l1.8.9c.3.1.5.2.5.4 0 .8-.4 1.7-1 2.1-.6.4-1.5.6-2.4.3a11 11 0 0 1-5.2-3.4 9 9 0 0 1-1.9-3.4 3 3 0 0 1 .3-2.3Z"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/>',
    alert: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    edit: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4Z"/>',
    trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>',
    eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
    phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2Z"/>',
    mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/>',
    menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    print: '<path d="M6 9V2h12v7"/><rect x="6" y="14" width="12" height="8"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/>',
    copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    refresh: '<path d="M3 12a9 9 0 0 1 15.5-6.2L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.5 6.2L3 16"/><path d="M3 21v-5h5"/>',
    smart: '<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 18h.01"/>',
    filter: '<path d="M22 3H2l8 9.5V19l4 2v-8.5L22 3Z"/>'
  };

  function icon(name, cls) {
    var p = ICONS[name] || '';
    return '<svg class="ico ' + (cls || '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>';
  }

  function badge(estado) {
    var cls = estado === 'Aprobado' ? 'ok' : (estado === 'Rechazado' ? 'bad' : 'warn');
    return '<span class="badge badge-' + cls + '">' + esc(estado) + '</span>';
  }

  function estadoIcon(estado) {
    if (estado === 'Aprobado') return icon('check');
    if (estado === 'Rechazado') return icon('x');
    return icon('alert');
  }

  function empty(title, text, action) {
    return '<div class="empty">' +
      '<div class="empty-ico">' + icon('list') + '</div>' +
      '<h4>' + esc(title) + '</h4><p>' + esc(text || '') + '</p>' +
      (action || '') + '</div>';
  }

  function download(filename, blob) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { a.remove(); URL.revokeObjectURL(url); }, 1200);
  }

  function downloadText(filename, text, mime) {
    download(filename, new Blob([text], { type: mime || 'text/plain;charset=utf-8' }));
  }

  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).then(function () { return true; }).catch(function () { return fallback(); });
    }
    return Promise.resolve(fallback());
    function fallback() {
      try {
        var ta = document.createElement('textarea');
        ta.value = text; ta.setAttribute('readonly', '');
        ta.style.position = 'fixed'; ta.style.left = '-9999px';
        document.body.appendChild(ta); ta.select();
        document.execCommand('copy'); ta.remove(); return true;
      } catch (e) { return false; }
    }
  }

  function emailOk(v) { return /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(String(v || '').trim()); }

  global.UI = {
    esc: esc, icon: icon, toast: toast, modal: modal, closeModal: closeModal,
    confirm: confirmDlg, badge: badge, estadoIcon: estadoIcon, empty: empty,
    download: download, downloadText: downloadText, copyText: copyText,
    initials: initials, emailOk: emailOk
  };
})(window);
