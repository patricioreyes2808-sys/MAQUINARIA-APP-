# Check List Maquinarias ENTS

Aplicación web instalable (PWA) para digitalizar los check lists diarios de inspección de maquinaria en terreno. Funciona en el navegador del celular o del computador, se instala como aplicación en Android y en iPhone/iPad, y permite trabajar sin señal una vez instalada.

Incluye los **22 check lists** del archivo Excel original (1.195 puntos de inspección), separados en una **lista desplegable por tipo de maquinaria**, sin la frase de obras tempranas del proyecto anterior.

---

## 1. Qué trae la aplicación

| Módulo | Qué hace |
|---|---|
| Panel | Checklists del día, porcentaje de cumplimiento de 30 días, equipos activos y actividad de la semana. |
| Nuevo checklist | Se elige el **tipo de maquinaria** en una lista desplegable, luego el equipo, y se responde ítem por ítem. |
| Historial | Registros guardados, con filtros por texto, estado y rango de fechas. Exportable a Excel. |
| Plantillas | Los 22 check lists cargados, con filtro por tipo de maquinaria y carga de nuevos check lists desde Excel. |
| Equipos | Catálogo de equipos: código, tipo, marca, modelo, patente, faena y estado. |
| Usuarios | Nombre completo, RUT, correo, teléfono celular y equipo(s) que opera cada persona. |
| Ajustes | Datos de la empresa, mensaje de WhatsApp, respaldo y restauración de la información. |

### Respuestas del checklist

Cada punto se responde con los mismos códigos del formulario original:

- **B** = Bueno
- **M** = Malo (pide describir la desviación y la acción tomada)
- **N/A** = No aplica

Al guardar, la aplicación calcula el resultado del registro (Aprobado / Observado / Rechazado) y deja el mensaje de confirmación listo para enviar por WhatsApp.

---

## 2. Los 22 check lists incluidos

| # | Tipo de maquinaria | Ítems | Secciones |
|---|---|---|---|
| 1 | Retroexcavadora | 33 | 7 |
| 2 | Excavadora | 29 | 8 |
| 3 | Grúa | 74 | 17 |
| 4 | Camión Tolva | 50 | 8 |
| 5 | Minicargador | 49 | 9 |
| 6 | Camión Rampla | 60 | 10 |
| 7 | Camión Plano | 50 | 8 |
| 8 | Motoniveladora | 61 | 13 |
| 9 | Rodillo | 49 | 10 |
| 10 | Camión Aljibe | 69 | 11 |
| 11 | Camión Combustible | 79 | 12 |
| 12 | Camión Bomba | 69 | 11 |
| 13 | Cargador Frontal | 54 | 9 |
| 14 | Bus | 61 | 9 |
| 15 | Minibús | 59 | 10 |
| 16 | Elevador de Persona | 52 | 13 |
| 17 | Manitou | 49 | 13 |
| 18 | Grúa Horquilla | 48 | 13 |
| 19 | Camioneta | 61 | 9 |
| 20 | Bulldozer | 51 | 11 |
| 21 | Camión 3/4 | 58 | 11 |
| 22 | Generador | 30 | 4 |
| | **Total** | **1.195** | |

Los textos de los ítems y los nombres de las secciones se mantuvieron tal como venían en el Excel entregado; solo se corrigieron tildes y se eliminó la frase del proyecto anterior.

---

## 3. Accesos de prueba

| Perfil | Correo | Clave |
|---|---|---|
| Administrador | admin@ents.cl | Admin2026 |
| Supervisor | supervisor@ents.cl | Supervisor2026 |
| Operador | operador@ents.cl | Operador2026 |

> **Importante:** estas claves son de demostración. Antes de usar la aplicación en terreno hay que cambiarlas y crear los usuarios reales en el módulo **Usuarios**. El administrador puede crear cuentas nuevas, asignar equipos y editar los datos de cada persona.

---

## 4. Cómo se usa (flujo de trabajo)

1. La persona entra con su correo y clave (o crea su cuenta desde el mismo acceso).
2. Va a **Nuevo checklist**, elige el **tipo de maquinaria** en la lista desplegable y luego el equipo inspeccionado.
3. Completa la tarjeta **Datos del equipo**: **patente**, **kilometraje u horómetro**, **última mantención** y **próxima mantención**. Los datos vienen precargados desde la ficha del equipo y se pueden corregir en terreno. Si la próxima mantención ya venció, la aplicación lo avisa antes de guardar.
4. Responde cada punto con **B**, **M** o **N/A**. Si marca **M**, se abre el campo de observación para describir la desviación y la acción tomada.
5. Revisa el resumen, firma con el dedo en la pantalla y guarda.
6. En la pantalla de confirmación escribe el **teléfono del encuestado** y envía la confirmación: sale el **PDF del check list adjunto** con los datos del equipo (patente, kilometraje, mantenciones), el detalle de los ítems, las observaciones y la firma. Si se prefiere, el mensaje de texto se puede enviar solo.
7. El registro queda en **Historial**, con el botón **PDF** para descargarlo o imprimirlo, y la opción de exportar todo a Excel o reenviar por WhatsApp.

---

## 5. Instalación en el celular

### Android (Chrome)

1. Abrir la dirección de la aplicación en Chrome.
2. Tocar el menú de tres puntos (arriba a la derecha).
3. Elegir **Instalar aplicación** o **Agregar a pantalla principal**.
4. Confirmar. Queda el ícono «Check List ENTS» en el escritorio, se abre a pantalla completa y funciona sin señal.

### iPhone / iPad (Safari)

1. Abrir la dirección de la aplicación **en Safari** (en iPhone no funciona desde Chrome).
2. Tocar el botón **Compartir** (cuadrado con flecha hacia arriba).
3. Bajar y elegir **Añadir a pantalla de inicio**.
4. Confirmar con **Agregar**. Queda el ícono en la pantalla de inicio.

### Requisitos

- La aplicación debe estar publicada en una dirección **HTTPS** (o en el servidor interno de la faena). Sin HTTPS, el navegador no permite instalarla ni guardarla para uso sin conexión.
- Los datos quedan guardados **en el propio dispositivo**. Si se borran los datos del navegador, se pierde el historial local: por eso conviene exportar respaldos periódicos desde **Ajustes → Respaldo**.

---

## 6. Publicación de la aplicación

Es un sitio estático: no necesita base de datos ni servidor especial para funcionar.

**Opción A — hosting en la nube (la más rápida)**

1. Subir el contenido de la carpeta `app/` a Netlify, Vercel, Firebase Hosting, Cloudflare Pages o GitHub Pages.
2. La dirección que entrega el servicio ya viene con HTTPS y sirve para instalar en Android y iPhone.

**Opción B — servidor propio de la faena**

1. Copiar la carpeta `app/` en el servidor web (Nginx, Apache o IIS).
2. Publicar con certificado HTTPS.
3. Verificar que el archivo `sw.js` quede en la raíz del sitio, junto a `index.html`.

---

## 7. Generar el APK (Android) o la app para iPhone

Si se necesita un archivo instalable (APK / AAB para Play Store, o IPA para App Store), la vía más simple es envolver la misma aplicación con **Capacitor**:

```bash
# 1. Requisitos: Node.js 20+, Android Studio (para APK)
npm install -g @capacitor/cli

# 2. Crear el proyecto envoltorio
mkdir clm-ents && cd clm-ents
npm init -y
npm install @capacitor/core @capacitor/android
npx cap init "Check List Maquinarias ENTS" cl.ents.checklist --web-dir=www

# 3. Copiar la aplicación dentro de www/
mkdir www && cp -r ../app/* www/

# 4. Agregar Android y sincronizar
npx cap add android
npx cap sync

# 5. Abrir en Android Studio y generar el APK firmado
npx cap open android
```

En Android Studio: **Build → Generate Signed Bundle / APK**. Para iPhone se repite el proceso con `npx cap add ios` en un Mac con Xcode.

Alternativa sin código: publicar la PWA y usar un servicio de empaquetado (PWABuilder) para descargar el APK listo para instalar.

---

## 8. Cargar check lists nuevos desde Excel

En **Plantillas → Subir checklist Excel**. El archivo debe tener una fila de encabezados con estas columnas:

| Sección | Ítem | Criterio de aceptación | Crítico |
|---|---|---|---|
| LUCES | LUCES DE FRENO | Encienden y apagan correctamente | No |
| NIVELES | NIVEL DE ACEITE | Entre las marcas mínima y máxima | Sí |

- Cada fila se transforma en un punto a inspeccionar.
- La columna **Crítico** acepta Sí/No; los ítems críticos se destacan en el formulario y bloquean la aprobación si quedan en **M**.
- Acepta archivos `.xlsx`, `.xls` y `.csv` de hasta 5 MB.
- También se puede descargar el formato de ejemplo desde el botón **Descargar formato Excel**.

---

### Editar un check list existente (solo administrador)

En **Plantillas**, cada tarjeta tiene el botón **Modificar**. Ahí se puede:

- Corregir el nombre del check list, el tipo de maquinaria y la frecuencia.
- Corregir el texto de cada ítem, su sección y su criterio de aceptación.
- Marcar o desmarcar un ítem como **crítico**.
- **Agregar ítem** para sumar un punto nuevo y el basurero para quitarlo.
- **Nuevo check list** crea una plantilla vacía para un tipo de maquinaria que no esté en la lista.

Los check lists ya guardados en el historial **no se modifican**: los cambios se aplican desde ese momento en adelante.

---

## 8 bis. Base de datos compartida (todos en la misma información)

Para que **todos los equipos trabajen con la misma base**, la aplicación se conecta al servicio central incluido en la carpeta `servidor/`.

### Paso 1 — Publicar el servicio

La vía más simple: subir el paquete a un servidor Ubuntu y ejecutar `servidor/instalar.sh <dominio> <correo>`. Ese script instala Node.js, deja el servicio con arranque automático, obtiene el HTTPS y programa el respaldo diario. El paso a paso completo, con costos y solución de problemas, está en `GUIA_SERVIDOR.md`.

Instalación manual (alternativa):

1. Copiar la carpeta `servidor/` a un servidor con Node.js 20 o superior y HTTPS.
2. `npm install` y luego `npm start`.
3. Crear el archivo `.env` a partir de `.env.example` (clave de sesión, datos de WhatsApp si se usará envío automático).
4. Al arrancar por primera vez, el servicio crea las cuentas iniciales: `admin@ents.cl` / `Admin2026`, `supervisor@ents.cl` / `Supervisor2026` y `operador@ents.cl` / `Operador2026`. **Cambiar esas claves de inmediato.**

### Paso 2 — Conectar cada equipo

1. Entrar a la aplicación con una cuenta **administradora**.
2. Ir a **Configuración → Base de datos compartida**.
3. Escribir la dirección del servidor (por ejemplo `https://checklist.empresa.cl`), el correo y la contraseña del administrador, y presionar **Conectar**.
4. La aplicación sube los check lists y equipos de ese equipo y desde ahí queda sincronizada.
5. Repetir en cada celular o computador. Todos verán los mismos usuarios, check lists y registros.

### Cómo funciona la sincronización

- Cada cambio se envía al servidor automáticamente (a los pocos segundos) y se descarga lo que haya cambiado en otros equipos.
- Sin señal, la aplicación sigue funcionando con la copia guardada y sincroniza al recuperar la conexión.
- En la barra superior aparece **Base compartida** (conectada), **Sin conexión** o **Sesión vencida**. En Configuración está el botón **Sincronizar ahora** y la fecha de la última sincronización.
- Las bajas (usuarios, equipos, check lists o registros eliminados) también se propagan al resto de los equipos.
- Si se desea volver a trabajar solo con los datos del equipo, se usa **Desconectar**.

---

## 8 ter. Quién puede modificar y quién no

| Acción | Administrador | Supervisor | Operador |
|---|---|---|---|
| Crear y responder check lists | Sí | Sí | Sí |
| Ver el historial | Todo | Todo | Solo sus registros |
| Crear y modificar usuarios | Sí | Sí (no puede crear ni editar administradores) | No |
| Crear y modificar equipos | Sí | Sí | No |
| Crear, modificar, subir o eliminar check lists | Sí | Sí | No |
| Datos de empresa y mensaje de WhatsApp | Sí | Sí | No |
| Conectar o desconectar la base compartida | Sí | No | No |
| Restaurar datos de ejemplo y respaldos | Sí | No | No |

Los permisos se aplican en la pantalla y también en el servidor: si un operador intenta modificar información, el servicio rechaza el cambio.

---

## 9. Módulo de usuarios

Cada usuario se registra con:

- **Nombre completo**
- **RUT**
- **Correo electrónico** (es el nombre de usuario para entrar)
- **Teléfono celular** (destino del mensaje de WhatsApp)
- **Equipo(s) a operar** (uno o varios del catálogo)
- Perfil: administrador, supervisor u operador
- Estado: habilitado o deshabilitado

El administrador puede crear, editar, deshabilitar y eliminar usuarios, y exportar el listado a Excel.

---

## 10. Confirmación por WhatsApp

La confirmación sale como **documento PDF adjunto** (una hoja A4 por cada página que necesite el registro), con la misma información del check list:

- Encabezado con empresa, proyecto, contrato y número de registro.
- Datos del equipo: código y nombre, **patente**, **kilometraje u horómetro**, **última** y **próxima mantención**, operador, RUT, teléfono, fecha y hora.
- Aviso destacado si la mantención preventiva está vencida o vence en los próximos 15 días.
- Tabla completa de puntos revisados, con resultado B / M / N/A, marca de ítem crítico y observaciones.
- Observaciones generales y firma del operador.
- Pie de página con número de registro y paginación.

**Sin servidor (modo actual).** Al guardar, la aplicación arma el mensaje y abre WhatsApp con el texto listo; el PDF se descarga desde la ficha del registro para adjuntarlo en la misma conversación. Queda registrada la fecha y hora del envío y el destino.

**Con servidor (opcional).** La carpeta `servidor/` genera el PDF y lo envía automáticamente como documento por la API oficial de WhatsApp Cloud (Meta), junto con el texto de confirmación. Además guarda los check lists en una base central y permite que varios dispositivos trabajen con la misma información. Requiere número de WhatsApp Business, token de Meta y un servidor con HTTPS. Instrucciones en `servidor/README.md`.

El texto del mensaje admite las variables `{{equipo}}`, `{{codigo}}`, `{{patente}}`, `{{kilometraje}}`, `{{ultimaMantencion}}`, `{{proximaMantencion}}`, `{{fecha}}`, `{{hora}}`, `{{estado}}` y `{{id}}`, además de las que ya existían (`{{nombre}}`, `{{checklist}}`, `{{evaluados}}`, `{{noconformes}}`, `{{observaciones}}`, `{{empresa}}`). En **Ajustes** aparecen como botones para insertarlas sin escribirlas a mano.

---

## 11. Estructura de archivos

```
app/
├── index.html              Página de entrada
├── manifest.webmanifest    Datos de instalación (nombre, íconos, colores)
├── sw.js                   Modo sin conexión
├── css/styles.css          Diseño
├── icons/                  Íconos de la aplicación
└── js/
    ├── checklists.js       Los 22 check lists (1.195 ítems)
    ├── vendor/xlsx.full.min.js   Lector y generador de Excel
    ├── store.js            Datos y almacenamiento local
    ├── ui.js               Componentes de interfaz
    └── app.js              Pantallas y lógica
servidor/                   Servicio opcional (Node.js + Express)
```

---

## 12. Antes de ponerla en producción

- [ ] Cambiar las claves de demostración y crear los usuarios reales.
- [ ] Revisar en **Ajustes** el nombre de la empresa, el proyecto y el texto del mensaje de WhatsApp.
- [ ] Cargar el catálogo real de equipos (código, marca, modelo, patente).
- [ ] Definir el número de WhatsApp que aparecerá como remitente.
- [ ] Publicar con HTTPS y probar la instalación en un Android y en un iPhone.
- [ ] Definir si se usará solo el teléfono (datos en el dispositivo) o el servidor central.
- [ ] Acordar quién revisa y cierra las observaciones marcadas como **M**.

---

## 13. Datos que conviene confirmar

- Logotipo oficial de la empresa para la pantalla de acceso y el ícono de la aplicación (hoy se usa un ícono genérico).
- Nombre exacto del proyecto y centro de costo que debe aparecer en el mensaje y en los reportes.
- Criterio de aprobación: hoy un checklist con cualquier ítem en **M** queda como *Observado* y con un ítem crítico en **M** queda *Rechazado*.
- Si se usará la API oficial de WhatsApp o el envío manual (modo actual).
