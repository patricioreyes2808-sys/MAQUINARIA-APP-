# Guía para publicar el servidor
### Check List Maquinarias ENTS — base compartida entre todos los equipos

Esta guía deja la aplicación publicada en una dirección segura (`https://...`), con la base de datos central y el respaldo automático. Una vez publicada, los celulares y computadores entran con esa dirección, la instalan como aplicación y trabajan todos sobre la misma información.

---

## 1. Qué se va a montar

Un solo servidor entrega dos cosas en la misma dirección:

| Parte | Qué hace |
|---|---|
| La aplicación | Se abre en el navegador del celular o computador y se puede instalar como app |
| El servicio de datos | Guarda usuarios, check lists, equipos e inspecciones, valida los permisos y genera el PDF de cada registro para enviarlo por WhatsApp |

Por eso **no hay que configurar dos direcciones**: la misma dirección sirve para entrar y para sincronizar.

---

## 2. Lo que se necesita antes de partir

1. **Un dominio.** Por ejemplo `checklist.ents.cl`. Se compra en NIC Chile (`.cl`) o en cualquier proveedor internacional (`.com`).
2. **Un servidor** con Ubuntu 22.04 o 24.04, 1 GB de memoria y 20 GB de disco. Basta el plan más económico.
3. **Acceso al servidor por SSH** (usuario y clave, o llave).
4. **Un correo** para el aviso de vencimiento del certificado.

### Dónde arrendar el servidor (valores referenciales)

| Proveedor | Plan | Valor aproximado |
|---|---|---|
| DigitalOcean | Basic 1 GB, región Santiago | USD 6 al mes |
| Hetzner | CX22 | EUR 4,5 al mes |
| AWS Lightsail | 1 GB | USD 5 al mes |
| Vultr | 1 GB | USD 6 al mes |

Cualquiera sirve. Lo importante es elegir **región cercana** (Santiago o São Paulo) para que la sincronización sea rápida.

> Si la faena exige que los datos no salgan del país, conviene un servidor en la región de Santiago o un equipo propio en la oficina, con la salvedad de que en ese caso solo se sincroniza dentro de la red interna.

---

## 3. Opción A — Servidor propio (recomendada)

Es la más estable y la que deja todo funcionando en cerca de 15 minutos.

### Paso 1: apuntar el dominio al servidor

En el panel donde compró el dominio, crear un registro tipo **A**:

| Tipo | Nombre | Valor |
|---|---|---|
| A | checklist | la dirección IP del servidor |

Esperar unos minutos y comprobar desde su computador:

```bash
ping checklist.ents.cl
```

Debe responder con la IP del servidor. Si no responde, todavía no propaga el cambio: espere y repita.

### Paso 2: entrar al servidor

```bash
ssh root@IP-DEL-SERVIDOR
```

### Paso 3: subir la aplicación

Desde su computador, en la carpeta donde descomprimió el paquete:

```bash
scp Check_List_Maquinarias_ENTS.zip root@IP-DEL-SERVIDOR:/root/
```

De vuelta en el servidor:

```bash
apt-get update && apt-get install -y unzip
unzip /root/Check_List_Maquinarias_ENTS.zip -d /root/paquete
cd /root/paquete/app/servidor
chmod +x instalar.sh
```

### Paso 4: instalar

```bash
./instalar.sh checklist.ents.cl correo@ents.cl
```

El instalador hace todo solo: instala Node.js, crea el usuario de servicio, configura el arranque automático, pide el certificado HTTPS, activa el cortafuegos y programa el respaldo diario a las 03:00.

Al final muestra en pantalla la **clave inicial del administrador**. Anótela.

### Paso 5: comprobar

Abrir en el navegador:

```
https://checklist.ents.cl
```

Debe aparecer la portada de Check List Maquinarias ENTS con el candado de conexión segura. Si aparece, el servidor quedó bien.

### Paso 6: cambiar la clave y crear las cuentas reales

1. Entrar con `admin@ents.cl` y la clave que mostró el instalador.
2. Ir a **Usuarios** y cambiar la clave del administrador.
3. Crear las cuentas de supervisores y operadores con nombre, RUT, correo y teléfono reales.
4. Eliminar o desactivar las cuentas de ejemplo que no se usarán.

### Paso 7: conectar los equipos

En cada celular o computador:

1. Abrir `https://checklist.ents.cl` en Chrome o Safari.
2. Instalar como aplicación (menú del navegador → *Instalar aplicación* o *Agregar a pantalla de inicio*).
3. Entrar con la cuenta que le corresponde a esa persona.
4. Ir a **Configuración → Base de datos compartida**, escribir la misma dirección `https://checklist.ents.cl` y las credenciales de administrador, y presionar **Conectar** una sola vez por equipo.
5. Verificar que arriba aparezca **Base compartida**.

---

## 4. Opción B — Con Docker

Si el servidor ya usa Docker, no hace falta instalar Node.js:

```bash
cd /root/paquete/app
cp servidor/.env.example servidor/.env
nano servidor/.env        # completar JWT_SECRET, APP_ORIGIN y claves
mkdir -p servidor/datos
docker compose up -d --build
docker compose logs -f
```

El servicio queda escuchando solo en `127.0.0.1:8080`. Para publicarlo con HTTPS, instalar Caddy y usar el archivo `servidor/Caddyfile`:

```bash
apt-get install -y caddy
sed 's/checklist.tuempresa.cl/checklist.ents.cl/g' servidor/Caddyfile > /etc/caddy/Caddyfile
systemctl restart caddy
```

---

## 5. Opción C — Servicio en la nube sin administrar servidor

Sirve para pruebas o para un piloto pequeño.

1. Crear una cuenta en Render o Railway y un servicio **Web Service** desde el repositorio o subiendo el proyecto.
2. Tipo de servicio: Node.js. Carpeta del servicio: `servidor`. Comando de inicio: `node server.js`.
3. Agregar las variables de entorno: `JWT_SECRET`, `APP_ORIGIN`, `ADMIN_CLAVE`.
4. **Agregar un disco persistente** montado en `/app/datos` y definir `DATA_DIR=/app/datos`. Sin disco persistente la base se borra en cada publicación.
5. La plataforma entrega una dirección `https://...` que se usa tal cual en la aplicación.

> En los planes gratuitos el servicio se suspende por inactividad y la primera conexión del día tarda en responder. Para uso en faena, conviene la Opción A.

---

## 6. Cómo funciona el día a día

- Cada inspección se guarda en el equipo y se envía al servidor a los pocos segundos.
- Si no hay señal, se sigue trabajando y se sincroniza al recuperar conexión.
- Los cambios de usuarios, check lists y equipos llegan solos a los demás equipos.
- El operador solo responde inspecciones y ve sus propios registros; no puede modificar la estructura ni las cuentas.
- Si alguien intenta modificar datos sin permiso, el servidor rechaza el cambio aunque la pantalla estuviera abierta.

---

## 7. Respaldo y restauración

El respaldo queda programado todos los días a las 03:00 en `/var/respaldos/checklist`, y se conservan 30 días.

Para respaldar ahora:

```bash
/opt/checklist-ents/servidor/respaldo.sh
```

Para llevarse una copia al computador:

```bash
scp root@IP-DEL-SERVIDOR:/var/respaldos/checklist/*.tar.gz .
```

Para restaurar en un servidor nuevo: instalar normalmente, detener el servicio, reemplazar el contenido de `/opt/checklist-ents/servidor/datos` con el respaldo y volver a iniciar.

```bash
systemctl stop checklist-ents
tar -xzf respaldo.tar.gz -C /opt/checklist-ents/servidor/datos
chown -R checklist:checklist /opt/checklist-ents/servidor/datos
systemctl start checklist-ents
```

---

## 8. Actualizar la versión

1. Subir el paquete nuevo al servidor y descomprimirlo.
2. Entrar a la carpeta `app/servidor` de la versión nueva.
3. Ejecutar `./actualizar.sh`.

El script hace un respaldo antes de copiar, conserva la base y el archivo de configuración, y reinicia el servicio.

---

## 9. Revisión rápida del estado

```bash
cd /opt/checklist-ents/servidor
./verificar.sh
```

Muestra si el servicio está activo, si responde, cuántos usuarios y check lists hay, y los últimos respaldos.

---

## 10. Problemas frecuentes

| Síntoma | Causa habitual | Solución |
|---|---|---|
| La dirección no abre | El dominio todavía no apunta al servidor | Revisar el registro A y esperar la propagación |
| Error de certificado | El dominio no resuelve o el puerto 80 está cerrado | Abrir 80 y 443, reiniciar Caddy |
| Aparece "Bad Gateway" | El servicio está detenido | `systemctl restart checklist-ents` y revisar `journalctl -u checklist-ents -n 50` |
| La aplicación dice "Sesión vencida" | Pasó mucho tiempo o cambió la clave | Volver a conectarse en Configuración |
| Un equipo no ve los cambios | Está sin conexión o con la dirección mal escrita | Revisar el chip de estado y presionar *Sincronizar ahora* |
| El operador no puede guardar | Está intentando modificar estructura o cuentas | Es lo esperado: solo registra inspecciones |
| Se perdieron datos al actualizar | Se cambió la carpeta de datos | Restaurar el respaldo y revisar `DATA_DIR` |

---

## 11. Lista de verificación de seguridad

- [ ] Clave del administrador cambiada (no dejar la inicial).
- [ ] Cuentas de ejemplo eliminadas o desactivadas.
- [ ] Cada persona con su propia cuenta, sin claves compartidas.
- [ ] `JWT_SECRET` distinto en cada instalación y nunca publicado.
- [ ] El archivo `.env` con permisos 600 y fuera de repositorios.
- [ ] HTTPS activo y renovación automática funcionando.
- [ ] Cortafuegos con solo 22, 80 y 443 abiertos.
- [ ] Respaldo diario comprobado (hacer una restauración de prueba).
- [ ] Responsable definido para revisar el respaldo una vez al mes.

---

## 12. Costos estimados

| Ítem | Valor aproximado |
|---|---|
| Servidor 1 GB | USD 5 a 7 al mes |
| Dominio `.cl` | CLP 10.000 a 15.000 al año |
| Dominio `.com` | USD 12 a 15 al año |
| Certificado HTTPS | Sin costo (automático) |
| WhatsApp Cloud API | Sin costo en el volumen habitual de una faena |

---

## 13. Estado de esta entrega

El servicio fue probado localmente: entrega la aplicación, valida el ingreso de administrador y operador, sincroniza check lists y equipos, genera el PDF de cada registro (con patente, kilometraje, mantenciones, ítems, observaciones y firma) y rechaza los cambios o descargas de registros ajenos hechos por un operador. Lo que queda por hacer del lado del cliente es contratar el dominio y el servidor, y ejecutar la instalación con la dirección real.

Pendiente de definir con ustedes:

1. Dominio definitivo.
2. Proveedor y región del servidor.
3. Logotipo final de la aplicación.
4. Número de WhatsApp para las confirmaciones (Meta Business) y su token permanente, para que el PDF salga adjunto de forma automática.
