#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Check List Maquinarias ENTS — instalación en un servidor Ubuntu 22.04/24.04
#
# Uso (con permisos de administrador):
#   sudo ./instalar.sh checklist.tuempresa.cl correo@tuempresa.cl
#
# Deja el servicio andando, con HTTPS automático y respaldo diario.
# ---------------------------------------------------------------------------
set -euo pipefail

DOMINIO="${1:-}"
CORREO="${2:-}"
if [[ -z "$DOMINIO" || -z "$CORREO" ]]; then
  echo "Uso: sudo ./instalar.sh <dominio> <correo>"
  echo "Ejemplo: sudo ./instalar.sh checklist.ents.cl soporte@ents.cl"
  exit 1
fi
if [[ "$EUID" -ne 0 ]]; then
  echo "Ejecutar con sudo."
  exit 1
fi

ORIGEN="$(cd "$(dirname "$0")/.." && pwd)"
DESTINO="/opt/checklist-ents"
echo "==> Instalando en $DESTINO para el dominio $DOMINIO"

echo "==> Paquetes base"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl ca-certificates gnupg ufw tar openssl

echo "==> Node.js 20"
if ! command -v node >/dev/null || [[ "$(node -v | cut -c2-3)" -lt 20 ]]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi

echo "==> Usuario de servicio"
id -u checklist >/dev/null 2>&1 || useradd --system --home "$DESTINO" --shell /usr/sbin/nologin checklist

echo "==> Copiando aplicación"
mkdir -p "$DESTINO"
tar -C "$ORIGEN" --exclude='node_modules' --exclude='servidor/datos' -cf - . | tar -C "$DESTINO" -xf -
mkdir -p "$DESTINO/servidor/datos"

echo "==> Dependencias"
cd "$DESTINO/servidor"
npm install --omit=dev --no-audit --no-fund

echo "==> Configuración"
if [[ ! -f .env ]]; then
  CLAVE_ADMIN="Ents$(openssl rand -hex 4)"
  cat > .env <<EOF
PORT=8080
HOST=127.0.0.1
APP_ORIGIN=https://$DOMINIO
JWT_SECRET=$(openssl rand -base64 48 | tr -d '\n')
ADMIN_CLAVE=$CLAVE_ADMIN
SUPERVISOR_CLAVE=Supervisor2026
OPERADOR_CLAVE=Operador2026
EOF
  chmod 600 .env
  echo "==> Clave inicial del administrador: $CLAVE_ADMIN  (anótala y cámbiala al entrar)"
else
  echo "==> Se conserva el archivo .env existente"
fi

chown -R checklist:checklist "$DESTINO"

echo "==> Servicio del sistema"
install -m 644 checklist-ents.service /etc/systemd/system/checklist-ents.service
systemctl daemon-reload
systemctl enable --now checklist-ents
sleep 2
systemctl --no-pager --lines=5 status checklist-ents || true

echo "==> HTTPS con Caddy"
if ! command -v caddy >/dev/null; then
  apt-get install -y debian-keyring debian-archive-keyring apt-transport-https
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -y
  apt-get install -y caddy
fi
sed "s/checklist.tuempresa.cl/$DOMINIO/g" "$DESTINO/servidor/Caddyfile" > /etc/caddy/Caddyfile
mkdir -p /var/log/caddy
chown -R caddy:caddy /var/log/caddy 2>/dev/null || true
systemctl restart caddy

echo "==> Cortafuegos"
ufw allow OpenSSH >/dev/null 2>&1 || true
ufw allow 80/tcp >/dev/null 2>&1 || true
ufw allow 443/tcp >/dev/null 2>&1 || true
yes | ufw enable >/dev/null 2>&1 || true

echo "==> Respaldo diario (03:00)"
mkdir -p /var/respaldos/checklist
chown -R checklist:checklist /var/respaldos/checklist
CRON="0 3 * * * $DESTINO/servidor/respaldo.sh /var/respaldos/checklist"
( crontab -u checklist -l 2>/dev/null | grep -v 'respaldo.sh' || true; echo "$CRON" ) | crontab -u checklist -

echo ""
echo "=========================================================="
echo " Listo. Abrir: https://$DOMINIO"
echo " Usuario administrador: admin@ents.cl"
echo " Revisar la clave inicial impresa más arriba."
echo " Estado: systemctl status checklist-ents"
echo " Registro: journalctl -u checklist-ents -f"
echo "=========================================================="
