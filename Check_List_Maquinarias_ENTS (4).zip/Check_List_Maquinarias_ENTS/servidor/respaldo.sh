#!/usr/bin/env bash
# Respaldo de la base compartida. Uso: ./respaldo.sh [carpeta-destino]
set -euo pipefail
ORIGEN="$(cd "$(dirname "$0")" && pwd)/datos"
DESTINO="${1:-/var/respaldos/checklist}"
FECHA="$(date +%Y-%m-%d_%H%M)"

mkdir -p "$DESTINO"
tar -czf "$DESTINO/checklist-$FECHA.tar.gz" -C "$ORIGEN" .
find "$DESTINO" -name 'checklist-*.tar.gz' -mtime +30 -delete
echo "Respaldo creado: $DESTINO/checklist-$FECHA.tar.gz"
