#!/usr/bin/env bash
# Actualiza la aplicación y el servicio conservando la base de datos.
# Uso: sudo ./actualizar.sh   (desde la carpeta servidor/ de la nueva versión)
set -euo pipefail
ORIGEN="$(cd "$(dirname "$0")/.." && pwd)"
DESTINO="/opt/checklist-ents"

if [[ "$EUID" -ne 0 ]]; then echo "Ejecutar con sudo."; exit 1; fi

echo "==> Respaldo previo"
"$DESTINO/servidor/respaldo.sh" /var/respaldos/checklist || true

echo "==> Copiando archivos nuevos"
tar -C "$ORIGEN" --exclude='node_modules' --exclude='datos' --exclude='.env' -cf - . | tar -C "$DESTINO" -xf -

echo "==> Dependencias"
cd "$DESTINO/servidor"
npm install --omit=dev --no-audit --no-fund
chown -R checklist:checklist "$DESTINO"

echo "==> Reiniciando"
systemctl restart checklist-ents
sleep 2
systemctl --no-pager --lines=5 status checklist-ents || true
echo "Actualización terminada."
