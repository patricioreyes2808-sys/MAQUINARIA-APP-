#!/usr/bin/env bash
# Comprueba el estado del servicio y de la base compartida.
set -uo pipefail
DESTINO="/opt/checklist-ents"
echo "--- Servicio ---"
systemctl is-active checklist-ents
echo "--- Respuesta local ---"
curl -s http://127.0.0.1:8080/api/salud || echo "Sin respuesta del servicio"
echo ""
echo "--- Base de datos ---"
ls -lh "$DESTINO/servidor/datos" 2>/dev/null
node -e "const d=require('$DESTINO/servidor/datos/datos.json');console.log('usuarios:',(d.usuarios||[]).length,'| checklists:',(d.checklists||[]).length,'| inspecciones:',(d.inspecciones||[]).length)" 2>/dev/null || true
echo "--- Últimos respaldos ---"
ls -lh /var/respaldos/checklist 2>/dev/null | tail -3
