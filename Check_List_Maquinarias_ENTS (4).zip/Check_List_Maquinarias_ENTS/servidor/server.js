/*
 * Check List Maquinarias ENTS — servicio de referencia
 * -----------------------------------------------------
 * Este servicio es OPCIONAL. La aplicación funciona sola en el teléfono,
 * guardando los datos en el propio dispositivo. Se usa este servicio cuando
 * se necesita una base central compartida entre varios equipos y el envío
 * automático del mensaje de confirmación por WhatsApp.
 *
 * Puesta en marcha:
 *   1) npm install
 *   2) copiar .env.example a .env y completar los datos
 *   3) npm start
 *   4) publicar detrás de HTTPS y apuntar la aplicación a esta dirección
 */

'use strict';

require('dotenv').config();

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const XLSX = require('xlsx');
const rateLimit = require('express-rate-limit');
const { crearPdfInspeccion } = require('./pdf');

const PUERTO = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || '0.0.0.0';
const CARPETA_APP = path.resolve(process.env.APP_DIR || path.join(__dirname, '..'));
const CLAVE = process.env.JWT_SECRET || '';
const ORIGEN = process.env.APP_ORIGIN || '*';
const CARPETA_DATOS = path.resolve(process.env.DATA_DIR || './datos');
const ARCHIVO_DATOS = path.join(CARPETA_DATOS, 'datos.json');

if (!CLAVE || CLAVE.length < 24) {
  console.error('Falta JWT_SECRET (mínimo 24 caracteres). Revisa el archivo .env');
  process.exit(1);
}

/* ----------------------------- almacenamiento ----------------------------- */

const VACIO = { usuarios: [], checklists: [], inspecciones: [], equipos: [], ajustes: {} };

function leerDatos() {
  try {
    return Object.assign({}, VACIO, JSON.parse(fs.readFileSync(ARCHIVO_DATOS, 'utf8')));
  } catch (e) {
    return JSON.parse(JSON.stringify(VACIO));
  }
}

let datos = leerDatos();

function guardarDatos() {
  fs.mkdirSync(CARPETA_DATOS, { recursive: true });
  const temporal = ARCHIVO_DATOS + '.tmp';
  fs.writeFileSync(temporal, JSON.stringify(datos, null, 2));
  fs.renameSync(temporal, ARCHIVO_DATOS);
}

function nuevoId(prefijo) {
  return prefijo + '_' + crypto.randomBytes(6).toString('hex');
}

/* -------------------------------- utilidades ------------------------------ */

function limpiarTelefono(tel) {
  const soloDigitos = String(tel || '').replace(/\D/g, '');
  if (!soloDigitos) return '';
  if (soloDigitos.startsWith('56')) return soloDigitos;
  if (soloDigitos.length === 9) return '56' + soloDigitos;
  return soloDigitos;
}

function validarRut(rut) {
  const limpio = String(rut || '').replace(/[.\-\s]/g, '').toUpperCase();
  if (!/^\d{7,8}[0-9K]$/.test(limpio)) return false;
  const cuerpo = limpio.slice(0, -1);
  const dv = limpio.slice(-1);
  let suma = 0;
  let factor = 2;
  for (let i = cuerpo.length - 1; i >= 0; i--) {
    suma += Number(cuerpo[i]) * factor;
    factor = factor === 7 ? 2 : factor + 1;
  }
  const resto = 11 - (suma % 11);
  const esperado = resto === 11 ? '0' : resto === 10 ? 'K' : String(resto);
  return esperado === dv;
}

function publico(usuario) {
  return {
    id: usuario.id,
    nombre: usuario.nombre,
    rut: usuario.rut,
    correo: usuario.correo,
    telefono: usuario.telefono,
    rol: usuario.rol,
    equipos: usuario.equipos || [],
    activo: usuario.activo !== false,
    creado: usuario.creado
  };
}

function firmar(usuario) {
  return jwt.sign({ sub: usuario.id, rol: usuario.rol }, CLAVE, { expiresIn: '12h' });
}

function autenticar(req, res, next) {
  const cabecera = req.headers.authorization || '';
  const token = cabecera.startsWith('Bearer ') ? cabecera.slice(7) : '';
  if (!token) return res.status(401).json({ error: 'Debes iniciar sesión.' });
  try {
    const carga = jwt.verify(token, CLAVE);
    const usuario = datos.usuarios.find((u) => u.id === carga.sub);
    if (!usuario || usuario.activo === false) return res.status(401).json({ error: 'Sesión no válida.' });
    req.usuario = usuario;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Sesión vencida. Vuelve a entrar.' });
  }
}

function soloGestion(req, res, next) {
  if (req.usuario.rol === 'admin' || req.usuario.rol === 'supervisor') return next();
  return res.status(403).json({ error: 'Solo administradores y supervisores pueden hacer cambios.' });
}

function soloAdmin(req, res, next) {
  if (req.usuario.rol !== 'admin') return res.status(403).json({ error: 'Requiere permisos de administrador.' });
  next();
}

/* --------------------------------- servidor ------------------------------- */

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  next();
});
app.use(cors({ origin: ORIGEN === '*' ? true : ORIGEN.split(','), credentials: false }));
app.use(express.json({ limit: '2mb' }));
app.use('/api/', rateLimit({ windowMs: 60 * 1000, max: 240, standardHeaders: true, legacyHeaders: false }));

const subida = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 } });

app.get('/api/salud', (req, res) => res.json({ ok: true, servicio: 'Check List Maquinarias ENTS', version: '1.0.0' }));

/* ---- acceso ---- */

const limiteLogin = rateLimit({ windowMs: 10 * 60 * 1000, max: 20 });

app.post('/api/auth/login', limiteLogin, async (req, res) => {
  const correo = String(req.body.correo || '').trim().toLowerCase();
  const clave = String(req.body.clave || '');
  const usuario = datos.usuarios.find((u) => u.correo === correo);
  if (!usuario || usuario.activo === false) return res.status(401).json({ error: 'Correo o clave incorrectos.' });
  const ok = await bcrypt.compare(clave, usuario.claveHash);
  if (!ok) return res.status(401).json({ error: 'Correo o clave incorrectos.' });
  return res.json({ token: firmar(usuario), usuario: publico(usuario) });
});

app.post('/api/auth/registro', limiteLogin, async (req, res) => {
  const { nombre, rut, correo, telefono, clave } = req.body || {};
  if (!nombre || !correo || !clave) return res.status(400).json({ error: 'Nombre, correo y clave son obligatorios.' });
  if (String(clave).length < 8) return res.status(400).json({ error: 'La clave debe tener al menos 8 caracteres.' });
  if (rut && !validarRut(rut)) return res.status(400).json({ error: 'El RUT no es válido.' });
  if (datos.usuarios.some((u) => u.correo === String(correo).toLowerCase())) {
    return res.status(409).json({ error: 'Ese correo ya está registrado.' });
  }
  const usuario = {
    id: nuevoId('usr'),
    nombre: String(nombre).trim(),
    rut: String(rut || '').trim(),
    correo: String(correo).trim().toLowerCase(),
    telefono: limpiarTelefono(telefono),
    rol: 'operador',
    equipos: [],
    activo: true,
    creado: new Date().toISOString(),
    claveHash: await bcrypt.hash(String(clave), 10)
  };
  datos.usuarios.push(usuario);
  guardarDatos();
  return res.status(201).json({ token: firmar(usuario), usuario: publico(usuario) });
});

app.get('/api/me', autenticar, (req, res) => res.json({ usuario: publico(req.usuario) }));

/* ---- usuarios ---- */

app.get('/api/usuarios', autenticar, (req, res) => {
  if (req.usuario.rol === 'operador') return res.json({ usuarios: [publico(req.usuario)] });
  return res.json({ usuarios: datos.usuarios.map(publico) });
});

app.post('/api/usuarios', autenticar, soloGestion, async (req, res) => {
  const { nombre, rut, correo, telefono, rol, equipos, clave } = req.body || {};
  if (!nombre || !correo) return res.status(400).json({ error: 'Nombre y correo son obligatorios.' });
  if (rol === 'admin' && req.usuario.rol !== 'admin') {
    return res.status(403).json({ error: 'Solo un administrador puede crear administradores.' });
  }
  if (rut && !validarRut(rut)) return res.status(400).json({ error: 'El RUT no es válido.' });
  if (datos.usuarios.some((u) => u.correo === String(correo).toLowerCase())) {
    return res.status(409).json({ error: 'Ese correo ya está registrado.' });
  }
  const inicial = String(clave || 'Ents' + new Date().getFullYear());
  const usuario = {
    id: nuevoId('usr'),
    nombre: String(nombre).trim(),
    rut: String(rut || '').trim(),
    correo: String(correo).trim().toLowerCase(),
    telefono: limpiarTelefono(telefono),
    rol: ['admin', 'supervisor', 'operador'].includes(rol) ? rol : 'operador',
    equipos: Array.isArray(equipos) ? equipos : [],
    activo: true,
    creado: new Date().toISOString(),
    claveHash: await bcrypt.hash(inicial, 10)
  };
  datos.usuarios.push(usuario);
  guardarDatos();
  return res.status(201).json({ usuario: publico(usuario), claveInicial: clave ? undefined : inicial });
});

app.put('/api/usuarios/:id', autenticar, soloGestion, async (req, res) => {
  const usuario = datos.usuarios.find((u) => u.id === req.params.id);
  if (!usuario) return res.status(404).json({ error: 'Usuario no encontrado.' });
  const { nombre, rut, correo, telefono, rol, equipos, activo, clave } = req.body || {};
  if (req.usuario.rol !== 'admin' && (usuario.rol === 'admin' || rol === 'admin')) {
    return res.status(403).json({ error: 'Solo un administrador puede modificar cuentas de administrador.' });
  }
  if (rut && !validarRut(rut)) return res.status(400).json({ error: 'El RUT no es válido.' });
  if (nombre) usuario.nombre = String(nombre).trim();
  if (rut !== undefined) usuario.rut = String(rut).trim();
  if (correo) usuario.correo = String(correo).trim().toLowerCase();
  if (telefono !== undefined) usuario.telefono = limpiarTelefono(telefono);
  if (rol && ['admin', 'supervisor', 'operador'].includes(rol)) usuario.rol = rol;
  if (Array.isArray(equipos)) usuario.equipos = equipos;
  if (typeof activo === 'boolean') usuario.activo = activo;
  if (clave) usuario.claveHash = await bcrypt.hash(String(clave), 10);
  guardarDatos();
  return res.json({ usuario: publico(usuario) });
});

app.delete('/api/usuarios/:id', autenticar, soloGestion, (req, res) => {
  const antes = datos.usuarios.length;
  datos.usuarios = datos.usuarios.filter((u) => u.id !== req.params.id);
  if (datos.usuarios.length === antes) return res.status(404).json({ error: 'Usuario no encontrado.' });
  guardarDatos();
  return res.json({ ok: true });
});

/* ---- checklists ---- */

app.get('/api/checklists', autenticar, (req, res) => {
  const resumen = datos.checklists.map((c) => ({
    id: c.id,
    tipo: c.tipo,
    nombre: c.nombre,
    frecuencia: c.frecuencia || 'Diario',
    items: c.items.length,
    actualizado: c.actualizado
  }));
  return res.json({ checklists: resumen });
});

app.get('/api/checklists/:id', autenticar, (req, res) => {
  const c = datos.checklists.find((x) => x.id === req.params.id);
  if (!c) return res.status(404).json({ error: 'Check list no encontrado.' });
  return res.json({ checklist: c });
});

/*
 * Carga de un check list desde Excel.
 * Columnas esperadas: Sección | Ítem | Criterio de aceptación | Crítico
 * La primera hoja del libro es la que se procesa.
 */
app.post('/api/checklists/importar', autenticar, soloGestion, subida.single('archivo'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Falta el archivo Excel.' });
  let libro;
  try {
    libro = XLSX.read(req.file.buffer, { type: 'buffer' });
  } catch (e) {
    return res.status(400).json({ error: 'No se pudo leer el archivo. Revisa que sea un Excel válido.' });
  }
  const hoja = libro.Sheets[libro.SheetNames[0]];
  const filas = XLSX.utils.sheet_to_json(hoja, { defval: '' });
  if (!filas.length) return res.status(400).json({ error: 'La hoja está vacía.' });

  const buscar = (fila, nombres) => {
    const claves = Object.keys(fila);
    for (const n of nombres) {
      const k = claves.find((c) => String(c).trim().toLowerCase() === n);
      if (k) return fila[k];
    }
    return '';
  };

  const items = [];
  filas.forEach((fila, i) => {
    const texto = String(buscar(fila, ['ítem', 'item', 'punto', 'descripción', 'descripcion']) || '').trim();
    if (!texto) return;
    const seccion = String(buscar(fila, ['sección', 'seccion', 'grupo', 'sistema']) || 'General').trim() || 'General';
    const criterio = String(buscar(fila, ['criterio de aceptación', 'criterio', 'criterio de aceptacion']) || '').trim();
    const criticoTxt = String(buscar(fila, ['crítico', 'critico', 'crítica', 'critica']) || '').trim().toLowerCase();
    items.push({
      id: 'i' + (i + 1),
      sec: seccion,
      txt: texto,
      criterio,
      crit: ['sí', 'si', 'x', '1', 'true', 'crítico', 'critico'].includes(criticoTxt)
    });
  });

  if (!items.length) return res.status(400).json({ error: 'No se encontraron ítems. Revisa los encabezados del archivo.' });

  const checklist = {
    id: nuevoId('chk'),
    tipo: String(req.body.tipo || 'General').trim(),
    nombre: String(req.body.nombre || 'Check List ' + checklist_tipo(req.body.tipo)).trim(),
    frecuencia: String(req.body.frecuencia || 'Diario').trim(),
    items,
    fuente: 'Excel: ' + (req.file.originalname || 'archivo'),
    actualizado: new Date().toISOString()
  };
  datos.checklists.push(checklist);
  guardarDatos();
  return res.status(201).json({ checklist: { id: checklist.id, tipo: checklist.tipo, nombre: checklist.nombre, items: checklist.items.length } });
});

function checklist_tipo(tipo) {
  return tipo ? '— ' + String(tipo).trim() : '';
}

app.delete('/api/checklists/:id', autenticar, soloGestion, (req, res) => {
  const antes = datos.checklists.length;
  datos.checklists = datos.checklists.filter((c) => c.id !== req.params.id);
  if (datos.checklists.length === antes) return res.status(404).json({ error: 'Check list no encontrado.' });
  guardarDatos();
  return res.json({ ok: true });
});

/* ---- inspecciones ---- */

app.get('/api/inspecciones', autenticar, (req, res) => {
  let lista = datos.inspecciones.slice().sort((a, b) => String(b.creado).localeCompare(String(a.creado)));
  if (req.usuario.rol === 'operador') lista = lista.filter((i) => i.usuarioId === req.usuario.id);
  if (req.query.desde) lista = lista.filter((i) => i.creado >= req.query.desde);
  if (req.query.hasta) lista = lista.filter((i) => i.creado <= req.query.hasta);
  if (req.query.estado) lista = lista.filter((i) => i.estado === req.query.estado);
  return res.json({ inspecciones: lista.slice(0, 500) });
});

app.post('/api/inspecciones', autenticar, (req, res) => {
  const { checklistId, equipoCodigo, equipoNombre, respuestas, observaciones, firma, telefono,
    patente, kilometraje, ultimaMantencion, proximaMantencion } = req.body || {};
  if (!Array.isArray(respuestas) || !respuestas.length) return res.status(400).json({ error: 'El checklist no tiene respuestas.' });

  const malos = respuestas.filter((r) => r.valor === 'no');
  const criticosMalos = malos.filter((r) => r.crit);
  const estado = criticosMalos.length ? 'Rechazado' : malos.length ? 'Observado' : 'Aprobado';

  const inspeccion = {
    id: nuevoId('ins'),
    checklistId: checklistId || '',
    equipoCodigo: equipoCodigo || '',
    equipoNombre: equipoNombre || '',
    patente: patente || '',
    kilometraje: kilometraje === 0 || kilometraje ? Number(kilometraje) : '',
    ultimaMantencion: ultimaMantencion || '',
    proximaMantencion: proximaMantencion || '',
    usuarioId: req.usuario.id,
    usuarioNombre: req.usuario.nombre,
    usuarioRut: req.usuario.rut,
    usuarioTelefono: limpiarTelefono(telefono || req.usuario.telefono),
    respuestas,
    observaciones: observaciones || '',
    firma: firma || '',
    estado,
    creado: new Date().toISOString(),
    whatsapp: { enviado: false }
  };
  datos.inspecciones.push(inspeccion);
  guardarDatos();
  return res.status(201).json({ inspeccion });
});

app.delete('/api/inspecciones/:id', autenticar, (req, res) => {
  const ins = datos.inspecciones.find((i) => i.id === req.params.id);
  if (!ins) return res.status(404).json({ error: 'Registro no encontrado.' });
  if (req.usuario.rol === 'operador' && ins.usuarioId !== req.usuario.id) {
    return res.status(403).json({ error: 'No puedes eliminar registros de otras personas.' });
  }
  datos.inspecciones = datos.inspecciones.filter((i) => i.id !== req.params.id);
  guardarDatos();
  return res.json({ ok: true });
});

/* ---- WhatsApp Cloud API ---- */

function fechaLarga(iso) {
  const meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '—';
  try {
    const p = {};
    new Intl.DateTimeFormat('es-CL', { timeZone: process.env.ZONA_HORARIA || 'America/Santiago', day: '2-digit', month: '2-digit', year: 'numeric' })
      .formatToParts(d).forEach((x) => { p[x.type] = x.value; });
    return Number(p.day) + ' de ' + meses[Number(p.month) - 1] + ' de ' + p.year;
  } catch (e) {
    return d.getDate() + ' de ' + meses[d.getMonth()] + ' de ' + d.getFullYear();
  }
}

function hora(iso) {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '—';
  try {
    const p = {};
    new Intl.DateTimeFormat('es-CL', { timeZone: process.env.ZONA_HORARIA || 'America/Santiago', hour: '2-digit', minute: '2-digit', hour12: false })
      .formatToParts(d).forEach((x) => { p[x.type] = x.value; });
    return p.hour + ':' + p.minute;
  } catch (e) {
    return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  }
}

function fechaCortaServidor(valor) {
  const m = String(valor || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (!m) return '—';
  return m[3] + '-' + m[2] + '-' + m[1];
}

function numeroServidor(valor) {
  if (valor === null || valor === undefined || valor === '') return '—';
  const n = Number(valor);
  if (isNaN(n)) return String(valor);
  return new Intl.NumberFormat('es-CL').format(n);
}

function mensajeConfirmacion(ins) {
  const malos = (ins.respuestas || []).filter((r) => r.valor === 'no');
  const lineas = [
    'Hola ' + ins.usuarioNombre + ',',
    '',
    'Se registró el check list del equipo ' + ins.equipoNombre + ' (' + ins.equipoCodigo + ').',
    'Patente: ' + (ins.patente || '—') + ' · Km/horómetro: ' + numeroServidor(ins.kilometraje) + '.',
    'Última mantención: ' + fechaCortaServidor(ins.ultimaMantencion) + ' · Próxima: ' + fechaCortaServidor(ins.proximaMantencion) + '.',
    'Día: ' + fechaLarga(ins.creado) + ' a las ' + hora(ins.creado) + '.',
    'Resultado: ' + ins.estado + '.',
    'Ítems con M (malo): ' + malos.length + '.',
    ins.observaciones ? 'Observaciones: ' + ins.observaciones : '',
    '',
    'Registro N° ' + ins.id.slice(-6).toUpperCase() + '.'
  ];
  return lineas.filter((l) => l !== '').join('\n');
}

async function enviarWhatsApp(destino, texto) {
  const token = process.env.WHATSAPP_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_ID;
  if (!token || !phoneId) throw new Error('Falta configurar WHATSAPP_TOKEN y WHATSAPP_PHONE_ID.');
  if (typeof fetch !== 'function') throw new Error('El servidor debe usar Node 20 o superior para enviar por WhatsApp.');

  const usarPlantilla = String(process.env.WHATSAPP_MODO_PLANTILLA || 'false') === 'true';
  const cuerpo = usarPlantilla
    ? {
        messaging_product: 'whatsapp',
        to: destino,
        type: 'template',
        template: {
          name: process.env.WHATSAPP_TEMPLATE || 'confirmacion_checklist',
          language: { code: process.env.WHATSAPP_TEMPLATE_IDIOMA || 'es_CL' },
          components: [{ type: 'body', parameters: [{ type: 'text', text: texto }] }]
        }
      }
    : { messaging_product: 'whatsapp', to: destino, type: 'text', text: { preview_url: false, body: texto } };

  const respuesta = await fetch('https://graph.facebook.com/v20.0/' + phoneId + '/messages', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' },
    body: JSON.stringify(cuerpo)
  });
  const salida = await respuesta.json().catch(() => ({}));
  if (!respuesta.ok) {
    const detalle = salida && salida.error && salida.error.message ? salida.error.message : 'Error ' + respuesta.status;
    throw new Error('WhatsApp rechazó el envío: ' + detalle);
  }
  return salida;
}

async function enviarDocumentoWhatsApp(destino, archivo, nombre, texto) {
  const token = process.env.WHATSAPP_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_ID;
  if (!token || !phoneId) throw new Error('Falta configurar WHATSAPP_TOKEN y WHATSAPP_PHONE_ID.');
  if (typeof fetch !== 'function') throw new Error('El servidor debe usar Node 20 o superior para enviar por WhatsApp.');

  const version = process.env.WHATSAPP_API_VERSION || 'v20.0';
  const formulario = new FormData();
  formulario.append('messaging_product', 'whatsapp');
  formulario.append('type', 'application/pdf');
  formulario.append('file', new Blob([archivo], { type: 'application/pdf' }), nombre);

  const subida = await fetch('https://graph.facebook.com/' + version + '/' + phoneId + '/media', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + token },
    body: formulario
  });
  const salidaSubida = await subida.json().catch(() => ({}));
  if (!subida.ok || !salidaSubida.id) {
    const detalle = salidaSubida && salidaSubida.error && salidaSubida.error.message ? salidaSubida.error.message : 'Error ' + subida.status;
    throw new Error('No se pudo subir el PDF a WhatsApp: ' + detalle);
  }

  const respuesta = await fetch('https://graph.facebook.com/' + version + '/' + phoneId + '/messages', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      messaging_product: 'whatsapp',
      to: destino,
      type: 'document',
      document: { id: salidaSubida.id, filename: nombre, caption: String(texto || '').slice(0, 1000) }
    })
  });
  const salida = await respuesta.json().catch(() => ({}));
  if (!respuesta.ok) {
    const detalle = salida && salida.error && salida.error.message ? salida.error.message : 'Error ' + respuesta.status;
    throw new Error('WhatsApp rechazó el envío del PDF: ' + detalle);
  }
  return salida;
}

function puedeVerInspeccion(usuario, ins) {
  return usuario.rol !== 'operador' || ins.usuarioId === usuario.id;
}

app.get('/api/inspecciones/:id/pdf', autenticar, async (req, res) => {
  const ins = datos.inspecciones.find((i) => i.id === req.params.id);
  if (!ins) return res.status(404).json({ error: 'Registro no encontrado.' });
  if (!puedeVerInspeccion(req.usuario, ins)) return res.status(403).json({ error: 'Este registro pertenece a otro operador.' });
  try {
    const archivo = await crearPdfInspeccion(ins, datos.ajustes || {});
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="Checklist_' + String(ins.id).slice(-6).toUpperCase() + '.pdf"');
    return res.send(archivo);
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'No se pudo generar el PDF.' });
  }
});

app.post('/api/inspecciones/:id/whatsapp', autenticar, async (req, res) => {
  const ins = datos.inspecciones.find((i) => i.id === req.params.id);
  if (!ins) return res.status(404).json({ error: 'Registro no encontrado.' });
  if (!puedeVerInspeccion(req.usuario, ins)) return res.status(403).json({ error: 'Este registro pertenece a otro operador.' });
  const destino = limpiarTelefono((req.body && req.body.telefono) || ins.usuarioTelefono);
  if (!destino) return res.status(400).json({ error: 'Falta el teléfono del encuestado.' });

  const texto = mensajeConfirmacion(ins);
  try {
    const archivo = await crearPdfInspeccion(ins, datos.ajustes || {});
    await enviarDocumentoWhatsApp(destino, archivo, 'Checklist_' + String(ins.id).slice(-6).toUpperCase() + '.pdf', texto);
  } catch (e) {
    return res.status(502).json({ error: e.message, mensaje: texto, enlace: 'https://wa.me/' + destino + '?text=' + encodeURIComponent(texto) });
  }
  ins.whatsapp = { enviado: true, destino, pdf: true, fechaEnvio: new Date().toISOString() };
  guardarDatos();
  return res.json({ ok: true, whatsapp: ins.whatsapp });
});


/* ---- sincronización de la base compartida ---- */

const CAMPOS_AJUSTES = ['empresa', 'proyecto', 'contrato', 'mensaje', 'whatsappApi'];

function fusionarUsuarios(lista, claves, actor) {
  (lista || []).slice(0, 500).forEach((u) => {
    if (!u || !u.email) return;
    const correo = String(u.email).trim().toLowerCase();
    let actual = datos.usuarios.find((x) => x.id === u.id) || datos.usuarios.find((x) => x.correo === correo);
    if (actor.rol !== 'admin' && ((u.rol === 'admin') || (actual && actual.rol === 'admin'))) return;
    if (!actual) {
      actual = {
        id: u.id || nuevoId('usr'),
        correo,
        nombre: '',
        rut: '',
        telefono: '',
        rol: 'operador',
        equipos: [],
        activo: true,
        creado: new Date().toISOString(),
        claveHash: null
      };
      datos.usuarios.push(actual);
    }
    actual.nombre = u.nombre || actual.nombre || '';
    actual.rut = u.rut !== undefined ? String(u.rut) : actual.rut;
    actual.telefono = u.telefono !== undefined ? limpiarTelefono(u.telefono) : actual.telefono;
    actual.rol = ['admin', 'supervisor', 'operador'].includes(u.rol) ? u.rol : actual.rol;
    actual.equipos = Array.isArray(u.equipos) ? u.equipos : actual.equipos;
    actual.activo = u.activo !== false;
    if (!actual.claveHash) {
      const entregada = claves && (claves[correo] || claves[u.email]);
      actual.claveHash = bcrypt.hashSync(String(entregada || ('Ents' + new Date().getFullYear())), 10);
    }
  });
}

function fusionarInspecciones(lista, actor) {
  (lista || []).slice(0, 3000).forEach((i) => {
    if (!i || !i.id) return;
    const actual = datos.inspecciones.find((x) => x.id === i.id);
    const base = actual || {};
    const reg = {
      id: i.id,
      checklistId: i.checklistId || base.checklistId || '',
      plantillaNombre: i.plantillaNombre || base.plantillaNombre || '',
      equipoCodigo: i.equipoCodigo || base.equipoCodigo || '',
      equipoNombre: i.equipoNombre || base.equipoNombre || '',
      patente: i.patente !== undefined ? i.patente : (base.patente || ''),
      kilometraje: i.kilometraje !== undefined ? i.kilometraje : (base.kilometraje !== undefined ? base.kilometraje : ''),
      ultimaMantencion: i.ultimaMantencion !== undefined ? i.ultimaMantencion : (base.ultimaMantencion || ''),
      proximaMantencion: i.proximaMantencion !== undefined ? i.proximaMantencion : (base.proximaMantencion || ''),
      respuestas: Array.isArray(i.respuestas) ? i.respuestas : (base.respuestas || []),
      observaciones: i.observaciones !== undefined ? i.observaciones : (base.observaciones || ''),
      firma: i.firma !== undefined ? i.firma : (base.firma || ''),
      estado: i.estado || base.estado || 'Observado',
      creado: i.creado || base.creado || new Date().toISOString(),
      whatsapp: i.whatsapp || base.whatsapp || { enviado: false }
    };
    if (actor.rol === 'operador') {
      reg.usuarioId = actor.id;
      reg.usuarioNombre = actor.nombre;
      reg.usuarioRut = actor.rut;
    } else {
      reg.usuarioId = i.usuarioId || base.usuarioId || actor.id;
      reg.usuarioNombre = i.usuarioNombre || base.usuarioNombre || '';
      reg.usuarioRut = i.usuarioRut || base.usuarioRut || '';
    }
    reg.usuarioTelefono = i.usuarioTelefono || base.usuarioTelefono || '';
    if (actual) Object.assign(actual, reg); else datos.inspecciones.push(reg);
  });
}

function aplicarBorrados(lista, actor) {
  (lista || []).slice(0, 500).forEach((b) => {
    if (!b || !b.id) return;
    if (b.tipo === 'inspeccion') {
      datos.inspecciones = datos.inspecciones.filter((i) => !(i.id === b.id && (actor.rol !== 'operador' || i.usuarioId === actor.id)));
    } else if (b.tipo === 'plantilla' && actor.rol !== 'operador') {
      datos.checklists = datos.checklists.filter((x) => x.id !== b.id);
    } else if (b.tipo === 'equipo' && actor.rol !== 'operador') {
      datos.equipos = datos.equipos.filter((x) => x.id !== b.id);
    } else if (b.tipo === 'usuario' && actor.rol !== 'operador') {
      const objetivo = datos.usuarios.find((u) => u.id === b.id);
      if (!objetivo) return;
      if (objetivo.rol === 'admin' && actor.rol !== 'admin') return;
      datos.usuarios = datos.usuarios.filter((u) => u.id !== b.id);
    }
  });
}

function paqueteServidor(actor) {
  const salida = {
    actualizado: new Date().toISOString(),
    plantillas: datos.checklists,
    equipos: datos.equipos,
    ajustes: datos.ajustes || {},
    inspecciones: actor.rol === 'operador'
      ? datos.inspecciones.filter((i) => i.usuarioId === actor.id)
      : datos.inspecciones
  };
  if (actor.rol !== 'operador') salida.usuarios = datos.usuarios.map(publico);
  return salida;
}

app.get('/api/sincronizar', autenticar, (req, res) => res.json(paqueteServidor(req.usuario)));

app.post('/api/sincronizar', autenticar, (req, res) => {
  const b = req.body || {};
  const actor = req.usuario;
  const quiereGestionar = b.usuarios || b.plantillas || b.equipos || b.ajustes;
  if (quiereGestionar && actor.rol === 'operador') {
    return res.status(403).json({ error: 'Solo administradores y supervisores pueden modificar la información.' });
  }
  if (Array.isArray(b.usuarios)) fusionarUsuarios(b.usuarios, b.claves, actor);
  if (Array.isArray(b.plantillas)) datos.checklists = b.plantillas.slice(0, 500);
  if (Array.isArray(b.equipos)) datos.equipos = b.equipos.slice(0, 2000);
  if (b.ajustes && typeof b.ajustes === 'object') {
    CAMPOS_AJUSTES.forEach((k) => { if (typeof b.ajustes[k] === 'string') datos.ajustes[k] = b.ajustes[k]; });
  }
  if (Array.isArray(b.inspecciones)) fusionarInspecciones(b.inspecciones, actor);
  if (Array.isArray(b.borrados)) aplicarBorrados(b.borrados, actor);
  guardarDatos();
  return res.json(paqueteServidor(actor));
});

/* ---- respaldo ---- */

app.get('/api/respaldo', autenticar, soloAdmin, (req, res) => {
  res.setHeader('Content-Disposition', 'attachment; filename="respaldo-check-list-ents.json"');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  return res.send(JSON.stringify(datos, null, 2));
});

/* ---------------------------- aplicación web ----------------------------- */
/* Publica la aplicación (PWA) en la misma dirección del servicio, para que
   los equipos entren por HTTPS sin instalar nada más. */
app.use('/api', (req, res) => res.status(404).json({ error: 'Ruta no encontrada.' }));
app.use(express.static(CARPETA_APP, {
  etag: true,
  setHeaders(res, ruta) {
    if (/(sw\.js|index\.html|manifest\.webmanifest)$/.test(ruta)) {
      res.setHeader('Cache-Control', 'no-cache');
    }
  }
}));
app.get(/^\/(?!api\/).*/, (req, res, next) => {
  res.sendFile(path.join(CARPETA_APP, 'index.html'), (err) => (err ? next() : undefined));
});

app.use((err, req, res, next) => {
  console.error(err);
  if (err && err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: 'El archivo supera los 8 MB.' });
  return res.status(500).json({ error: 'Error interno del servicio.' });
});

/* Crea las cuentas iniciales si la base está vacía. */
function asegurarDatosIniciales() {
  if (datos.usuarios.length) return;
  const iniciales = [
    { nombre: 'Administrador ENTS', correo: 'admin@ents.cl', rol: 'admin', clave: process.env.ADMIN_CLAVE || 'Admin2026', rut: '11.111.111-1' },
    { nombre: 'Supervisor ENTS', correo: 'supervisor@ents.cl', rol: 'supervisor', clave: process.env.SUPERVISOR_CLAVE || 'Supervisor2026', rut: '22.222.222-2' },
    { nombre: 'Operador ENTS', correo: 'operador@ents.cl', rol: 'operador', clave: process.env.OPERADOR_CLAVE || 'Operador2026', rut: '33.333.333-3' }
  ];
  datos.usuarios = iniciales.map((u) => ({
    id: nuevoId('usr'),
    nombre: u.nombre,
    rut: u.rut,
    correo: u.correo,
    telefono: '',
    rol: u.rol,
    equipos: [],
    activo: true,
    creado: new Date().toISOString(),
    claveHash: bcrypt.hashSync(u.clave, 10)
  }));
  datos.ajustes = datos.ajustes || {};
  guardarDatos();
  console.log('Base inicial creada con las cuentas de administrador, supervisor y operador.');
}

asegurarDatosIniciales();

module.exports = app;

if (require.main === module) {
  app.listen(PUERTO, HOST, () => {
    console.log('Check List Maquinarias ENTS escuchando en ' + HOST + ':' + PUERTO);
    console.log('Aplicación web: ' + CARPETA_APP);
    console.log('Datos en ' + ARCHIVO_DATOS);
  });
}
