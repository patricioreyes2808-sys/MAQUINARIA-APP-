# Servicio opcional — Check List Maquinarias ENTS

Este servicio **no es necesario** para usar la aplicación: la versión instalable funciona sola y guarda los datos en el teléfono. Se usa cuando se necesita una base central compartida entre varios equipos y el envío automático del mensaje de confirmación por WhatsApp.

## Qué agrega sobre la versión sin servidor

- Base de datos central (un archivo JSON en el servidor) con usuarios, check lists e inspecciones.
- Acceso con correo y clave, con sesión válida por 12 horas.
- Envío automático de la confirmación por WhatsApp con el **check list en PDF adjunto** (datos del equipo, patente, kilometraje, mantenciones, ítems, observaciones y firma) más el texto con día, fecha, hora y resultado.
- Carga de check lists en Excel desde el servidor.
- Respaldo completo descargable.

## Puesta en marcha

```bash
cd servidor
npm install
cp .env.example .env      # completar los datos reales
npm start                 # queda escuchando en el puerto indicado
```

Requisitos: Node.js 20 o superior y un dominio con HTTPS (Meta exige HTTPS para la API de WhatsApp).

## Variables de entorno

| Variable | Para qué sirve |
|---|---|
| `PORT` | Puerto del servicio (por defecto 8080). |
| `APP_ORIGIN` | Dirección de la aplicación autorizada (CORS). |
| `JWT_SECRET` | Clave larga y aleatoria para firmar las sesiones (mínimo 24 caracteres). |
| `DATA_DIR` | Carpeta donde se guarda `datos.json` (por defecto `./datos`). |
| `WHATSAPP_TOKEN` | Token permanente del sistema, desde Meta for Developers. |
| `WHATSAPP_PHONE_ID` | Identificador del número de WhatsApp Business. |
| `WHATSAPP_TEMPLATE` / `WHATSAPP_TEMPLATE_IDIOMA` | Nombre y idioma de la plantilla aprobada (obligatoria para escribir fuera de la ventana de 24 horas). |
| `WHATSAPP_MODO_PLANTILLA` | `true` para enviar con plantilla, `false` para texto libre. |
| `ZONA_HORARIA` | Zona horaria de las fechas del PDF y del mensaje (por defecto `America/Santiago`). |

## Endpoints principales

| Método | Ruta | Para qué sirve |
|---|---|---|
| POST | `/api/auth/login` | Iniciar sesión (correo y clave). |
| POST | `/api/auth/registro` | Crear cuenta de operador. |
| GET | `/api/me` | Datos de la sesión actual. |
| GET/POST | `/api/usuarios` | Listar y crear usuarios (nombre, RUT, correo, celular, equipos). |
| PUT/DELETE | `/api/usuarios/:id` | Editar o eliminar usuarios. |
| GET | `/api/checklists` | Listar check lists disponibles. |
| POST | `/api/checklists/importar` | Subir un check list en Excel (campo `archivo`). |
| GET/POST | `/api/inspecciones` | Listar y guardar inspecciones. |
| GET | `/api/inspecciones/:id/pdf` | Descargar el check list en PDF (A4). Un operador solo accede a sus propios registros. |
| POST | `/api/inspecciones/:id/whatsapp` | Generar el PDF y enviarlo como documento por WhatsApp, junto con el texto de confirmación. |
| GET | `/api/respaldo` | Descargar respaldo completo (administrador). |

## Notas de seguridad

- Cambiar las claves de demostración antes de publicar y crear los usuarios reales.
- El servicio guarda un archivo `datos.json`: programar respaldos diarios de esa carpeta.
- Si el envío por WhatsApp falla, el servicio devuelve el texto del mensaje y un enlace `wa.me` para enviarlo a mano; el PDF se puede descargar desde la ficha del registro y adjuntar en la conversación.
- El PDF se genera en el servidor con la librería `pdfkit` (se instala con `npm install`); no requiere programas externos.
- No exponer el servicio sin HTTPS ni compartir el token de Meta.
