/*
 * Check List Maquinarias ENTS — generación del PDF de confirmación
 * -----------------------------------------------------------------
 * Construye un documento A4 con la cabecera institucional, los datos del
 * equipo (patente, kilometraje y mantenciones), el detalle de los ítems,
 * las observaciones y la firma del operador.
 */

'use strict';

const PDFDocument = require('pdfkit');

const AZUL = '#0B2D5B';
const GRIS = '#5A6470';
const LINEA = '#D5DBE1';
const VERDE = '#1B7F4B';
const ROJO = '#A61B1B';
const AMBAR = '#9A6B00';

const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

const ZONA = process.env.ZONA_HORARIA || 'America/Santiago';

function partesFecha(iso) {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return null;
  try {
    const f = new Intl.DateTimeFormat('es-CL', {
      timeZone: ZONA, day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: false
    }).formatToParts(d);
    const mapa = {};
    f.forEach((p) => { mapa[p.type] = p.value; });
    return mapa;
  } catch (e) {
    return { day: String(d.getDate()).padStart(2, '0'), month: String(d.getMonth() + 1).padStart(2, '0'), year: String(d.getFullYear()), hour: String(d.getHours()).padStart(2, '0'), minute: String(d.getMinutes()).padStart(2, '0') };
  }
}

function fechaLarga(iso) {
  const p = partesFecha(iso);
  if (!p) return '—';
  return Number(p.day) + ' de ' + MESES[Number(p.month) - 1] + ' de ' + p.year;
}

function hora(iso) {
  const p = partesFecha(iso);
  if (!p) return '—';
  return p.hour + ':' + p.minute;
}

function fechaCorta(valor) {
  if (!valor) return '—';
  const t = String(valor).slice(0, 10);
  const p = t.split('-');
  return p.length === 3 ? p[2] + '-' + p[1] + '-' + p[0] : String(valor);
}

function numero(valor) {
  if (valor === 0 || valor) {
    const n = Number(String(valor).replace(/\./g, ''));
    if (!isNaN(n)) return n.toLocaleString('es-CL');
  }
  return '—';
}

function telefonoBonito(tel) {
  const n = String(tel || '').replace(/\D/g, '');
  if (!n) return '—';
  if (n.length === 11 && n.startsWith('56')) return '+56 ' + n.slice(2, 3) + ' ' + n.slice(3, 7) + ' ' + n.slice(7);
  if (n.length === 9) return '+56 ' + n.slice(0, 1) + ' ' + n.slice(1, 5) + ' ' + n.slice(5);
  return '+' + n;
}

function diasHasta(fecha) {
  if (!fecha) return null;
  const m = String(fecha).match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (!m) return null;
  const objetivo = Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  const hoy = new Date();
  let partes;
  try {
    partes = {};
    new Intl.DateTimeFormat('en-CA', { timeZone: ZONA, year: 'numeric', month: '2-digit', day: '2-digit' })
      .formatToParts(hoy).forEach((x) => { partes[x.type] = x.value; });
  } catch (e) {
    partes = { year: hoy.getFullYear(), month: hoy.getMonth() + 1, day: hoy.getDate() };
  }
  const base = Date.UTC(Number(partes.year), Number(partes.month) - 1, Number(partes.day));
  return Math.round((objetivo - base) / 86400000);
}

function codigoCorto(ins) {
  const codigo = String(ins.id || '').replace(/[^a-z0-9]/gi, '').slice(-6).toUpperCase();
  return codigo || 'S/N';
}

function colorEstado(estado) {
  if (estado === 'Aprobado') return VERDE;
  if (estado === 'Rechazado') return ROJO;
  return AMBAR;
}

function crearPdfInspeccion(ins, ajustes) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: 'A4',
      margins: { top: 34, bottom: 44, left: 40, right: 40 },
      bufferPages: true,
      info: {
        Title: 'Check list ' + (ins.equipoNombre || '') + ' ' + codigoCorto(ins),
        Author: (ajustes && ajustes.empresa) || 'Salfa Montajes',
        Subject: 'Confirmación de check list'
      }
    });

    const partes = [];
    doc.on('data', (c) => partes.push(c));
    doc.on('end', () => resolve(Buffer.concat(partes)));
    doc.on('error', reject);

    const izq = 40;
    const ancho = doc.page.width - 80;
    const empresa = (ajustes && ajustes.empresa) || 'Salfa Montajes';
    const proyecto = (ajustes && ajustes.proyecto) || 'Minera Escondida';
    const contrato = (ajustes && ajustes.contrato) || '';

    /* ---------------------------- cabecera ---------------------------- */
    doc.save();
    doc.rect(0, 0, doc.page.width, 72).fill(AZUL);
    doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(15).text(empresa, izq, 20, { width: ancho * 0.6 });
    doc.font('Helvetica').fontSize(8.5).fillColor('#C9D6E3')
      .text([proyecto, contrato].filter(Boolean).join('  ·  '), izq, 40, { width: ancho * 0.6 });
    doc.font('Helvetica-Bold').fontSize(11).fillColor('#FFFFFF')
      .text('CONFIRMACIÓN DE CHECK LIST', izq, 20, { width: ancho, align: 'right' });
    doc.font('Helvetica').fontSize(8.5).fillColor('#C9D6E3')
      .text('Registro N° ' + codigoCorto(ins), izq, 38, { width: ancho, align: 'right' });
    doc.restore();

    let y = 92;
    doc.fillColor('#111827').font('Helvetica-Bold').fontSize(15)
      .text(String(ins.plantillaNombre || 'Check list'), izq, y, { width: ancho });
    y += 22;

    /* ------------------------- datos del equipo ------------------------ */
    const filas = [
      ['Equipo', (ins.equipoCodigo || '') + ' · ' + (ins.equipoNombre || ''), 'Patente', ins.patente || '—'],
      ['Kilometraje / horómetro', numero(ins.kilometraje), 'Última mantención', fechaCorta(ins.ultimaMantencion)],
      ['Próxima mantención', fechaCorta(ins.proximaMantencion), 'Fecha y hora', fechaLarga(ins.creado) + ' · ' + hora(ins.creado)],
      ['Operador', (ins.usuarioNombre || '') + (ins.usuarioRut ? '  ·  ' + ins.usuarioRut : ''), 'Teléfono', telefonoBonito(ins.usuarioTelefono)]
    ];

    doc.roundedRect(izq, y, ancho, 26 + filas.length * 17, 4).lineWidth(0.8).strokeColor(LINEA).stroke();
    let fy = y + 8;
    filas.forEach((f) => {
      const mitades = [[f[0], f[1]], [f[2], f[3]]];
      mitades.forEach((par, idx) => {
        const x = izq + 10 + idx * (ancho / 2);
        doc.font('Helvetica').fontSize(7.4).fillColor(GRIS).text(par[0].toUpperCase(), x, fy, { width: ancho / 2 - 20 });
        doc.font('Helvetica-Bold').fontSize(9).fillColor('#111827').text(String(par[1] || '—'), x, fy + 8, { width: ancho / 2 - 20, lineBreak: false, ellipsis: true });
      });
      fy += 17;
    });
    y += 26 + filas.length * 17 + 12;

    /* ---------------------- aviso de mantención ------------------------ */
    const dias = diasHasta(ins.proximaMantencion);
    if (dias !== null && dias < 0) {
      doc.roundedRect(izq, y - 4, ancho, 20, 3).fill('#FDECEC');
      doc.fillColor(ROJO).font('Helvetica-Bold').fontSize(8.5)
        .text('Mantención preventiva vencida hace ' + Math.abs(dias) + (Math.abs(dias) === 1 ? ' día' : ' días') + ' (programada para el ' + fechaCorta(ins.proximaMantencion) + ').', izq + 8, y + 1, { width: ancho - 16, lineBreak: false, ellipsis: true });
      y += 22;
    } else if (dias !== null && dias <= 15) {
      doc.roundedRect(izq, y - 4, ancho, 20, 3).fill('#FFF6E5');
      doc.fillColor('#B45309').font('Helvetica-Bold').fontSize(8.5)
        .text('Mantención preventiva próxima: vence en ' + dias + (dias === 1 ? ' día' : ' días') + ' (' + fechaCorta(ins.proximaMantencion) + ').', izq + 8, y + 1, { width: ancho - 16, lineBreak: false, ellipsis: true });
      y += 22;
    }

    /* ------------------------------ estado ----------------------------- */
    const buenos = (ins.respuestas || []).filter((r) => r.valor === 'si').length;
    const malos = (ins.respuestas || []).filter((r) => r.valor === 'no').length;
    const na = (ins.respuestas || []).filter((r) => r.valor === 'na').length;
    const resumen = 'Resultado: ' + (ins.estado || '—') + '     ·     B (bueno): ' + buenos + '     ·     M (malo): ' + malos + '     ·     N/A: ' + na;
    doc.roundedRect(izq, y, ancho, 24, 4).fill('#F2F5F8');
    doc.fillColor(colorEstado(ins.estado)).font('Helvetica-Bold').fontSize(9.5).text(resumen, izq + 10, y + 7, { width: ancho - 20 });
    y += 36;

    /* ------------------------------ ítems ------------------------------ */
    const cols = [
      { t: 'N°', w: 24, a: 'left' },
      { t: 'Punto de inspección', w: 268, a: 'left' },
      { t: 'Resultado', w: 62, a: 'center' },
      { t: 'Observación', w: ancho - 24 - 268 - 62, a: 'left' }
    ];

    function cabeceraTabla() {
      doc.rect(izq, y, ancho, 18).fill(AZUL);
      let x = izq;
      cols.forEach((c) => {
        doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(8)
          .text(c.t, x + 5, y + 5, { width: c.w - 10, align: c.a });
        x += c.w;
      });
      y += 18;
    }

    cabeceraTabla();
    let n = 0;
    let sombra = false;
    (ins.respuestas || []).forEach((r) => {
      const valor = r.valor === 'si' ? 'B · Bueno' : r.valor === 'no' ? 'M · Malo' : 'N/A';
      const texto = (r.crit ? '[CRÍTICO] ' : '') + (r.txt || '') + (r.sec ? '' : '');
      doc.font('Helvetica').fontSize(8);
      const altoTexto = doc.heightOfString(texto, { width: cols[1].w - 10 });
      const altoObs = doc.heightOfString(String(r.obs || ''), { width: cols[3].w - 10 });
      const alto = Math.max(15, altoTexto + 8, altoObs + 8);

      if (y + alto > doc.page.height - 60) {
        doc.addPage();
        y = 46;
        cabeceraTabla();
      }

      if (sombra) doc.rect(izq, y, ancho, alto).fill('#F7F9FB');
      sombra = !sombra;

      let x = izq;
      doc.fillColor('#6B7280').font('Helvetica').fontSize(7.6)
        .text(String(++n), x + 5, y + 4, { width: cols[0].w - 10 });
      x += cols[0].w;
      doc.fillColor('#111827').fontSize(8)
        .text(texto, x + 5, y + 4, { width: cols[1].w - 10 });
      x += cols[1].w;
      doc.fillColor(colorEstado(r.valor === 'si' ? 'Aprobado' : r.valor === 'no' ? 'Rechazado' : 'Observado'))
        .font('Helvetica-Bold').fontSize(7.8)
        .text(valor, x + 3, y + 4, { width: cols[2].w - 6, align: 'center' });
      x += cols[2].w;
      doc.fillColor('#374151').font('Helvetica').fontSize(7.4)
        .text(String(r.obs || ''), x + 5, y + 4, { width: cols[3].w - 10 });

      doc.moveTo(izq, y + alto).lineTo(izq + ancho, y + alto).lineWidth(0.4).strokeColor(LINEA).stroke();
      y += alto;
    });

    /* -------------------------- observaciones -------------------------- */
    y += 14;
    if (y > doc.page.height - 150) { doc.addPage(); y = 46; }
    doc.font('Helvetica-Bold').fontSize(9).fillColor(AZUL).text('Observaciones generales', izq, y);
    y += 14;
    doc.font('Helvetica').fontSize(8.5).fillColor('#111827')
      .text(ins.observaciones || 'Sin observaciones registradas.', izq, y, { width: ancho, height: 60 });
    y = doc.y + 10;

    /* ------------------------------ firma ------------------------------ */
    const firma = String(ins.firma || '');
    if (firma.indexOf('base64,') > 0) {
      try {
        const datosFirma = Buffer.from(firma.split('base64,')[1], 'base64');
        const altoFirma = 74;
        if (y > doc.page.height - 140) { doc.addPage(); y = 46; }
        doc.font('Helvetica-Bold').fontSize(8.5).fillColor(AZUL).text('Firma del operador', izq, y);
        doc.image(datosFirma, izq, y + 12, { fit: [190, altoFirma] });
        doc.moveTo(izq, y + 12 + altoFirma).lineTo(izq + 190, y + 12 + altoFirma).lineWidth(0.6).strokeColor('#9AA4AF').stroke();
        doc.font('Helvetica').fontSize(7.5).fillColor(GRIS)
          .text((ins.usuarioNombre || '') + (ins.usuarioRut ? '  ·  ' + ins.usuarioRut : ''), izq, y + 12 + altoFirma + 4, { width: 190 });
        y += 12 + altoFirma + 26;
      } catch (e) { /* firma ilegible: se omite sin romper el documento */ }
    }

    /* ------------------------------ pie ------------------------------- */
    // El pie se escribe fuera del área de texto: se anula el margen inferior
    // mientras se dibuja para que pdfkit no agregue páginas en blanco.
    const rango = doc.bufferedPageRange();
    for (let i = 0; i < rango.count; i++) {
      doc.switchToPage(rango.start + i);
      const altoPagina = doc.page.height;
      const margenPrevio = doc.page.margins.bottom;
      doc.page.margins.bottom = 0;
      doc.font('Helvetica').fontSize(7).fillColor(GRIS)
        .text('Documento generado automáticamente por Check List Maquinarias ENTS. La información corresponde al registro firmado por el operador.',
          izq, altoPagina - 60, { width: ancho, align: 'center', lineBreak: false });
      doc.font('Helvetica').fontSize(7.5).fillColor(GRIS)
        .text('Registro N° ' + codigoCorto(ins) + '  ·  ' + fechaLarga(ins.creado), izq, altoPagina - 44, { width: ancho, align: 'left', lineBreak: false });
      doc.text('Página ' + (i + 1) + ' de ' + rango.count, izq, altoPagina - 44, { width: ancho, align: 'right', lineBreak: false });
      doc.page.margins.bottom = margenPrevio;
    }

    doc.end();
  });
}

module.exports = { crearPdfInspeccion };
